package com.hibr.nativeapp

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Shape correction. Points are x0,y0,x1,y1,... in one uniform space (same scale on both axes). */
object Shapes {

    /** Returns the corrected points (line / rectangle / circle / ellipse), or null to leave the stroke as is. */
    fun snap(p: FloatArray, minDiag: Float): FloatArray? {
        val n = p.size / 2
        if (n < 4) return null
        var x0 = Float.MAX_VALUE
        var y0 = Float.MAX_VALUE
        var x1 = -Float.MAX_VALUE
        var y1 = -Float.MAX_VALUE
        for (i in 0 until n) {
            val x = p[2 * i]
            val y = p[2 * i + 1]
            if (x < x0) x0 = x
            if (x > x1) x1 = x
            if (y < y0) y0 = y
            if (y > y1) y1 = y
        }
        val w = max(x1 - x0, 0.001f)
        val h = max(y1 - y0, 0.001f)
        val diag = hypot(w, h)
        if (diag < minDiag) return null

        val ax = p[0]
        val ay = p[1]
        val bx = p[2 * n - 2]
        val by = p[2 * n - 1]
        val chord = hypot(bx - ax, by - ay)

        // open stroke -> straight line (unless it is a clear arc)
        if (chord > diag * 0.35f) {
            var dev = 0f
            for (i in 0 until n) {
                val d = abs((bx - ax) * (ay - p[2 * i + 1]) - (ax - p[2 * i]) * (by - ay)) / chord
                if (d > dev) dev = d
            }
            if (dev > chord * 0.25f) return null
            return floatArrayOf(ax, ay, bx, by)
        }

        // closed stroke -> rectangle or ellipse/circle
        val cx = (x0 + x1) / 2f
        val cy = (y0 + y1) / 2f
        val ra = w / 2f
        val rb = h / 2f
        val sc = (ra + rb) / 2f
        var eE = 0f
        var eR = 0f
        for (i in 0 until n) {
            val x = p[2 * i]
            val y = p[2 * i + 1]
            eE += abs(hypot((x - cx) / ra, (y - cy) / rb) - 1f)
            eR += min(min(x - x0, x1 - x), min(y - y0, y1 - y)) / sc
        }
        eE /= n
        eR /= n
        if (eR < eE * 0.6f) {
            return densify(floatArrayOf(x0, y0, x1, y0, x1, y1, x0, y1, x0, y0))
        }
        val round = abs(w - h) < 0.12f * max(w, h)
        val rx = if (round) (ra + rb) / 2f else ra
        val ry = if (round) (ra + rb) / 2f else rb
        val out = FloatArray(2 * 49)
        for (k in 0..48) {
            val t = k / 48f * 2f * PI.toFloat()
            out[2 * k] = cx + rx * cos(t)
            out[2 * k + 1] = cy + ry * sin(t)
        }
        return out
    }

    /** Adds points along straight edges so the smoothed path keeps sharp-looking corners. */
    private fun densify(poly: FloatArray): FloatArray {
        val n = poly.size / 2
        var per = 0f
        for (i in 1 until n) per += hypot(poly[2 * i] - poly[2 * i - 2], poly[2 * i + 1] - poly[2 * i - 1])
        val step = max(per / 200f, 0.5f)
        val out = ArrayList<Float>()
        out.add(poly[0])
        out.add(poly[1])
        for (i in 1 until n) {
            val ax = poly[2 * i - 2]
            val ay = poly[2 * i - 1]
            val bx = poly[2 * i]
            val by = poly[2 * i + 1]
            val d = hypot(bx - ax, by - ay)
            val k = max(1, ceil(d / step).toInt())
            for (j in 1..k) {
                val t = j.toFloat() / k
                out.add(ax + (bx - ax) * t)
                out.add(ay + (by - ay) * t)
            }
        }
        return out.toFloatArray()
    }
}
