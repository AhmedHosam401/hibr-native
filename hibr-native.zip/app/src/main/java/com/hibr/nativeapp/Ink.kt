package com.hibr.nativeapp

import android.content.Context
import android.graphics.Path
import org.json.JSONArray
import org.json.JSONObject

object Tool {
    const val PEN = 0
    const val HL = 1
    const val ERASER = 2
    const val IMAGE = 3
    const val TEXT = 4
    const val SELECT = 5
}

/** One stroke. pts = x0,y0,x1,y1,... normalized to the page (0..1). width = fraction of page width. */
class Stroke(val tool: Int, val color: Int, var width: Float, val pts: FloatArray) {
    var path: Path? = null
    var pathVer: Int = -1

    /** For Tool.IMAGE: file name inside the document's image folder. pts = x, y, w, h (normalized to the page). */
    var img: String? = null

    /** For Tool.TEXT: the text. width = font size as a fraction of the page width, pts = x, y, w, h (normalized). */
    var text: String? = null
}

class FloatBuf {
    private var a = FloatArray(256)
    private var n = 0

    fun add(x: Float, y: Float) {
        if (n + 2 > a.size) a = a.copyOf(a.size * 2)
        a[n] = x
        a[n + 1] = y
        n += 2
    }

    fun toArray(): FloatArray = a.copyOf(n)

    fun clear() {
        n = 0
    }
}

class Item(val page: Int, val index: Int, val stroke: Stroke)

/** type 0 = a stroke was added, type 1 = strokes were erased */
class Action(val type: Int, val items: List<Item>)

class InkStore(private val ctx: Context, private val id: String) {
    private val pages = HashMap<Int, MutableList<Stroke>>()
    private val undoS = ArrayList<Action>()
    private val redoS = ArrayList<Action>()
    private var eraseItems: ArrayList<Item>? = null
    private var dirty = false

    fun strokes(page: Int): List<Stroke> = pages[page] ?: emptyList()

    /** After pages were deleted / inserted / moved: order[k] = old page index shown at new position k (negative = new blank page). */
    fun remap(order: IntArray) {
        val np = HashMap<Int, MutableList<Stroke>>()
        for (k in order.indices) {
            val o = order[k]
            if (o < 0) continue
            val l = pages[o]
            if (l != null && l.isNotEmpty()) np[k] = l
        }
        pages.clear()
        pages.putAll(np)
        undoS.clear()
        redoS.clear()
        eraseItems = null
        dirty = true
    }

    fun hasStrokes(): Boolean {
        for (l in pages.values) if (l.isNotEmpty()) return true
        return false
    }

    fun canUndo(): Boolean = undoS.isNotEmpty()

    fun canRedo(): Boolean = redoS.isNotEmpty()

    fun add(page: Int, s: Stroke) {
        val l = pages.getOrPut(page) { ArrayList() }
        l.add(s)
        undoS.add(Action(0, listOf(Item(page, l.size - 1, s))))
        redoS.clear()
        dirty = true
    }

    /** Replaces one stroke in place (used for moving / resizing an image) as one undoable step. */
    fun replace(page: Int, index: Int, ns: Stroke) {
        val l = pages[page] ?: return
        if (index < 0 || index >= l.size) return
        val old = l[index]
        l[index] = ns
        undoS.add(Action(2, listOf(Item(page, index, old), Item(page, index, ns))))
        redoS.clear()
        dirty = true
    }

    /** Replaces several strokes of one page in place (lasso move / resize) as one undoable step. */
    fun replaceMany(page: Int, indices: IntArray, ns: List<Stroke>) {
        val l = pages[page] ?: return
        for (i in indices) if (i < 0 || i >= l.size) return
        val items = ArrayList<Item>()
        for (k in indices.indices) {
            val i = indices[k]
            items.add(Item(page, i, l[i]))
            items.add(Item(page, i, ns[k]))
            l[i] = ns[k]
        }
        undoS.add(Action(2, items))
        redoS.clear()
        dirty = true
    }

    fun eraseBegin() {
        eraseItems = ArrayList()
    }

    fun eraseRemove(page: Int, indices: List<Int>) {
        val l = pages[page] ?: return
        for (idx in indices.sortedDescending()) {
            if (idx < 0 || idx >= l.size) continue
            val s = l.removeAt(idx)
            eraseItems?.add(Item(page, idx, s))
        }
        dirty = true
    }

    fun eraseEnd() {
        val items = eraseItems
        eraseItems = null
        if (items != null && items.isNotEmpty()) {
            undoS.add(Action(1, items))
            redoS.clear()
        }
    }

    /** Adds several strokes to one page as a single undoable step. */
    fun addMany(page: Int, ss: List<Stroke>) {
        if (ss.isEmpty()) return
        val l = pages.getOrPut(page) { ArrayList() }
        val items = ArrayList<Item>()
        for (s in ss) {
            l.add(s)
            items.add(Item(page, l.size - 1, s))
        }
        undoS.add(Action(0, items))
        redoS.clear()
        dirty = true
    }

    fun undo(): Boolean {
        if (undoS.isEmpty()) return false
        val a = undoS.removeAt(undoS.size - 1)
        if (a.type == 2) {
            var k = 0
            while (k < a.items.size) {
                val o = a.items[k]
                pages[o.page]?.let { l -> if (o.index < l.size) l[o.index] = o.stroke }
                k += 2
            }
        } else if (a.type == 0) {
            for (k in a.items.indices.reversed()) {
                val it = a.items[k]
                pages[it.page]?.let { l -> if (it.index < l.size) l.removeAt(it.index) }
            }
        } else {
            for (k in a.items.indices.reversed()) {
                val it = a.items[k]
                val l = pages.getOrPut(it.page) { ArrayList() }
                l.add(minOf(it.index, l.size), it.stroke)
            }
        }
        redoS.add(a)
        dirty = true
        return true
    }

    fun redo(): Boolean {
        if (redoS.isEmpty()) return false
        val a = redoS.removeAt(redoS.size - 1)
        if (a.type == 2) {
            var k = 1
            while (k < a.items.size) {
                val n = a.items[k]
                pages[n.page]?.let { l -> if (n.index < l.size) l[n.index] = n.stroke }
                k += 2
            }
        } else if (a.type == 0) {
            for (it in a.items) {
                val l = pages.getOrPut(it.page) { ArrayList() }
                l.add(minOf(it.index, l.size), it.stroke)
            }
        } else {
            for (it in a.items) pages[it.page]?.let { l -> if (it.index < l.size) l.removeAt(it.index) }
        }
        undoS.add(a)
        dirty = true
        return true
    }

    fun load() {
        try {
            val f = Library.inkFile(ctx, id)
            if (!f.exists()) return
            val root = JSONObject(f.readText())
            val keys = root.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                val arr = root.getJSONArray(k)
                val list = ArrayList<Stroke>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val p = o.getJSONArray("p")
                    val pts = FloatArray(p.length())
                    for (j in 0 until p.length()) pts[j] = p.getDouble(j).toFloat()
                    val st = Stroke(o.getInt("t"), o.getInt("c"), o.getDouble("w").toFloat(), pts)
                    if (o.has("i")) st.img = o.getString("i")
                    if (o.has("tx")) st.text = o.getString("tx")
                    list.add(st)
                }
                pages[k.toInt()] = list
            }
        } catch (e: Exception) {
        }
    }

    fun save() {
        if (!dirty) return
        try {
            val root = JSONObject()
            for ((page, list) in pages) {
                if (list.isEmpty()) continue
                val arr = JSONArray()
                for (s in list) {
                    val o = JSONObject()
                    o.put("t", s.tool)
                    o.put("c", s.color)
                    o.put("w", s.width.toDouble())
                    val im = s.img
                    if (im != null) o.put("i", im)
                    val tx = s.text
                    if (tx != null) o.put("tx", tx)
                    val p = JSONArray()
                    for (v in s.pts) p.put(Math.round(v * 10000f) / 10000.0)
                    o.put("p", p)
                    arr.put(o)
                }
                root.put(page.toString(), arr)
            }
            val f = Library.inkFile(ctx, id)
            if (root.length() == 0) f.delete() else f.writeText(root.toString())
            dirty = false
        } catch (e: Exception) {
        }
    }
}
