package com.hibr.nativeapp

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import com.shockwave.pdfium.PdfiumCore
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID
import kotlin.math.max

data class Doc(
    val id: String,
    var name: String,
    var star: Boolean = false,
    var openedAt: Long = System.currentTimeMillis(),
    var lastPage: Int = 0,
    var lastFrac: Float = 0f,
    var pages: Int = 0,
    var folder: String = ""
)

object Library {
    @Volatile
    var lastError: String = ""
    private val docs = mutableListOf<Doc>()
    private var loaded = false

    private fun pdfDir(c: Context): File {
        val d = File(c.filesDir, "pdfs")
        d.mkdirs()
        return d
    }

    fun file(c: Context, id: String): File = File(pdfDir(c), "$id.pdf")

    fun thumbFile(c: Context, id: String): File {
        val d = File(c.filesDir, "thumbs")
        d.mkdirs()
        return File(d, "$id.jpg")
    }

    private fun metaFile(c: Context): File = File(c.filesDir, "library.json")

    fun imgDir(c: Context, id: String): File {
        val d = File(File(c.filesDir, "img"), id)
        d.mkdirs()
        return d
    }

    fun inkFile(c: Context, id: String): File {
        val d = File(c.filesDir, "ink")
        d.mkdirs()
        return File(d, "$id.json")
    }

    @Synchronized
    private fun ensure(c: Context) {
        if (loaded) return
        loaded = true
        try {
            val f = metaFile(c)
            if (f.exists()) {
                val arr = JSONArray(f.readText())
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    docs.add(
                        Doc(
                            id = o.getString("id"),
                            name = o.getString("name"),
                            star = o.optBoolean("star", false),
                            openedAt = o.optLong("openedAt", 0L),
                            lastPage = o.optInt("lastPage", 0),
                            lastFrac = o.optDouble("lastFrac", 0.0).toFloat(),
                            pages = o.optInt("pages", 0),
                            folder = o.optString("folder", "")
                        )
                    )
                }
            }
        } catch (e: Exception) {
        }
    }

    @Synchronized
    fun all(c: Context): List<Doc> {
        ensure(c)
        return docs.toList()
    }

    @Synchronized
    fun find(c: Context, id: String): Doc? {
        ensure(c)
        return docs.firstOrNull { it.id == id }
    }

    @Synchronized
    fun save(c: Context) {
        ensure(c)
        try {
            val arr = JSONArray()
            for (d in docs) {
                val o = JSONObject()
                o.put("id", d.id)
                o.put("name", d.name)
                o.put("star", d.star)
                o.put("openedAt", d.openedAt)
                o.put("lastPage", d.lastPage)
                o.put("lastFrac", d.lastFrac.toDouble())
                o.put("pages", d.pages)
                o.put("folder", d.folder)
                arr.put(o)
            }
            metaFile(c).writeText(arr.toString())
        } catch (e: Exception) {
        }
    }

    // ---- folders (a folder exists while it has files, or until the user deletes it)
    private val extraFolders = LinkedHashSet<String>()
    private var foldersLoaded = false

    private fun foldersFile(c: Context): File = File(c.filesDir, "folders.json")

    private fun loadFolders(c: Context) {
        if (foldersLoaded) return
        foldersLoaded = true
        try {
            val f = foldersFile(c)
            if (f.exists()) {
                val arr = JSONArray(f.readText())
                for (i in 0 until arr.length()) extraFolders.add(arr.getString(i))
            }
        } catch (e: Exception) {
        }
    }

    private fun saveFolders(c: Context) {
        try {
            val arr = JSONArray()
            for (n in extraFolders) arr.put(n)
            foldersFile(c).writeText(arr.toString())
        } catch (e: Exception) {
        }
    }

    @Synchronized
    fun folders(c: Context): List<String> {
        ensure(c)
        loadFolders(c)
        val s = LinkedHashSet<String>(extraFolders)
        for (d in docs) if (d.folder.isNotEmpty()) s.add(d.folder)
        return s.toList()
    }

    @Synchronized
    fun addFolder(c: Context, name: String) {
        ensure(c)
        loadFolders(c)
        extraFolders.add(name)
        saveFolders(c)
    }

    @Synchronized
    fun renameFolder(c: Context, old: String, new: String) {
        ensure(c)
        loadFolders(c)
        extraFolders.remove(old)
        extraFolders.add(new)
        for (d in docs) if (d.folder == old) d.folder = new
        saveFolders(c)
        save(c)
    }

    @Synchronized
    fun deleteFolder(c: Context, name: String) {
        ensure(c)
        loadFolders(c)
        extraFolders.remove(name)
        for (d in docs) if (d.folder == name) d.folder = ""
        saveFolders(c)
        save(c)
    }

    @Synchronized
    fun delete(c: Context, d: Doc) {
        ensure(c)
        docs.remove(d)
        file(c, d.id).delete()
        thumbFile(c, d.id).delete()
        inkFile(c, d.id).delete()
        File(File(c.filesDir, "img"), d.id).deleteRecursively()
        save(c)
    }

    @Synchronized
    fun importPdf(c: Context, uri: Uri): Doc? {
        ensure(c)
        try {
            val id = UUID.randomUUID().toString().replace("-", "").substring(0, 12)
            val input = c.contentResolver.openInputStream(uri) ?: return null
            input.use { ins ->
                file(c, id).outputStream().use { out -> ins.copyTo(out) }
            }
            var name = "ملف"
            val cur = c.contentResolver.query(uri, null, null, null, null)
            if (cur != null) {
                cur.use {
                    val idx = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (it.moveToFirst() && idx >= 0) {
                        val n = it.getString(idx)
                        if (n != null) name = n
                    }
                }
            }
            if (name.lowercase().endsWith(".pdf")) name = name.substring(0, name.length - 4)
            val d = Doc(id = id, name = name)
            docs.add(d)
            save(c)
            return d
        } catch (e: Exception) {
            return null
        }
    }

    /** Registers a document whose files (pdf / ink / images) were already written under d.id. */
    fun addDoc(c: Context, d: Doc) {
        ensure(c)
        docs.add(d)
        save(c)
    }

    fun makeThumb(c: Context, d: Doc) {
        try {
            val core = PdfiumCore(c)
            val doc = core.newDocument(file(c, d.id).readBytes())
            val n = core.getPageCount(doc)
            core.openPage(doc, 0)
            val s = core.getPageSize(doc, 0)
            val w = 240
            val h = max(1, (w * s.height.toFloat() / max(1, s.width)).toInt())
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(Color.WHITE)
            core.renderPageBitmap(doc, bmp, 0, 0, 0, w, h, false)
            thumbFile(c, d.id).outputStream().use { out ->
                bmp.compress(Bitmap.CompressFormat.JPEG, 80, out)
            }
            core.closeDocument(doc)
            d.pages = n
            save(c)
        } catch (e: Throwable) {
            lastError = e.javaClass.simpleName + ": " + (e.message ?: "")
        }
    }
}
