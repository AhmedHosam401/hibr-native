package com.hibr.nativeapp

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import java.io.File
import java.util.concurrent.Executors
import kotlin.math.max
import android.widget.EditText
import android.widget.RadioGroup
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.AppCompatRadioButton
import androidx.appcompat.widget.PopupMenu
import android.content.ClipData
import android.content.ClipboardManager
import android.text.Editable
import android.text.TextWatcher
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.ListView
import android.widget.BaseAdapter
import android.app.Dialog
import android.graphics.drawable.ColorDrawable
import android.util.LruCache
import android.widget.ImageView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle

class ViewerActivity : AppCompatActivity(), PdfView.Listener {

    private lateinit var doc: Doc
    private lateinit var pdfView: PdfView
    private lateinit var ink: InkStore
    private lateinit var root: FrameLayout
    private lateinit var topBar: LinearLayout
    private lateinit var scrub: TextView
    private lateinit var dock: LinearLayout
    private lateinit var titleView: TextView
    private lateinit var shareBtn: ImageButton
    private lateinit var searchBtn: ImageButton
    private lateinit var tocBtn: ImageButton
    private var toc: List<TocItem> = emptyList()
    private var skipAnchorSave = false
    private var locked = false
    private var dockPinned = false
    private var fabLong = false
    private lateinit var lockBtn: ImageButton
    private val fabLongRun = Runnable {
        if (!fDragged) {
            fabLong = true
            fab.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
            onFabLong()
        }
    }
    private lateinit var searchField: EditText
    private lateinit var countText: TextView
    private lateinit var prevBtn: ImageButton
    private lateinit var nextBtn: ImageButton
    private lateinit var closeSearchBtn: ImageButton
    private lateinit var selBar: LinearLayout
    private var textIndex: TextIndex? = null
    private var hits: List<Hit> = emptyList()
    private var hitCur = -1
    private var searchOn = false
    private var searchSeq = 0
    private val searchRun = Runnable { runSearch(false) }
    private lateinit var optPanel: LinearLayout
    private lateinit var fab: ImageButton
    private lateinit var undoBtn: ImageButton
    private lateinit var redoBtn: ImageButton
    private lateinit var shapeBtn: ImageButton
    private val toolBtns = HashMap<Int, ImageButton>()

    private var barsOn = true
    private var topInset = 0
    private var botInset = 0
    private var leftInset = 0
    private var rightInset = 0
    private var frac = 0f
    private var scrubDragging = false

    private var tool = Tool.PEN
    private var penColor = 0
    private var hlColor = 0
    private var penSize = 3
    private var hlSize = 4

    private val penColors = intArrayOf(
        0xFFD6336C.toInt(), 0xFF1C7ED6.toInt(), 0xFF2B8A3E.toInt(), 0xFF212529.toInt(), 0xFFF08C00.toInt()
    )
    private val hlColors = intArrayOf(
        0xFFFFE600.toInt(), 0xFF8CE99A.toInt(), 0xFF74C0FC.toInt(), 0xFFFFA8A8.toInt(), 0xFFFFD8A8.toInt()
    )

    private val handler = Handler(Looper.getMainLooper())
    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) addImage(uri)
    }
    private val io = Executors.newSingleThreadExecutor()
    private val hideScrub = Runnable {
        if (!barsOn && !scrubDragging) scrub.animate().alpha(0f).setDuration(200).start()
    }
    private val saveRunnable = Runnable { if (::ink.isInitialized) ink.save() }

    // floating button drag state
    private var fDownX = 0f
    private var fDownY = 0f
    private var fStartX = 0f
    private var fStartY = 0f
    private var fDragged = false
    private var fabHomeX = 0f
    private var fabShifted = false
    private var fabRight = false
    private var fabYFrac = 0.45f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = intent.getStringExtra("id")
        val d = if (id != null) Library.find(this, id) else null
        if (d == null || !Library.file(this, d.id).exists()) {
            finish()
            return
        }
        doc = d
        doc.openedAt = System.currentTimeMillis()
        ink = InkStore(this, doc.id)
        ink.load()

        val prefs = getSharedPreferences("tools", MODE_PRIVATE)
        penColor = prefs.getInt("penColor", penColors[0])
        hlColor = prefs.getInt("hlColor", hlColors[0])
        penSize = prefs.getInt("penSize", 3)
        hlSize = prefs.getInt("hlSize", 4)

        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }
        hideSystemBars()

        root = FrameLayout(this)
        root.setBackgroundColor(color(R.color.viewer_bg))

        pdfView = PdfView(this)
        pdfView.bgColor = color(R.color.viewer_bg)
        pdfView.listener = this
        pdfView.ink = ink
        pdfView.pageNight = getSharedPreferences("settings", MODE_PRIVATE).getBoolean("pageNight", false)
        pdfView.imgDir = Library.imgDir(this, doc.id)
        pdfView.onTextEdit = { t, col, sz ->
            showTextDialog(t, col, sz) { nt, nc, ns -> pdfView.updateSelectedText(nt, nc, ns) }
        }
        pdfView.shapeOn = prefs.getBoolean("shapeOn", true)
        root.addView(pdfView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        buildTopBar()
        buildScrub()
        buildDock()
        buildOptions()
        buildSelBar()
        handler.postDelayed({ ensureTextIndex() }, 2500)
        buildFab()
        applyTool()

        ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            topInset = b.top
            botInset = b.bottom
            leftInset = b.left
            rightInset = b.right
            val lp = topBar.layoutParams
            lp.height = dp(56) + b.top
            topBar.layoutParams = lp
            topBar.setPadding(b.left + dp(4), b.top, b.right + dp(4), 0)
            topBar.animate().cancel()
            topBar.translationY = topBarOffset(barsOn)
            if (barsOn) pdfView.setTopSlack(lp.height.toFloat(), false)
            val sl = scrub.layoutParams as FrameLayout.LayoutParams
            sl.marginStart = b.left + dp(6)
            scrub.layoutParams = sl
            val dl = dock.layoutParams as FrameLayout.LayoutParams
            dl.bottomMargin = dp(16) + b.bottom
            dock.layoutParams = dl
            val ol = optPanel.layoutParams as FrameLayout.LayoutParams
            ol.bottomMargin = dp(16 + 56 + 8) + b.bottom
            optPanel.layoutParams = ol
            positionScrub()
            root.post { placeFab() }
            insets
        }

        setContentView(root)
        root.post {
            positionScrub()
            if (barsOn) pdfView.setTopSlack((dp(56) + topInset).toFloat(), false)
            placeFab()
        }
        root.addOnLayoutChangeListener { _, l, t, r, b, ol, ot, orr, ob ->
            if (r - l != orr - ol || b - t != ob - ot) {
                placeFab()
                positionScrub()
            }
        }
        updateUndoRedo()
        pdfView.open(Library.file(this, doc.id), doc.lastPage, doc.lastFrac)
    }

    // ------------------------------------------------------------ UI building

    private fun buildTopBar() {
        topBar = LinearLayout(this)
        topBar.orientation = LinearLayout.HORIZONTAL
        topBar.gravity = Gravity.CENTER_VERTICAL
        topBar.layoutDirection = View.LAYOUT_DIRECTION_LTR
        topBar.setBackgroundColor(color(R.color.surface))
        topBar.elevation = dp(4).toFloat()
        val back = ImageButton(this)
        back.setImageResource(R.drawable.ic_back)
        back.setBackgroundResource(R.drawable.ripple_circle)
        back.setColorFilter(color(R.color.ink))
        back.setOnClickListener { finish() }
        val title = TextView(this)
        title.text = doc.name
        title.setTextColor(color(R.color.ink))
        title.textSize = 17f
        title.setTypeface(title.typeface, Typeface.BOLD)
        title.maxLines = 1
        title.ellipsize = TextUtils.TruncateAt.END
        val share = ImageButton(this)
        share.setImageResource(R.drawable.ic_more)
        share.setBackgroundResource(R.drawable.ripple_circle)
        share.setColorFilter(color(R.color.ink))
        share.setOnClickListener { showMoreMenu(share) }
        titleView = title
        shareBtn = share
        searchBtn = smallIcon(R.drawable.ic_search, true) { openSearch() }
        tocBtn = smallIcon(R.drawable.ic_toc, false) { showToc() }
        searchField = EditText(this)
        searchField.hint = "بحث في الملف"
        searchField.setSingleLine(true)
        searchField.imeOptions = EditorInfo.IME_ACTION_SEARCH
        searchField.setTextColor(color(R.color.ink))
        searchField.setHintTextColor(color(R.color.muted))
        searchField.textSize = 16f
        searchField.background = null
        searchField.visibility = View.GONE
        searchField.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                handler.removeCallbacks(searchRun)
                handler.postDelayed(searchRun, 350)
            }
        })
        searchField.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                handler.removeCallbacks(searchRun)
                runSearch(false)
                hideKeyboard()
                true
            } else {
                false
            }
        }
        countText = TextView(this)
        countText.setTextColor(color(R.color.muted))
        countText.textSize = 13f
        countText.visibility = View.GONE
        prevBtn = smallIcon(R.drawable.ic_up, false) { stepHit(-1) }
        nextBtn = smallIcon(R.drawable.ic_down, false) { stepHit(1) }
        closeSearchBtn = smallIcon(R.drawable.ic_close, false) { closeSearch() }
        topBar.addView(back, LinearLayout.LayoutParams(dp(48), dp(48)))
        val tlp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        tlp.marginStart = dp(8)
        topBar.addView(title, tlp)
        val slp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        slp.marginStart = dp(8)
        topBar.addView(searchField, slp)
        topBar.addView(countText, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        topBar.addView(prevBtn, LinearLayout.LayoutParams(dp(40), dp(48)))
        topBar.addView(nextBtn, LinearLayout.LayoutParams(dp(40), dp(48)))
        topBar.addView(tocBtn, LinearLayout.LayoutParams(dp(48), dp(48)))
        topBar.addView(searchBtn, LinearLayout.LayoutParams(dp(48), dp(48)))
        topBar.addView(share, LinearLayout.LayoutParams(dp(48), dp(48)))
        topBar.addView(closeSearchBtn, LinearLayout.LayoutParams(dp(48), dp(48)))
        root.addView(topBar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)))
    }

    private fun buildScrub() {
        scrub = TextView(this)
        scrub.text = "1 / 1"
        scrub.setTextColor(Color.WHITE)
        scrub.textSize = 13f
        scrub.gravity = Gravity.CENTER
        scrub.layoutDirection = View.LAYOUT_DIRECTION_LTR
        scrub.setPadding(dp(10), 0, dp(10), 0)
        val sbg = GradientDrawable()
        sbg.setColor(0x99000000.toInt())
        sbg.cornerRadius = dp(15).toFloat()
        scrub.background = sbg
        val slp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(30), Gravity.TOP or Gravity.START)
        slp.marginStart = dp(6)
        root.addView(scrub, slp)
        scrub.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    scrubDragging = true
                    dragTo(e.rawY)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    dragTo(e.rawY)
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    scrubDragging = false
                    handler.removeCallbacks(hideScrub)
                    if (!barsOn) handler.postDelayed(hideScrub, 1200)
                    true
                }
                else -> false
            }
        }
    }

    private fun smallIcon(res: Int, visible: Boolean, onClick: () -> Unit): ImageButton {
        val b = ImageButton(this)
        b.setImageResource(res)
        b.setBackgroundResource(R.drawable.ripple_circle)
        b.setColorFilter(color(R.color.ink))
        b.setOnClickListener { onClick() }
        if (!visible) b.visibility = View.GONE
        return b
    }

    private fun hideKeyboard() {
        val im = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        im.hideSoftInputFromWindow(searchField.windowToken, 0)
    }

    private fun ensureTextIndex() {
        if (textIndex != null) return
        val f = Library.file(this, doc.id)
        if (!f.exists() || f.length() > 200L * 1024 * 1024) return
        val ti = TextIndex(this, f)
        textIndex = ti
        pdfView.textIndex = ti
        ti.start { runOnUiThread { onIndexProgress() } }
    }

    private fun onIndexProgress() {
        if (!searchOn) return
        val ti = textIndex ?: return
        if (searchField.text.isNotBlank()) {
            handler.removeCallbacks(searchRun)
            handler.postDelayed({ runSearch(true) }, 500)
        } else {
            updateCount()
        }
        if (ti.finished) updateCount()
    }

    private fun updateCount() {
        val ti = textIndex
        if (hits.isNotEmpty()) {
            countText.text = (hitCur + 1).toString() + "/" + hits.size
        } else if (ti != null && ti.failed) {
            countText.text = "تعذّر قراءة النص"
        } else if (ti != null && !ti.finished && ti.total > 0) {
            countText.text = "تحليل " + (ti.done * 100 / ti.total) + "%"
        } else if (searchField.text.isNotBlank()) {
            countText.text = "0"
        } else {
            countText.text = ""
        }
    }

    private fun openSearch() {
        ensureTextIndex()
        searchOn = true
        setBars(true)
        titleView.visibility = View.GONE
        shareBtn.visibility = View.GONE
        searchBtn.visibility = View.GONE
        tocBtn.visibility = View.GONE
        searchField.visibility = View.VISIBLE
        countText.visibility = View.VISIBLE
        prevBtn.visibility = View.VISIBLE
        nextBtn.visibility = View.VISIBLE
        closeSearchBtn.visibility = View.VISIBLE
        updateCount()
        searchField.requestFocus()
        val im = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        im.showSoftInput(searchField, InputMethodManager.SHOW_IMPLICIT)
    }

    private fun closeSearch() {
        searchOn = false
        searchSeq++
        handler.removeCallbacks(searchRun)
        hideKeyboard()
        searchField.setText("")
        searchField.clearFocus()
        hits = emptyList()
        hitCur = -1
        pdfView.setHits(emptyList(), -1)
        titleView.visibility = View.VISIBLE
        shareBtn.visibility = View.VISIBLE
        searchBtn.visibility = View.VISIBLE
        tocBtn.visibility = if (toc.isNotEmpty()) View.VISIBLE else View.GONE
        searchField.visibility = View.GONE
        countText.visibility = View.GONE
        prevBtn.visibility = View.GONE
        nextBtn.visibility = View.GONE
        closeSearchBtn.visibility = View.GONE
    }

    private fun runSearch(fromProgress: Boolean) {
        val ti = textIndex ?: return
        val q = searchField.text.toString()
        val seq = ++searchSeq
        io.execute {
            val res = ti.search(q)
            runOnUiThread {
                if (seq != searchSeq || !searchOn) return@runOnUiThread
                hits = res
                if (res.isEmpty()) {
                    hitCur = -1
                    pdfView.setHits(res, -1)
                } else if (!fromProgress || hitCur < 0) {
                    val cp = pdfView.currentPage()
                    var k = res.indexOfFirst { it.page >= cp }
                    if (k < 0) k = 0
                    hitCur = k
                    pdfView.setHits(res, k)
                    pdfView.goToHit(k)
                } else {
                    hitCur = hitCur.coerceIn(0, res.size - 1)
                    pdfView.setHits(res, hitCur)
                }
                updateCount()
            }
        }
    }

    private fun stepHit(d: Int) {
        if (hits.isEmpty()) return
        hitCur = (hitCur + d + hits.size) % hits.size
        pdfView.setCurrentHit(hitCur)
        pdfView.goToHit(hitCur)
        updateCount()
    }

    private fun buildSelBar() {
        selBar = LinearLayout(this)
        selBar.orientation = LinearLayout.HORIZONTAL
        selBar.gravity = Gravity.CENTER_VERTICAL
        selBar.layoutDirection = View.LAYOUT_DIRECTION_LTR
        selBar.background = roundBg(24)
        selBar.elevation = dp(8).toFloat()
        selBar.setPadding(dp(6), dp(4), dp(6), dp(4))
        selBar.visibility = View.GONE
        selBar.addView(selChip("نسخ") { copySelection() })
        selBar.addView(selChip("تظليل") { pdfView.highlightSelection(hlColor) })
        selBar.addView(selChip("✕") { pdfView.clearTextSelection() })
        val lp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        lp.topMargin = topInset + dp(72)
        root.addView(selBar, lp)
    }

    private fun selChip(label: String, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = label
        t.setTextColor(color(R.color.accent))
        t.textSize = 15f
        t.setTypeface(t.typeface, Typeface.BOLD)
        t.setPadding(dp(16), dp(10), dp(16), dp(10))
        t.setOnClickListener { onClick() }
        return t
    }

    private fun copySelection() {
        val t = pdfView.selectionText()
        if (t.isNotEmpty()) {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("hibr", t))
            Toast.makeText(this, "تم النسخ", Toast.LENGTH_SHORT).show()
        }
        pdfView.clearTextSelection()
    }

    private fun roundBg(radiusDp: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color(R.color.surface))
        g.cornerRadius = dp(radiusDp).toFloat()
        g.setStroke(dp(1), color(R.color.line))
        return g
    }

    private fun toolButton(res: Int, t: Int): ImageButton {
        val b = ImageButton(this)
        b.setImageResource(res)
        b.setColorFilter(color(R.color.ink))
        b.setOnClickListener {
            if (tool == t && pdfView.drawMode) {
                if (t != Tool.ERASER && t != Tool.SELECT) toggleOptions(t)
            } else {
                tool = t
                setDrawMode(true)
                applyTool()
                hideOptions()
            }
        }
        toolBtns[t] = b
        return b
    }

    private fun plainButton(res: Int, onClick: () -> Unit): ImageButton {
        val b = ImageButton(this)
        b.setImageResource(res)
        b.setBackgroundResource(R.drawable.ripple_circle)
        b.setColorFilter(color(R.color.ink))
        b.setOnClickListener { onClick() }
        return b
    }

    private fun buildDock() {
        dock = LinearLayout(this)
        dock.orientation = LinearLayout.HORIZONTAL
        dock.gravity = Gravity.CENTER_VERTICAL
        dock.layoutDirection = View.LAYOUT_DIRECTION_LTR
        dock.background = roundBg(28)
        dock.elevation = dp(8).toFloat()
        dock.setPadding(dp(8), dp(4), dp(8), dp(4))
        dock.addView(toolButton(R.drawable.ic_pen, Tool.PEN), LinearLayout.LayoutParams(dp(33), dp(33)))
        dock.addView(toolButton(R.drawable.ic_highlighter, Tool.HL), LinearLayout.LayoutParams(dp(33), dp(33)))
        dock.addView(toolButton(R.drawable.ic_eraser, Tool.ERASER), LinearLayout.LayoutParams(dp(33), dp(33)))
        dock.addView(toolButton(R.drawable.ic_lasso, Tool.SELECT), LinearLayout.LayoutParams(dp(33), dp(33)))
        shapeBtn = plainButton(R.drawable.ic_shapes) { toggleShapes() }
        dock.addView(shapeBtn, LinearLayout.LayoutParams(dp(33), dp(33)))
        refreshShapeBtn()
        val imageBtn = plainButton(R.drawable.ic_image) { pickImage.launch("image/*") }
        dock.addView(imageBtn, LinearLayout.LayoutParams(dp(33), dp(33)))
        val textBtn = plainButton(R.drawable.ic_text) {
            showTextDialog("", penColors[3], 0.036f) { t, col, sz -> pdfView.insertText(t, col, sz) }
        }
        dock.addView(textBtn, LinearLayout.LayoutParams(dp(33), dp(33)))
        val sep = View(this)
        sep.setBackgroundColor(color(R.color.line))
        val splp = LinearLayout.LayoutParams(dp(1), dp(24))
        splp.marginStart = dp(6)
        splp.marginEnd = dp(6)
        dock.addView(sep, splp)
        undoBtn = plainButton(R.drawable.ic_undo) { pdfView.undoInk() }
        redoBtn = plainButton(R.drawable.ic_redo) { pdfView.redoInk() }
        dock.addView(undoBtn, LinearLayout.LayoutParams(dp(33), dp(33)))
        dock.addView(redoBtn, LinearLayout.LayoutParams(dp(33), dp(33)))
        lockBtn = plainButton(R.drawable.ic_lock) { toggleLock() }
        dock.addView(lockBtn, LinearLayout.LayoutParams(dp(33), dp(33)))
        val dlp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        dlp.bottomMargin = dp(16)
        root.addView(dock, dlp)
    }

    private fun buildOptions() {
        optPanel = LinearLayout(this)
        optPanel.orientation = LinearLayout.HORIZONTAL
        optPanel.gravity = Gravity.CENTER_VERTICAL
        optPanel.layoutDirection = View.LAYOUT_DIRECTION_LTR
        optPanel.background = roundBg(24)
        optPanel.elevation = dp(8).toFloat()
        optPanel.setPadding(dp(10), dp(6), dp(10), dp(6))
        optPanel.visibility = View.GONE
        val olp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        olp.bottomMargin = dp(16 + 56 + 8)
        root.addView(optPanel, olp)
    }

    private fun buildFab() {
        fab = ImageButton(this)
        fab.setImageResource(R.drawable.ic_pen)
        fab.elevation = dp(6).toFloat()
        setFabStyle()
        root.addView(fab, FrameLayout.LayoutParams(dp(54), dp(54), Gravity.TOP or Gravity.START))
        fab.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    fDownX = e.rawX
                    fDownY = e.rawY
                    fStartX = v.x
                    fStartY = v.y
                    fDragged = false
                    fabLong = false
                    handler.removeCallbacks(fabLongRun)
                    handler.postDelayed(fabLongRun, 450)
                    v.animate().cancel()
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - fDownX
                    val dy = e.rawY - fDownY
                    if (!fDragged && dx * dx + dy * dy > dp(8) * dp(8)) fDragged = true
                    if (fDragged) {
                        handler.removeCallbacks(fabLongRun)
                        val maxX = max(0f, (root.width - v.width).toFloat())
                        val minY = fabMinY()
                        val maxY = fabMaxY()
                        v.x = (fStartX + dx).coerceIn(0f, maxX)
                        v.y = (fStartY + dy).coerceIn(minY, maxY)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    handler.removeCallbacks(fabLongRun)
                    val was = fDragged
                    fDragged = false
                    if (fabLong) {
                        fabLong = false
                    } else if (was) {
                        snapFab()
                    } else {
                        toggleDraw()
                    }
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(fabLongRun)
                    val was = fDragged
                    fDragged = false
                    fabLong = false
                    if (was) snapFab()
                    true
                }
                else -> false
            }
        }
    }

    private fun setFabStyle() {
        val on = pdfView.drawMode
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(if (on) color(R.color.accent) else color(R.color.surface))
        g.setStroke(dp(1), color(R.color.line))
        fab.background = g
        fab.setColorFilter(if (on) color(R.color.on_accent) else color(R.color.ink))
    }

    private fun fabMinY(): Float = (topInset + dp(60)).toFloat()

    private fun fabMaxY(): Float {
        val fh = if (fab.height > 0) fab.height else dp(54)
        return max(fabMinY(), (root.height - fh - dp(90)).toFloat())
    }

    /** Puts the floating button back where it belongs (side + relative height) after a rotation / size change. */
    private fun placeFab() {
        if (!::fab.isInitialized || !::root.isInitialized) return
        if (root.width == 0 || root.height == 0 || fDragged) return
        val w = if (fab.width > 0) fab.width else dp(54)
        fab.animate().cancel()
        fabHomeX = if (fabRight) (root.width - w - rightInset - dp(8)).toFloat() else (leftInset + dp(8)).toFloat()
        fabShifted = false
        fab.x = fabHomeX
        fab.y = fabMinY() + fabYFrac * (fabMaxY() - fabMinY())
        avoidScrub()
    }

    private fun snapFab() {
        val center = fab.x + fab.width / 2f
        fabRight = center >= root.width / 2f
        fabYFrac = ((fab.y - fabMinY()) / max(1f, fabMaxY() - fabMinY())).coerceIn(0f, 1f)
        fabHomeX = if (!fabRight) (leftInset + dp(8)).toFloat() else (root.width - fab.width - rightInset - dp(8)).toFloat()
        fabShifted = false
        fab.animate().x(fabHomeX).setDuration(180).start()
        handler.postDelayed({ avoidScrub() }, 220)
    }

    private fun avoidScrub() {
        if (!::fab.isInitialized || !::scrub.isInitialized || fDragged) return
        if (scrub.width == 0) return
        val visible = scrub.alpha > 0.3f
        val sTop = scrub.translationY
        val overlapY = fab.y + fab.height + dp(8) > sTop && fab.y - dp(8) < sTop + scrub.height
        val overlapX = fabHomeX < scrub.right + dp(8) && fabHomeX + fab.width + dp(8) > scrub.left
        val want = if (visible && overlapY && overlapX) (scrub.right + dp(12)).toFloat() else fabHomeX
        val ok = want + fab.width < root.width - 4
        val target = if (ok) want else fabHomeX
        val shifted = target != fabHomeX
        if (shifted != fabShifted) {
            fabShifted = shifted
            fab.animate().x(target).setDuration(220).start()
        }
    }

    // ------------------------------------------------------------ tools

    private fun toggleDraw() {
        setDrawMode(!pdfView.drawMode)
        if (pdfView.drawMode) applyTool()
    }

    private fun setDrawMode(on: Boolean) {
        pdfView.drawMode = on
        setFabStyle()
        refreshTools()
        if (!on) hideOptions()
    }

    private fun applyTool() {
        pdfView.tool = tool
        pdfView.color = if (tool == Tool.HL) hlColor else penColor
        pdfView.penWidth = 0.0012f + penSize * 0.0008f
        pdfView.hlWidth = 0.006f + hlSize * 0.0035f
        refreshTools()
    }

    private fun circleBg(c: Int): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(c)
        return g
    }

    private fun refreshTools() {
        for ((t, b) in toolBtns) {
            if (t == tool && pdfView.drawMode) {
                b.background = circleBg(color(R.color.accent_container))
            } else {
                b.setBackgroundResource(R.drawable.ripple_circle)
            }
        }
    }

    private fun toggleShapes() {
        pdfView.shapeOn = !pdfView.shapeOn
        getSharedPreferences("tools", MODE_PRIVATE).edit().putBoolean("shapeOn", pdfView.shapeOn).apply()
        refreshShapeBtn()
    }

    private fun refreshShapeBtn() {
        if (pdfView.shapeOn) {
            shapeBtn.background = circleBg(color(R.color.accent_container))
        } else {
            shapeBtn.setBackgroundResource(R.drawable.ripple_circle)
        }
    }

    private fun hideOptions() {
        optPanel.visibility = View.GONE
    }

    private fun toggleOptions(t: Int) {
        if (optPanel.visibility == View.VISIBLE) {
            hideOptions()
        } else {
            buildSwatches(t)
        }
    }

    private fun buildSwatches(t: Int) {
        optPanel.removeAllViews()
        val cols = if (t == Tool.HL) hlColors else penColors
        val cur = if (t == Tool.HL) hlColor else penColor
        val prefs = getSharedPreferences("tools", MODE_PRIVATE)
        for (c in cols) {
            val v = View(this)
            val g = GradientDrawable()
            g.shape = GradientDrawable.OVAL
            g.setColor(c)
            g.setStroke(dp(if (c == cur) 3 else 1), if (c == cur) color(R.color.accent) else color(R.color.line))
            v.background = g
            v.setOnClickListener {
                if (t == Tool.HL) hlColor = c else penColor = c
                prefs.edit().putInt("penColor", penColor).putInt("hlColor", hlColor).apply()
                applyTool()
                buildSwatches(t)
            }
            val lp = LinearLayout.LayoutParams(dp(30), dp(30))
            lp.marginStart = dp(5)
            lp.marginEnd = dp(5)
            optPanel.addView(v, lp)
        }
        val sb = SeekBar(this)
        sb.max = 9
        sb.progress = (if (t == Tool.HL) hlSize else penSize) - 1
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (t == Tool.HL) hlSize = progress + 1 else penSize = progress + 1
                applyTool()
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                prefs.edit().putInt("penSize", penSize).putInt("hlSize", hlSize).apply()
            }
        })
        optPanel.addView(sb, LinearLayout.LayoutParams(dp(130), dp(36)))
        optPanel.visibility = View.VISIBLE
    }

    private fun updateUndoRedo() {
        if (!::undoBtn.isInitialized) return
        undoBtn.alpha = if (ink.canUndo()) 1f else 0.35f
        redoBtn.alpha = if (ink.canRedo()) 1f else 0.35f
    }

    // ------------------------------------------------------------ export

    // ---- pages: thumbnails + delete / add blank / move

    private class PageVH(val box: FrameLayout, val img: ImageView, val num: TextView) : RecyclerView.ViewHolder(box)

    private fun showPages() {
        val n = pdfView.pageCount()
        if (n == 0) return
        val dlg = Dialog(this, android.R.style.Theme_DeviceDefault_NoActionBar)
        val sel = java.util.TreeSet<Int>()
        val cur = pdfView.currentPage()
        val cache = object : LruCache<Int, Bitmap>(24 * 1024 * 1024) {
            override fun sizeOf(key: Int, value: Bitmap): Int = value.byteCount
        }

        val column = LinearLayout(this)
        column.orientation = LinearLayout.VERTICAL
        column.setBackgroundColor(color(R.color.bg))
        ViewCompat.setOnApplyWindowInsetsListener(column) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            insets
        }

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.layoutDirection = View.LAYOUT_DIRECTION_LTR
        head.setBackgroundColor(color(R.color.surface))
        val title = TextView(this)
        title.setTextColor(color(R.color.ink))
        title.textSize = 17f
        title.setTypeface(title.typeface, Typeface.BOLD)
        head.addView(smallIcon(R.drawable.ic_close, true) { dlg.dismiss() }, LinearLayout.LayoutParams(dp(48), dp(56)))
        val tl = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        tl.marginStart = dp(8)
        head.addView(title, tl)
        column.addView(head, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)))

        val actions = LinearLayout(this)
        actions.orientation = LinearLayout.HORIZONTAL
        actions.gravity = Gravity.CENTER
        actions.layoutDirection = View.LAYOUT_DIRECTION_LTR
        actions.setBackgroundColor(color(R.color.surface))
        actions.visibility = View.GONE
        column.addView(actions, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val rv = RecyclerView(this)
        val land = resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
        val span = if (land) 5 else 3
        rv.layoutManager = GridLayoutManager(this, span)
        rv.setPadding(dp(6), dp(6), dp(6), dp(6))
        rv.clipToPadding = false
        column.addView(rv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        val itemW = (resources.displayMetrics.widthPixels - dp(12) - span * dp(8)) / span

        fun updateHeader() {
            title.text = if (sel.isEmpty()) "الصفحات ($n)" else sel.size.toString() + " محددة"
            actions.visibility = if (sel.isEmpty()) View.GONE else View.VISIBLE
        }

        fun toggle(p: Int) {
            if (!sel.add(p)) sel.remove(p)
            rv.adapter?.notifyDataSetChanged()
            updateHeader()
        }

        rv.adapter = object : RecyclerView.Adapter<PageVH>() {
            override fun getItemCount(): Int = n

            override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PageVH {
                val box = FrameLayout(this@ViewerActivity)
                val img = ImageView(this@ViewerActivity)
                img.scaleType = ImageView.ScaleType.FIT_CENTER
                img.setBackgroundColor(Color.WHITE)
                val ilp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                ilp.setMargins(dp(3), dp(3), dp(3), dp(3))
                box.addView(img, ilp)
                val num = TextView(this@ViewerActivity)
                num.setTextColor(Color.WHITE)
                num.textSize = 12f
                num.setPadding(dp(8), dp(2), dp(8), dp(2))
                val nb = GradientDrawable()
                nb.setColor(0xB0000000.toInt())
                nb.cornerRadius = dp(10).toFloat()
                num.background = nb
                val nlp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.START)
                nlp.setMargins(dp(8), 0, 0, dp(8))
                box.addView(num, nlp)
                val lp = RecyclerView.LayoutParams(itemW, (itemW * 1.35f).toInt())
                lp.setMargins(dp(4), dp(4), dp(4), dp(4))
                box.layoutParams = lp
                return PageVH(box, img, num)
            }

            override fun onBindViewHolder(h: PageVH, position: Int) {
                val selected = sel.contains(position)
                h.num.text = if (selected) "✓ " + (position + 1) else (position + 1).toString()
                h.img.tag = position
                val b = cache.get(position)
                if (b != null) {
                    h.img.setImageBitmap(b)
                } else {
                    h.img.setImageDrawable(null)
                    pdfView.renderThumb(position, 260) { bmp ->
                        if (bmp != null) {
                            cache.put(position, bmp)
                            if (h.img.tag == position) h.img.setImageBitmap(bmp)
                        }
                    }
                }
                val g = GradientDrawable()
                g.setColor(color(R.color.surface))
                g.cornerRadius = dp(6).toFloat()
                if (selected) {
                    g.setStroke(dp(3), color(R.color.accent))
                } else if (position == cur) {
                    g.setStroke(dp(2), color(R.color.muted))
                } else {
                    g.setStroke(dp(1), color(R.color.line))
                }
                h.box.background = g
                h.box.setOnClickListener {
                    if (sel.isNotEmpty()) {
                        toggle(position)
                    } else {
                        dlg.dismiss()
                        pdfView.goToPage(position)
                    }
                }
                h.box.setOnLongClickListener {
                    toggle(position)
                    true
                }
            }
        }

        val del = selChip("حذف") {
            if (sel.size >= n) {
                Toast.makeText(this, "لا يمكن حذف كل الصفحات", Toast.LENGTH_SHORT).show()
            } else {
                AlertDialog.Builder(this)
                    .setTitle("حذف الصفحات؟")
                    .setMessage("سيتم حذف " + sel.size + " صفحة مع أي رسم أو نص عليها. لا يمكن التراجع.")
                    .setPositiveButton("حذف") { _, _ ->
                        val order = ArrayList<Int>()
                        for (i in 0 until n) if (!sel.contains(i)) order.add(i)
                        val target = Math.min(sel.first(), order.size - 1)
                        dlg.dismiss()
                        applyPageOrder(order.toIntArray(), target)
                    }
                    .setNegativeButton("إلغاء", null)
                    .show()
            }
        }
        del.setTextColor(0xFFE03131.toInt())
        actions.addView(del)
        actions.addView(selChip("صفحة بيضاء بعدها") {
            if (sel.size != 1) {
                Toast.makeText(this, "اختار صفحة واحدة", Toast.LENGTH_SHORT).show()
            } else {
                val p = sel.first()
                val o = ArrayList<Int>()
                for (i in 0..p) o.add(i)
                o.add(-(p + 1))
                for (i in p + 1 until n) o.add(i)
                dlg.dismiss()
                applyPageOrder(o.toIntArray(), p + 1)
            }
        })
        actions.addView(selChip("نقل إلى…") {
            if (sel.size != 1) {
                Toast.makeText(this, "اختار صفحة واحدة", Toast.LENGTH_SHORT).show()
            } else {
                askMove(sel.first(), n) { k ->
                    val l = ArrayList<Int>()
                    for (i in 0 until n) l.add(i)
                    val p = sel.first()
                    l.removeAt(p)
                    l.add(k, p)
                    dlg.dismiss()
                    applyPageOrder(l.toIntArray(), k)
                }
            }
        })
        actions.addView(selChip("إلغاء") {
            sel.clear()
            rv.adapter?.notifyDataSetChanged()
            updateHeader()
        })

        updateHeader()
        dlg.setContentView(column)
        dlg.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        dlg.window?.setBackgroundDrawable(ColorDrawable(color(R.color.bg)))
        dlg.show()
    }

    private fun askMove(p: Int, n: Int, onOk: (Int) -> Unit) {
        val et = EditText(this)
        et.hint = "رقم المكان الجديد (1 - " + n + ")"
        et.inputType = android.text.InputType.TYPE_CLASS_NUMBER
        et.setTextColor(color(R.color.ink))
        et.setHintTextColor(color(R.color.muted))
        val box = FrameLayout(this)
        box.setPadding(dp(22), dp(8), dp(22), 0)
        box.addView(et)
        AlertDialog.Builder(this)
            .setTitle("نقل الصفحة " + (p + 1))
            .setView(box)
            .setPositiveButton("نقل") { _, _ ->
                val v = et.text.toString().trim().toIntOrNull()
                if (v == null || v < 1 || v > n || v - 1 == p) {
                    Toast.makeText(this, "رقم غير صالح", Toast.LENGTH_SHORT).show()
                } else {
                    onOk(v - 1)
                }
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    /** order[k] = old page index shown at new position k; a negative value -(r+1) inserts a blank page sized like old page r. */
    private fun applyPageOrder(order: IntArray, target: Int) {
        handler.removeCallbacks(saveRunnable)
        val busy = AlertDialog.Builder(this).setMessage("جاري تعديل الملف...").setCancelable(false).create()
        busy.show()
        io.execute {
            try {
                ink.save()
                val f = Library.file(this, doc.id)
                val tmp = File(f.parentFile, f.name + ".tmp")
                PDFBoxResourceLoader.init(applicationContext)
                val pd = PDDocument.load(f, MemoryUsageSetting.setupTempFileOnly())
                try {
                    val tree = pd.pages
                    val old = ArrayList<PDPage>()
                    for (p in tree) old.add(p)
                    for (p in old) {
                        p.mediaBox = p.mediaBox
                        p.cropBox = p.cropBox
                        p.rotation = p.rotation
                        val r = p.resources
                        if (r != null) p.resources = r
                    }
                    val fresh = ArrayList<PDPage>()
                    for (o in order) {
                        if (o >= 0) {
                            fresh.add(old[o])
                        } else {
                            val ref = old[-(o + 1)]
                            val box = ref.cropBox
                            val np = PDPage(PDRectangle(box.width, box.height))
                            np.rotation = ref.rotation
                            fresh.add(np)
                        }
                    }
                    for (k in old.indices) tree.remove(0)
                    if (tree.count != 0) throw IllegalStateException("page tree")
                    for (p in fresh) tree.add(p)
                    pd.save(tmp)
                } finally {
                    pd.close()
                }
                // make sure the rewritten file is sound before it replaces the original
                val chk = PDDocument.load(tmp, MemoryUsageSetting.setupTempFileOnly())
                try {
                    if (chk.numberOfPages != order.size) throw IllegalStateException("page count")
                } finally {
                    chk.close()
                }
                java.nio.file.Files.move(tmp.toPath(), f.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING)
                Library.makeThumb(this, doc)
                runOnUiThread {
                    ink.remap(order)
                    ink.save()
                    doc.lastPage = target
                    doc.lastFrac = 0f
                    Library.save(this)
                    skipAnchorSave = true
                    busy.dismiss()
                    recreate()
                }
            } catch (e: Throwable) {
                try {
                    File(Library.file(this, doc.id).parentFile, Library.file(this, doc.id).name + ".tmp").delete()
                } catch (e2: Throwable) {
                }
                runOnUiThread {
                    busy.dismiss()
                    Toast.makeText(this, "تعذر تعديل الملف", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun showMoreMenu(anchor: View) {
        val pm = PopupMenu(this, anchor)
        pm.menu.add(0, 1, 0, "مشاركة PDF")
        pm.menu.add(0, 3, 1, "الصفحات")
        val night = pm.menu.add(0, 2, 2, "وضع ليلي للصفحات")
        night.isCheckable = true
        night.isChecked = pdfView.pageNight
        pm.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> exportAndShare()
                3 -> showPages()
                2 -> {
                    val on = !pdfView.pageNight
                    pdfView.pageNight = on
                    getSharedPreferences("settings", MODE_PRIVATE).edit().putBoolean("pageNight", on).apply()
                }
            }
            true
        }
        pm.show()
    }

    private fun exportAndShare() {
        ink.save()
        Toast.makeText(this, "جاري التجهيز...", Toast.LENGTH_SHORT).show()
        io.execute {
            try {
                val f = Exporter.prepare(this, doc)
                runOnUiThread { shareFile(f) }
            } catch (e: Throwable) {
                val msg = e.javaClass.simpleName + ": " + (e.message ?: "")
                runOnUiThread { Toast.makeText(this, "تعذر التصدير\n" + msg, Toast.LENGTH_LONG).show() }
            }
        }
    }

    private fun shareFile(f: File) {
        try {
            val uri = FileProvider.getUriForFile(this, "$packageName.files", f)
            val i = Intent(Intent.ACTION_SEND)
            i.type = "application/pdf"
            i.putExtra(Intent.EXTRA_STREAM, uri)
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(i, doc.name))
        } catch (e: Exception) {
            Toast.makeText(this, "تعذرت المشاركة", Toast.LENGTH_SHORT).show()
        }
    }

    // ------------------------------------------------------------ system / bars / scrub

    private fun hideSystemBars() {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    private fun trackTop(): Float = (topInset + dp(64)).toFloat()

    private fun trackH(): Float = max(1f, root.height - trackTop() - dp(24))

    private fun positionScrub() {
        if (!::scrub.isInitialized || !::root.isInitialized || root.height == 0) return
        val span = max(0f, trackH() - dp(30))
        scrub.translationY = trackTop() + frac * span
    }

    private fun dragTo(rawY: Float) {
        val loc = IntArray(2)
        root.getLocationOnScreen(loc)
        val y = rawY - loc[1]
        val span = max(1f, trackH() - dp(30))
        val f = ((y - dp(15) - trackTop()) / span).coerceIn(0f, 1f)
        scrub.translationY = trackTop() + f * span
        scrub.alpha = 1f
        pdfView.scrollToFraction(f)
    }

    private fun topBarOffset(on: Boolean): Float = if (on) 0f else -(dp(56) + topInset + dp(8)).toFloat()

    // ---- insert image

    private fun swatchBg(col: Int, selected: Boolean): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(col)
        g.setStroke(dp(if (selected) 3 else 1), if (selected) color(R.color.accent) else color(R.color.line))
        return g
    }

    private fun showTextDialog(initText: String, initColor: Int, initSize: Float, onOk: (String, Int, Float) -> Unit) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(22), dp(8), dp(22), 0)
        val et = EditText(this)
        et.setText(initText)
        et.hint = "اكتب النص"
        et.minLines = 3
        et.gravity = Gravity.TOP or Gravity.START
        et.setTextColor(color(R.color.ink))
        et.setHintTextColor(color(R.color.muted))
        box.addView(et, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val sizes = floatArrayOf(0.024f, 0.036f, 0.056f)
        val labels = arrayOf("صغير", "متوسط", "كبير")
        var sizeIdx = 1
        var bestD = Float.MAX_VALUE
        for (i in sizes.indices) {
            val dd = Math.abs(sizes[i] - initSize)
            if (dd < bestD) {
                bestD = dd
                sizeIdx = i
            }
        }
        val rg = RadioGroup(this)
        rg.orientation = LinearLayout.HORIZONTAL
        val ids = IntArray(3)
        for (i in 0 until 3) {
            val rb = AppCompatRadioButton(this)
            rb.id = View.generateViewId()
            ids[i] = rb.id
            rb.text = labels[i]
            rb.setTextColor(color(R.color.ink))
            rg.addView(rb, RadioGroup.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        rg.check(ids[sizeIdx])
        val rgLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        rgLp.topMargin = dp(10)
        box.addView(rg, rgLp)

        var chosen = initColor
        val swatches = ArrayList<View>()
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        fun paintSwatches() {
            for (i in swatches.indices) swatches[i].background = swatchBg(penColors[i], penColors[i] == chosen)
        }
        for (i in penColors.indices) {
            val v = View(this)
            swatches.add(v)
            v.setOnClickListener {
                chosen = penColors[i]
                paintSwatches()
            }
            val lp = LinearLayout.LayoutParams(dp(34), dp(34))
            lp.marginEnd = dp(10)
            row.addView(v, lp)
        }
        paintSwatches()
        val rowLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        rowLp.topMargin = dp(12)
        box.addView(row, rowLp)

        val dlg = AlertDialog.Builder(this)
            .setTitle("نص")
            .setView(box)
            .setPositiveButton("تم") { _, _ ->
                val t = et.text.toString().trim()
                if (t.isNotEmpty()) {
                    val k = ids.indexOf(rg.checkedRadioButtonId).coerceAtLeast(0)
                    onOk(t, chosen, sizes[k])
                }
            }
            .setNegativeButton("إلغاء", null)
            .create()
        dlg.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        dlg.show()
        et.requestFocus()
    }

    private fun addImage(uri: Uri) {
        io.execute {
            try {
                val bmp = decodeImage(uri)
                val name = "img_" + System.currentTimeMillis() + ".jpg"
                val f = File(Library.imgDir(this, doc.id), name)
                f.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
                runOnUiThread { pdfView.insertImage(name, bmp) }
            } catch (e: Throwable) {
                runOnUiThread { Toast.makeText(this, "تعذر إدراج الصورة", Toast.LENGTH_SHORT).show() }
            }
        }
    }

    private fun decodeImage(uri: Uri): Bitmap {
        val cr = contentResolver
        val bounds = BitmapFactory.Options()
        bounds.inJustDecodeBounds = true
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        val maxSide = max(bounds.outWidth, bounds.outHeight)
        while (maxSide / sample > 2000) sample *= 2
        val opts = BitmapFactory.Options()
        opts.inSampleSize = sample
        var bmp: Bitmap = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: throw IllegalStateException("decode failed")
        var deg = 0
        try {
            cr.openInputStream(uri)?.use { s ->
                val o = ExifInterface(s).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
                deg = when (o) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270
                    else -> 0
                }
            }
        } catch (e: Throwable) {
        }
        if (deg != 0) {
            val m = Matrix()
            m.postRotate(deg.toFloat())
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        }
        if (bmp.hasAlpha()) {
            val flat = Bitmap.createBitmap(bmp.width, bmp.height, Bitmap.Config.ARGB_8888)
            val cv = Canvas(flat)
            cv.drawColor(Color.WHITE)
            cv.drawBitmap(bmp, 0f, 0f, null)
            bmp = flat
        }
        return bmp
    }

    private fun setBars(on: Boolean) {
        barsOn = on
        pdfView.setTopSlack(if (on) (dp(56) + topInset).toFloat() else 0f, true)
        topBar.animate().translationY(topBarOffset(on)).setDuration(180).start()
        if (on) dockPinned = false
        applyDock()
        if (!on) hideOptions()
        handler.removeCallbacks(hideScrub)
        scrub.animate().alpha(if (on) 1f else 0f).setDuration(150).start()
        handler.postDelayed({ avoidScrub() }, 200)
    }

    // ---- PdfView.Listener

    override fun onTap() {
        if (locked) {
            if (dockPinned) {
                dockPinned = false
                applyDock()
            }
            return
        }
        setBars(!barsOn)
    }

    private fun applyDock() {
        val show = barsOn || dockPinned
        dock.animate().translationY(if (show) 0f else (dock.height + dp(40)).toFloat()).setDuration(180).start()
        if (!show) hideOptions()
    }

    /** Long press on the floating button: the one-row tool bar (the dock) slides in while the bars are hidden / locked. */
    private fun onFabLong() {
        if (barsOn) return
        dockPinned = !dockPinned
        applyDock()
    }

    private fun refreshLockBtn() {
        if (locked) {
            lockBtn.background = circleBg(color(R.color.accent_container))
        } else {
            lockBtn.setBackgroundResource(R.drawable.ripple_circle)
        }
    }

    private fun toggleLock() {
        locked = !locked
        refreshLockBtn()
        if (locked) {
            dockPinned = false
            setBars(false)
            Toast.makeText(this, "الأشرطة مقفولة. اضغط مطولاً على الزر العائم لفتحها", Toast.LENGTH_SHORT).show()
        } else {
            setBars(true)
        }
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (pdfView.clearAllSelection()) return
        if (searchOn) {
            closeSearch()
            return
        }
        if (optPanel.visibility == View.VISIBLE) {
            hideOptions()
            return
        }
        if (locked) {
            if (dockPinned) {
                dockPinned = false
                applyDock()
            } else {
                toggleLock()
            }
            return
        }
        super.onBackPressed()
    }

    override fun onScrollChanged(frac: Float, page: Int, pages: Int) {
        this.frac = frac
        scrub.text = "${page + 1} / $pages"
        if (!scrubDragging) positionScrub()
        scrub.animate().cancel()
        scrub.alpha = 1f
        handler.removeCallbacks(hideScrub)
        if (!barsOn) handler.postDelayed(hideScrub, 1200)
        avoidScrub()
    }

    override fun onOpened(pages: Int) {
        scrub.text = "1 / $pages"
    }

    override fun onError(msg: String) {
        Toast.makeText(this, "تعذر فتح الملف\n" + msg, Toast.LENGTH_LONG).show()
        finish()
    }

    override fun onToc(items: List<TocItem>) {
        toc = items
        tocBtn.visibility = if (items.isNotEmpty() && !searchOn) View.VISIBLE else View.GONE
    }

    override fun onOpenUri(uri: String) {
        AlertDialog.Builder(this)
            .setTitle("فتح الرابط؟")
            .setMessage(uri)
            .setPositiveButton("فتح") { _, _ ->
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(uri)))
                } catch (e: Throwable) {
                    Toast.makeText(this, "تعذر فتح الرابط", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun showToc() {
        val items = toc
        if (items.isEmpty()) return
        val lv = ListView(this)
        lv.adapter = object : BaseAdapter() {
            override fun getCount(): Int = items.size
            override fun getItem(position: Int): Any = items[position]
            override fun getItemId(position: Int): Long = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val t = (convertView as? TextView) ?: TextView(this@ViewerActivity)
                val it = items[position]
                t.text = it.title
                t.setTextColor(color(R.color.ink))
                t.textSize = if (it.level == 0) 16f else 14f
                t.setTypeface(null, if (it.level == 0) Typeface.BOLD else Typeface.NORMAL)
                t.setPaddingRelative(dp(20 + it.level * 16), dp(12), dp(20), dp(12))
                return t
            }
        }
        val dlg = AlertDialog.Builder(this)
            .setTitle("الفهرس")
            .setView(lv)
            .setNegativeButton("إغلاق", null)
            .create()
        lv.setOnItemClickListener { _, _, pos, _ ->
            pdfView.goToPage(items[pos].page)
            dlg.dismiss()
        }
        dlg.show()
    }

    override fun onTextSelection(text: String?) {
        if (text.isNullOrBlank()) {
            selBar.visibility = View.GONE
        } else {
            val lp = selBar.layoutParams as FrameLayout.LayoutParams
            lp.topMargin = topInset + dp(72)
            selBar.layoutParams = lp
            selBar.visibility = View.VISIBLE
        }
    }

    override fun onInkChanged() {
        updateUndoRedo()
        handler.removeCallbacks(saveRunnable)
        handler.postDelayed(saveRunnable, 800)
    }

    override fun onPause() {
        super.onPause()
        if (::ink.isInitialized) ink.save()
        if (::doc.isInitialized && ::pdfView.isInitialized) {
            if (!skipAnchorSave) {
                val a = pdfView.anchor()
                doc.lastPage = a.first
                doc.lastFrac = a.second
            }
            doc.openedAt = System.currentTimeMillis()
            Library.save(this)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::pdfView.isInitialized) pdfView.release()
    }
}
