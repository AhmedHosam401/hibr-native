package com.hibr.nativeapp

import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlin.math.max

class ViewerActivity : AppCompatActivity(), PdfView.Listener {

    private lateinit var doc: Doc
    private lateinit var pdfView: PdfView
    private lateinit var root: FrameLayout
    private lateinit var topBar: LinearLayout
    private lateinit var scrub: TextView
    private var barsOn = true
    private var topInset = 0
    private var frac = 0f
    private var scrubDragging = false
    private val handler = Handler(Looper.getMainLooper())
    private val hideScrub = Runnable {
        if (!barsOn && !scrubDragging) scrub.animate().alpha(0f).setDuration(200).start()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = intent.getStringExtra("id")
        val d = if (id != null) Library.find(this, id) else null
        if (d == null || !Library.file(this, d.id).exists()) {
            finish()
            return
        }
        doc = d
        doc.openedAt = System.currentTimeMillis()

        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }
        hideSystemBars()

        root = FrameLayout(this)
        root.setBackgroundColor(color(R.color.viewer_bg))

        pdfView = PdfView(this)
        pdfView.bgColor = color(R.color.viewer_bg)
        pdfView.listener = this
        root.addView(pdfView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        topBar = LinearLayout(this)
        topBar.orientation = LinearLayout.HORIZONTAL
        topBar.gravity = Gravity.CENTER_VERTICAL
        topBar.layoutDirection = View.LAYOUT_DIRECTION_LTR
        topBar.setBackgroundColor(color(R.color.surface))
        topBar.elevation = dp(4).toFloat()
        val back = ImageButton(this)
        back.setImageResource(R.drawable.ic_back)
        back.setBackgroundResource(R.drawable.ripple_circle)
        back.setColorFilter(color(R.color.ink))
        back.setOnClickListener { finish() }
        val title = TextView(this)
        title.text = doc.name
        title.setTextColor(color(R.color.ink))
        title.textSize = 17f
        title.setTypeface(title.typeface, Typeface.BOLD)
        title.maxLines = 1
        title.ellipsize = TextUtils.TruncateAt.END
        topBar.addView(back, LinearLayout.LayoutParams(dp(48), dp(48)))
        val tlp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        tlp.marginStart = dp(8)
        topBar.addView(title, tlp)
        root.addView(topBar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)))

        scrub = TextView(this)
        scrub.text = "1 / 1"
        scrub.setTextColor(Color.WHITE)
        scrub.textSize = 13f
        scrub.gravity = Gravity.CENTER
        scrub.layoutDirection = View.LAYOUT_DIRECTION_LTR
        scrub.setPadding(dp(10), 0, dp(10), 0)
        val sbg = GradientDrawable()
        sbg.setColor(0x99000000.toInt())
        sbg.cornerRadius = dp(15).toFloat()
        scrub.background = sbg
        val slp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(30), Gravity.TOP or Gravity.START)
        slp.marginStart = dp(6)
        root.addView(scrub, slp)
        scrub.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    scrubDragging = true
                    dragTo(e.rawY)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    dragTo(e.rawY)
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    scrubDragging = false
                    handler.removeCallbacks(hideScrub)
                    if (!barsOn) handler.postDelayed(hideScrub, 1200)
                    true
                }
                else -> false
            }
        }

        ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            topInset = b.top
            val lp = topBar.layoutParams
            lp.height = dp(56) + b.top
            topBar.layoutParams = lp
            topBar.setPadding(b.left + dp(4), b.top, b.right + dp(4), 0)
            val sl = scrub.layoutParams as FrameLayout.LayoutParams
            sl.marginStart = b.left + dp(6)
            scrub.layoutParams = sl
            positionScrub()
            insets
        }

        setContentView(root)
        root.post { positionScrub() }
        pdfView.open(Library.file(this, doc.id), doc.lastPage, doc.lastFrac)
    }

    private fun hideSystemBars() {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    private fun trackTop(): Float = (topInset + dp(64)).toFloat()

    private fun trackH(): Float = max(1f, root.height - trackTop() - dp(24))

    private fun positionScrub() {
        if (!::scrub.isInitialized || !::root.isInitialized || root.height == 0) return
        val span = max(0f, trackH() - dp(30))
        scrub.translationY = trackTop() + frac * span
    }

    private fun dragTo(rawY: Float) {
        val loc = IntArray(2)
        root.getLocationOnScreen(loc)
        val y = rawY - loc[1]
        val span = max(1f, trackH() - dp(30))
        val f = ((y - dp(15) - trackTop()) / span).coerceIn(0f, 1f)
        scrub.translationY = trackTop() + f * span
        scrub.alpha = 1f
        pdfView.scrollToFraction(f)
    }

    private fun setBars(on: Boolean) {
        barsOn = on
        val h = topBar.height.toFloat() + dp(8)
        topBar.animate().translationY(if (on) 0f else -h).setDuration(180).start()
        handler.removeCallbacks(hideScrub)
        if (on) {
            scrub.animate().alpha(1f).setDuration(150).start()
        } else {
            scrub.animate().alpha(0f).setDuration(150).start()
        }
    }

    // ---- PdfView.Listener

    override fun onTap() {
        setBars(!barsOn)
    }

    override fun onScrollChanged(frac: Float, page: Int, pages: Int) {
        this.frac = frac
        scrub.text = "${page + 1} / $pages"
        if (!scrubDragging) positionScrub()
        scrub.animate().cancel()
        scrub.alpha = 1f
        handler.removeCallbacks(hideScrub)
        if (!barsOn) handler.postDelayed(hideScrub, 1200)
    }

    override fun onOpened(pages: Int) {
        scrub.text = "1 / $pages"
    }

    override fun onError() {
        Toast.makeText(this, "تعذر فتح الملف", Toast.LENGTH_LONG).show()
        finish()
    }

    override fun onPause() {
        super.onPause()
        if (::doc.isInitialized && ::pdfView.isInitialized) {
            val a = pdfView.anchor()
            doc.lastPage = a.first
            doc.lastFrac = a.second
            doc.openedAt = System.currentTimeMillis()
            Library.save(this)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::pdfView.isInitialized) pdfView.release()
    }
}
