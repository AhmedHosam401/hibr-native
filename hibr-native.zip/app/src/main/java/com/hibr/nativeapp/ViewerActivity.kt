package com.hibr.nativeapp

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import java.io.File
import java.util.concurrent.Executors
import kotlin.math.max

class ViewerActivity : AppCompatActivity(), PdfView.Listener {

    private lateinit var doc: Doc
    private lateinit var pdfView: PdfView
    private lateinit var ink: InkStore
    private lateinit var root: FrameLayout
    private lateinit var topBar: LinearLayout
    private lateinit var scrub: TextView
    private lateinit var dock: LinearLayout
    private lateinit var optPanel: LinearLayout
    private lateinit var fab: ImageButton
    private lateinit var undoBtn: ImageButton
    private lateinit var redoBtn: ImageButton
    private lateinit var shapeBtn: ImageButton
    private val toolBtns = HashMap<Int, ImageButton>()

    private var barsOn = true
    private var topInset = 0
    private var botInset = 0
    private var leftInset = 0
    private var rightInset = 0
    private var frac = 0f
    private var scrubDragging = false

    private var tool = Tool.PEN
    private var penColor = 0
    private var hlColor = 0
    private var penSize = 3
    private var hlSize = 4

    private val penColors = intArrayOf(
        0xFFD6336C.toInt(), 0xFF1C7ED6.toInt(), 0xFF2B8A3E.toInt(), 0xFF212529.toInt(), 0xFFF08C00.toInt()
    )
    private val hlColors = intArrayOf(
        0xFFFFE600.toInt(), 0xFF8CE99A.toInt(), 0xFF74C0FC.toInt(), 0xFFFFA8A8.toInt(), 0xFFFFD8A8.toInt()
    )

    private val handler = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private val hideScrub = Runnable {
        if (!barsOn && !scrubDragging) scrub.animate().alpha(0f).setDuration(200).start()
    }
    private val saveRunnable = Runnable { if (::ink.isInitialized) ink.save() }

    // floating button drag state
    private var fDownX = 0f
    private var fDownY = 0f
    private var fStartX = 0f
    private var fStartY = 0f
    private var fDragged = false
    private var fabHomeX = 0f
    private var fabShifted = false
    private var fabRight = false
    private var fabYFrac = 0.45f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = intent.getStringExtra("id")
        val d = if (id != null) Library.find(this, id) else null
        if (d == null || !Library.file(this, d.id).exists()) {
            finish()
            return
        }
        doc = d
        doc.openedAt = System.currentTimeMillis()
        ink = InkStore(this, doc.id)
        ink.load()

        val prefs = getSharedPreferences("tools", MODE_PRIVATE)
        penColor = prefs.getInt("penColor", penColors[0])
        hlColor = prefs.getInt("hlColor", hlColors[0])
        penSize = prefs.getInt("penSize", 3)
        hlSize = prefs.getInt("hlSize", 4)

        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }
        hideSystemBars()

        root = FrameLayout(this)
        root.setBackgroundColor(color(R.color.viewer_bg))

        pdfView = PdfView(this)
        pdfView.bgColor = color(R.color.viewer_bg)
        pdfView.listener = this
        pdfView.ink = ink
        pdfView.shapeOn = prefs.getBoolean("shapeOn", true)
        root.addView(pdfView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        buildTopBar()
        buildScrub()
        buildDock()
        buildOptions()
        buildFab()
        applyTool()

        ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            topInset = b.top
            botInset = b.bottom
            leftInset = b.left
            rightInset = b.right
            val lp = topBar.layoutParams
            lp.height = dp(56) + b.top
            topBar.layoutParams = lp
            topBar.setPadding(b.left + dp(4), b.top, b.right + dp(4), 0)
            if (barsOn) pdfView.setTopPad(lp.height.toFloat(), false)
            val sl = scrub.layoutParams as FrameLayout.LayoutParams
            sl.marginStart = b.left + dp(6)
            scrub.layoutParams = sl
            val dl = dock.layoutParams as FrameLayout.LayoutParams
            dl.bottomMargin = dp(16) + b.bottom
            dock.layoutParams = dl
            val ol = optPanel.layoutParams as FrameLayout.LayoutParams
            ol.bottomMargin = dp(16 + 56 + 8) + b.bottom
            optPanel.layoutParams = ol
            positionScrub()
            root.post { placeFab() }
            insets
        }

        setContentView(root)
        root.post {
            positionScrub()
            if (barsOn) pdfView.setTopPad((dp(56) + topInset).toFloat(), false)
            placeFab()
        }
        root.addOnLayoutChangeListener { _, l, t, r, b, ol, ot, orr, ob ->
            if (r - l != orr - ol || b - t != ob - ot) {
                placeFab()
                positionScrub()
            }
        }
        updateUndoRedo()
        pdfView.open(Library.file(this, doc.id), doc.lastPage, doc.lastFrac)
    }

    // ------------------------------------------------------------ UI building

    private fun buildTopBar() {
        topBar = LinearLayout(this)
        topBar.orientation = LinearLayout.HORIZONTAL
        topBar.gravity = Gravity.CENTER_VERTICAL
        topBar.layoutDirection = View.LAYOUT_DIRECTION_LTR
        topBar.setBackgroundColor(color(R.color.surface))
        topBar.elevation = dp(4).toFloat()
        val back = ImageButton(this)
        back.setImageResource(R.drawable.ic_back)
        back.setBackgroundResource(R.drawable.ripple_circle)
        back.setColorFilter(color(R.color.ink))
        back.setOnClickListener { finish() }
        val title = TextView(this)
        title.text = doc.name
        title.setTextColor(color(R.color.ink))
        title.textSize = 17f
        title.setTypeface(title.typeface, Typeface.BOLD)
        title.maxLines = 1
        title.ellipsize = TextUtils.TruncateAt.END
        val share = ImageButton(this)
        share.setImageResource(R.drawable.ic_share)
        share.setBackgroundResource(R.drawable.ripple_circle)
        share.setColorFilter(color(R.color.ink))
        share.setOnClickListener { exportAndShare() }
        topBar.addView(back, LinearLayout.LayoutParams(dp(48), dp(48)))
        val tlp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        tlp.marginStart = dp(8)
        topBar.addView(title, tlp)
        topBar.addView(share, LinearLayout.LayoutParams(dp(48), dp(48)))
        root.addView(topBar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)))
    }

    private fun buildScrub() {
        scrub = TextView(this)
        scrub.text = "1 / 1"
        scrub.setTextColor(Color.WHITE)
        scrub.textSize = 13f
        scrub.gravity = Gravity.CENTER
        scrub.layoutDirection = View.LAYOUT_DIRECTION_LTR
        scrub.setPadding(dp(10), 0, dp(10), 0)
        val sbg = GradientDrawable()
        sbg.setColor(0x99000000.toInt())
        sbg.cornerRadius = dp(15).toFloat()
        scrub.background = sbg
        val slp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(30), Gravity.TOP or Gravity.START)
        slp.marginStart = dp(6)
        root.addView(scrub, slp)
        scrub.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    scrubDragging = true
                    dragTo(e.rawY)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    dragTo(e.rawY)
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    scrubDragging = false
                    handler.removeCallbacks(hideScrub)
                    if (!barsOn) handler.postDelayed(hideScrub, 1200)
                    true
                }
                else -> false
            }
        }
    }

    private fun roundBg(radiusDp: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color(R.color.surface))
        g.cornerRadius = dp(radiusDp).toFloat()
        g.setStroke(dp(1), color(R.color.line))
        return g
    }

    private fun toolButton(res: Int, t: Int): ImageButton {
        val b = ImageButton(this)
        b.setImageResource(res)
        b.setColorFilter(color(R.color.ink))
        b.setOnClickListener {
            if (tool == t && pdfView.drawMode) {
                if (t != Tool.ERASER) toggleOptions(t)
            } else {
                tool = t
                setDrawMode(true)
                applyTool()
                hideOptions()
            }
        }
        toolBtns[t] = b
        return b
    }

    private fun plainButton(res: Int, onClick: () -> Unit): ImageButton {
        val b = ImageButton(this)
        b.setImageResource(res)
        b.setBackgroundResource(R.drawable.ripple_circle)
        b.setColorFilter(color(R.color.ink))
        b.setOnClickListener { onClick() }
        return b
    }

    private fun buildDock() {
        dock = LinearLayout(this)
        dock.orientation = LinearLayout.HORIZONTAL
        dock.gravity = Gravity.CENTER_VERTICAL
        dock.layoutDirection = View.LAYOUT_DIRECTION_LTR
        dock.background = roundBg(28)
        dock.elevation = dp(8).toFloat()
        dock.setPadding(dp(8), dp(4), dp(8), dp(4))
        dock.addView(toolButton(R.drawable.ic_pen, Tool.PEN), LinearLayout.LayoutParams(dp(46), dp(46)))
        dock.addView(toolButton(R.drawable.ic_highlighter, Tool.HL), LinearLayout.LayoutParams(dp(46), dp(46)))
        dock.addView(toolButton(R.drawable.ic_eraser, Tool.ERASER), LinearLayout.LayoutParams(dp(46), dp(46)))
        shapeBtn = plainButton(R.drawable.ic_shapes) { toggleShapes() }
        dock.addView(shapeBtn, LinearLayout.LayoutParams(dp(46), dp(46)))
        refreshShapeBtn()
        val sep = View(this)
        sep.setBackgroundColor(color(R.color.line))
        val splp = LinearLayout.LayoutParams(dp(1), dp(24))
        splp.marginStart = dp(6)
        splp.marginEnd = dp(6)
        dock.addView(sep, splp)
        undoBtn = plainButton(R.drawable.ic_undo) { pdfView.undoInk() }
        redoBtn = plainButton(R.drawable.ic_redo) { pdfView.redoInk() }
        dock.addView(undoBtn, LinearLayout.LayoutParams(dp(46), dp(46)))
        dock.addView(redoBtn, LinearLayout.LayoutParams(dp(46), dp(46)))
        val dlp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        dlp.bottomMargin = dp(16)
        root.addView(dock, dlp)
    }

    private fun buildOptions() {
        optPanel = LinearLayout(this)
        optPanel.orientation = LinearLayout.HORIZONTAL
        optPanel.gravity = Gravity.CENTER_VERTICAL
        optPanel.layoutDirection = View.LAYOUT_DIRECTION_LTR
        optPanel.background = roundBg(24)
        optPanel.elevation = dp(8).toFloat()
        optPanel.setPadding(dp(10), dp(6), dp(10), dp(6))
        optPanel.visibility = View.GONE
        val olp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        olp.bottomMargin = dp(16 + 56 + 8)
        root.addView(optPanel, olp)
    }

    private fun buildFab() {
        fab = ImageButton(this)
        fab.setImageResource(R.drawable.ic_pen)
        fab.elevation = dp(6).toFloat()
        setFabStyle()
        root.addView(fab, FrameLayout.LayoutParams(dp(54), dp(54), Gravity.TOP or Gravity.START))
        fab.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    fDownX = e.rawX
                    fDownY = e.rawY
                    fStartX = v.x
                    fStartY = v.y
                    fDragged = false
                    v.animate().cancel()
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - fDownX
                    val dy = e.rawY - fDownY
                    if (!fDragged && dx * dx + dy * dy > dp(8) * dp(8)) fDragged = true
                    if (fDragged) {
                        val maxX = max(0f, (root.width - v.width).toFloat())
                        val minY = fabMinY()
                        val maxY = fabMaxY()
                        v.x = (fStartX + dx).coerceIn(0f, maxX)
                        v.y = (fStartY + dy).coerceIn(minY, maxY)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val was = fDragged
                    fDragged = false
                    if (was) snapFab() else toggleDraw()
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    val was = fDragged
                    fDragged = false
                    if (was) snapFab()
                    true
                }
                else -> false
            }
        }
    }

    private fun setFabStyle() {
        val on = pdfView.drawMode
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(if (on) color(R.color.accent) else color(R.color.surface))
        g.setStroke(dp(1), color(R.color.line))
        fab.background = g
        fab.setColorFilter(if (on) color(R.color.on_accent) else color(R.color.ink))
    }

    private fun fabMinY(): Float = (topInset + dp(60)).toFloat()

    private fun fabMaxY(): Float {
        val fh = if (fab.height > 0) fab.height else dp(54)
        return max(fabMinY(), (root.height - fh - dp(90)).toFloat())
    }

    /** Puts the floating button back where it belongs (side + relative height) after a rotation / size change. */
    private fun placeFab() {
        if (!::fab.isInitialized || !::root.isInitialized) return
        if (root.width == 0 || root.height == 0 || fDragged) return
        val w = if (fab.width > 0) fab.width else dp(54)
        fab.animate().cancel()
        fabHomeX = if (fabRight) (root.width - w - rightInset - dp(8)).toFloat() else (leftInset + dp(8)).toFloat()
        fabShifted = false
        fab.x = fabHomeX
        fab.y = fabMinY() + fabYFrac * (fabMaxY() - fabMinY())
        avoidScrub()
    }

    private fun snapFab() {
        val center = fab.x + fab.width / 2f
        fabRight = center >= root.width / 2f
        fabYFrac = ((fab.y - fabMinY()) / max(1f, fabMaxY() - fabMinY())).coerceIn(0f, 1f)
        fabHomeX = if (!fabRight) (leftInset + dp(8)).toFloat() else (root.width - fab.width - rightInset - dp(8)).toFloat()
        fabShifted = false
        fab.animate().x(fabHomeX).setDuration(180).start()
        handler.postDelayed({ avoidScrub() }, 220)
    }

    private fun avoidScrub() {
        if (!::fab.isInitialized || !::scrub.isInitialized || fDragged) return
        if (scrub.width == 0) return
        val visible = scrub.alpha > 0.3f
        val sTop = scrub.translationY
        val overlapY = fab.y + fab.height + dp(8) > sTop && fab.y - dp(8) < sTop + scrub.height
        val overlapX = fabHomeX < scrub.right + dp(8) && fabHomeX + fab.width + dp(8) > scrub.left
        val want = if (visible && overlapY && overlapX) (scrub.right + dp(12)).toFloat() else fabHomeX
        val ok = want + fab.width < root.width - 4
        val target = if (ok) want else fabHomeX
        val shifted = target != fabHomeX
        if (shifted != fabShifted) {
            fabShifted = shifted
            fab.animate().x(target).setDuration(220).start()
        }
    }

    // ------------------------------------------------------------ tools

    private fun toggleDraw() {
        setDrawMode(!pdfView.drawMode)
        if (pdfView.drawMode) applyTool()
    }

    private fun setDrawMode(on: Boolean) {
        pdfView.drawMode = on
        setFabStyle()
        refreshTools()
        if (!on) hideOptions()
    }

    private fun applyTool() {
        pdfView.tool = tool
        pdfView.color = if (tool == Tool.HL) hlColor else penColor
        pdfView.penWidth = 0.0012f + penSize * 0.0008f
        pdfView.hlWidth = 0.006f + hlSize * 0.0035f
        refreshTools()
    }

    private fun circleBg(c: Int): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(c)
        return g
    }

    private fun refreshTools() {
        for ((t, b) in toolBtns) {
            if (t == tool && pdfView.drawMode) {
                b.background = circleBg(color(R.color.accent_container))
            } else {
                b.setBackgroundResource(R.drawable.ripple_circle)
            }
        }
    }

    private fun toggleShapes() {
        pdfView.shapeOn = !pdfView.shapeOn
        getSharedPreferences("tools", MODE_PRIVATE).edit().putBoolean("shapeOn", pdfView.shapeOn).apply()
        refreshShapeBtn()
    }

    private fun refreshShapeBtn() {
        if (pdfView.shapeOn) {
            shapeBtn.background = circleBg(color(R.color.accent_container))
        } else {
            shapeBtn.setBackgroundResource(R.drawable.ripple_circle)
        }
    }

    private fun hideOptions() {
        optPanel.visibility = View.GONE
    }

    private fun toggleOptions(t: Int) {
        if (optPanel.visibility == View.VISIBLE) {
            hideOptions()
        } else {
            buildSwatches(t)
        }
    }

    private fun buildSwatches(t: Int) {
        optPanel.removeAllViews()
        val cols = if (t == Tool.HL) hlColors else penColors
        val cur = if (t == Tool.HL) hlColor else penColor
        val prefs = getSharedPreferences("tools", MODE_PRIVATE)
        for (c in cols) {
            val v = View(this)
            val g = GradientDrawable()
            g.shape = GradientDrawable.OVAL
            g.setColor(c)
            g.setStroke(dp(if (c == cur) 3 else 1), if (c == cur) color(R.color.accent) else color(R.color.line))
            v.background = g
            v.setOnClickListener {
                if (t == Tool.HL) hlColor = c else penColor = c
                prefs.edit().putInt("penColor", penColor).putInt("hlColor", hlColor).apply()
                applyTool()
                buildSwatches(t)
            }
            val lp = LinearLayout.LayoutParams(dp(30), dp(30))
            lp.marginStart = dp(5)
            lp.marginEnd = dp(5)
            optPanel.addView(v, lp)
        }
        val sb = SeekBar(this)
        sb.max = 9
        sb.progress = (if (t == Tool.HL) hlSize else penSize) - 1
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (t == Tool.HL) hlSize = progress + 1 else penSize = progress + 1
                applyTool()
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                prefs.edit().putInt("penSize", penSize).putInt("hlSize", hlSize).apply()
            }
        })
        optPanel.addView(sb, LinearLayout.LayoutParams(dp(130), dp(36)))
        optPanel.visibility = View.VISIBLE
    }

    private fun updateUndoRedo() {
        if (!::undoBtn.isInitialized) return
        undoBtn.alpha = if (ink.canUndo()) 1f else 0.35f
        redoBtn.alpha = if (ink.canRedo()) 1f else 0.35f
    }

    // ------------------------------------------------------------ export

    private fun exportAndShare() {
        ink.save()
        Toast.makeText(this, "جاري التجهيز...", Toast.LENGTH_SHORT).show()
        io.execute {
            try {
                val f = Exporter.prepare(this, doc)
                runOnUiThread { shareFile(f) }
            } catch (e: Throwable) {
                val msg = e.javaClass.simpleName + ": " + (e.message ?: "")
                runOnUiThread { Toast.makeText(this, "تعذر التصدير\n" + msg, Toast.LENGTH_LONG).show() }
            }
        }
    }

    private fun shareFile(f: File) {
        try {
            val uri = FileProvider.getUriForFile(this, "$packageName.files", f)
            val i = Intent(Intent.ACTION_SEND)
            i.type = "application/pdf"
            i.putExtra(Intent.EXTRA_STREAM, uri)
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(i, doc.name))
        } catch (e: Exception) {
            Toast.makeText(this, "تعذرت المشاركة", Toast.LENGTH_SHORT).show()
        }
    }

    // ------------------------------------------------------------ system / bars / scrub

    private fun hideSystemBars() {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    private fun trackTop(): Float = (topInset + dp(64)).toFloat()

    private fun trackH(): Float = max(1f, root.height - trackTop() - dp(24))

    private fun positionScrub() {
        if (!::scrub.isInitialized || !::root.isInitialized || root.height == 0) return
        val span = max(0f, trackH() - dp(30))
        scrub.translationY = trackTop() + frac * span
    }

    private fun dragTo(rawY: Float) {
        val loc = IntArray(2)
        root.getLocationOnScreen(loc)
        val y = rawY - loc[1]
        val span = max(1f, trackH() - dp(30))
        val f = ((y - dp(15) - trackTop()) / span).coerceIn(0f, 1f)
        scrub.translationY = trackTop() + f * span
        scrub.alpha = 1f
        pdfView.scrollToFraction(f)
    }

    private fun setBars(on: Boolean) {
        barsOn = on
        pdfView.setTopPad(if (on) (dp(56) + topInset).toFloat() else 0f, true)
        val h = topBar.height.toFloat() + dp(8)
        topBar.animate().translationY(if (on) 0f else -h).setDuration(180).start()
        dock.animate().translationY(if (on) 0f else (dock.height + dp(40)).toFloat()).setDuration(180).start()
        if (!on) hideOptions()
        handler.removeCallbacks(hideScrub)
        scrub.animate().alpha(if (on) 1f else 0f).setDuration(150).start()
        handler.postDelayed({ avoidScrub() }, 200)
    }

    // ---- PdfView.Listener

    override fun onTap() {
        setBars(!barsOn)
    }

    override fun onScrollChanged(frac: Float, page: Int, pages: Int) {
        this.frac = frac
        scrub.text = "${page + 1} / $pages"
        if (!scrubDragging) positionScrub()
        scrub.animate().cancel()
        scrub.alpha = 1f
        handler.removeCallbacks(hideScrub)
        if (!barsOn) handler.postDelayed(hideScrub, 1200)
        avoidScrub()
    }

    override fun onOpened(pages: Int) {
        scrub.text = "1 / $pages"
    }

    override fun onError(msg: String) {
        Toast.makeText(this, "تعذر فتح الملف\n" + msg, Toast.LENGTH_LONG).show()
        finish()
    }

    override fun onInkChanged() {
        updateUndoRedo()
        handler.removeCallbacks(saveRunnable)
        handler.postDelayed(saveRunnable, 800)
    }

    override fun onPause() {
        super.onPause()
        if (::ink.isInitialized) ink.save()
        if (::doc.isInitialized && ::pdfView.isInitialized) {
            val a = pdfView.anchor()
            doc.lastPage = a.first
            doc.lastFrac = a.second
            doc.openedAt = System.currentTimeMillis()
            Library.save(this)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::pdfView.isInitialized) pdfView.release()
    }
}
