package com.hibr.nativeapp

import android.graphics.RectF
import com.shockwave.pdfium.PdfDocument

/** One entry of the document outline (bookmarks), flattened with its nesting level. */
class TocItem(val title: String, val page: Int, val level: Int)

/** A tappable link on a page: rect is normalized to the page; page >= 0 for internal links, uri for external ones. */
class LinkRect(val rect: RectF, val page: Int, val uri: String?)

object Toc {
    fun flatten(list: List<PdfDocument.Bookmark>, level: Int, out: ArrayList<TocItem>) {
        for (b in list) {
            val t = (b.title ?: "").trim()
            val p = b.pageIdx
            if (t.isNotEmpty() && p >= 0) out.add(TocItem(t, p.toInt(), level))
            if (b.hasChildren()) flatten(b.children, level + 1, out)
            if (out.size > 5000) return
        }
    }
}
