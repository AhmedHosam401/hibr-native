package com.hibr.nativeapp

import android.content.Context
import androidx.core.content.ContextCompat

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun Context.color(id: Int): Int = ContextCompat.getColor(this, id)
