package com.hibr.nativeapp

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.net.Uri
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.util.Base64
import android.util.Base64OutputStream
import android.util.JsonReader
import android.util.JsonToken
import com.shockwave.pdfium.PdfiumCore
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.FilterOutputStream
import java.io.InputStreamReader
import java.util.UUID
import kotlin.math.max
import kotlin.math.min

/**
 * .hibr backup files.
 *  - format 2 (this app): {hibr:2, name, star, ink:{...}, images:{name:base64}, pdf:base64}
 *  - format 1 (the web version): {hibr:1, name, star, folder, strokes:{page:[items]}, pdf:base64}
 */
object Backup {

    fun export(c: Context, d: Doc): File {
        val dir = File(c.cacheDir, "export")
        dir.mkdirs()
        val safe = d.name.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().ifEmpty { "file" }
        val target = File(dir, "$safe.hibr")
        val inkFile = Library.inkFile(c, d.id)
        val inkText = if (inkFile.exists()) inkFile.readText(Charsets.UTF_8).trim().ifEmpty { "{}" } else "{}"
        val raw = BufferedOutputStream(FileOutputStream(target), 64 * 1024)
        try {
            fun w(s: String) = raw.write(s.toByteArray(Charsets.UTF_8))
            w("{\"hibr\":2,\"name\":" + JSONObject.quote(d.name) + ",\"star\":" + d.star + ",\"folder\":" + JSONObject.quote(d.folder) + ",\"ink\":" + inkText + ",\"images\":{")
            val imgs = Library.imgDir(c, d.id).listFiles()
            var first = true
            if (imgs != null) {
                for (f in imgs) {
                    if (!f.isFile) continue
                    if (!first) w(",")
                    first = false
                    w(JSONObject.quote(f.name) + ":\"" + Base64.encodeToString(f.readBytes(), Base64.NO_WRAP) + "\"")
                }
            }
            w("},\"pdf\":\"")
            val keep = object : FilterOutputStream(raw) {
                override fun write(b: ByteArray, off: Int, len: Int) {
                    out.write(b, off, len)
                }

                override fun close() {
                    flush()
                }
            }
            val b64 = Base64OutputStream(keep, Base64.NO_WRAP)
            Library.file(c, d.id).inputStream().use { it.copyTo(b64, 64 * 1024) }
            b64.close()
            w("\"}")
            raw.flush()
        } finally {
            raw.close()
        }
        return target
    }

    private fun readValue(r: JsonReader): Any? {
        return when (r.peek()) {
            JsonToken.BEGIN_OBJECT -> {
                val o = JSONObject()
                r.beginObject()
                while (r.hasNext()) {
                    val k = r.nextName()
                    o.put(k, readValue(r) ?: JSONObject.NULL)
                }
                r.endObject()
                o
            }
            JsonToken.BEGIN_ARRAY -> {
                val a = JSONArray()
                r.beginArray()
                while (r.hasNext()) a.put(readValue(r) ?: JSONObject.NULL)
                r.endArray()
                a
            }
            JsonToken.STRING -> r.nextString()
            JsonToken.NUMBER -> r.nextDouble()
            JsonToken.BOOLEAN -> r.nextBoolean()
            else -> {
                r.skipValue()
                null
            }
        }
    }

    private fun safeName(s: String): String? {
        val n = File(s).name
        return if (Regex("[A-Za-z0-9_.-]{1,80}").matches(n)) n else null
    }

    /** Imports a .hibr file (web or app format) as a new document. Returns null if the file is not valid. */
    fun import(c: Context, uri: Uri): Doc? {
        val input = c.contentResolver.openInputStream(uri) ?: return null
        var ver = 0
        var name = "ملف"
        var star = false
        var folder = ""
        var strokes: Any? = null
        var ink: Any? = null
        var images: Any? = null
        var pdf: ByteArray? = null
        try {
            input.use { ins ->
                val r = JsonReader(InputStreamReader(BufferedInputStream(ins, 64 * 1024), Charsets.UTF_8))
                r.beginObject()
                while (r.hasNext()) {
                    when (r.nextName()) {
                        "hibr" -> ver = r.nextInt()
                        "name" -> name = if (r.peek() == JsonToken.STRING) r.nextString() else {
                            r.skipValue()
                            name
                        }
                        "star" -> star = if (r.peek() == JsonToken.BOOLEAN) r.nextBoolean() else {
                            r.skipValue()
                            false
                        }
                        "folder" -> folder = if (r.peek() == JsonToken.STRING) r.nextString() else {
                            r.skipValue()
                            ""
                        }
                        "strokes" -> strokes = readValue(r)
                        "ink" -> ink = readValue(r)
                        "images" -> images = readValue(r)
                        "pdf" -> {
                            val s = r.nextString()
                            pdf = Base64.decode(s, Base64.DEFAULT)
                        }
                        else -> r.skipValue()
                    }
                }
                r.endObject()
            }
        } catch (e: Throwable) {
            return null
        }
        val bytes = pdf ?: return null
        if (ver != 1 && ver != 2) return null
        val id = UUID.randomUUID().toString().replace("-", "").substring(0, 12)
        try {
            Library.file(c, id).writeBytes(bytes)
            if (ver == 2) {
                val im = images as? JSONObject
                if (im != null) {
                    val dir = Library.imgDir(c, id)
                    val it = im.keys()
                    while (it.hasNext()) {
                        val k = it.next()
                        val fn = safeName(k) ?: continue
                        File(dir, fn).writeBytes(Base64.decode(im.getString(k), Base64.DEFAULT))
                    }
                }
                val ik = ink as? JSONObject
                if (ik != null && ik.length() > 0) Library.inkFile(c, id).writeText(ik.toString(), Charsets.UTF_8)
            } else {
                val st = strokes as? JSONObject
                if (st != null && st.length() > 0) convertWeb(c, id, bytes, st)
            }
        } catch (e: Throwable) {
            Library.file(c, id).delete()
            Library.inkFile(c, id).delete()
            File(File(c.filesDir, "img"), id).deleteRecursively()
            return null
        }
        val d = Doc(id = id, name = name.trim().ifEmpty { "ملف" }, star = star, folder = folder.trim())
        Library.addDoc(c, d)
        Library.makeThumb(c, d)
        return d
    }

    private fun colorOf(s: String): Int {
        return try {
            var t = s.trim()
            if (t.startsWith("#") && t.length == 4) t = "#" + t[1] + t[1] + t[2] + t[2] + t[3] + t[3]
            Color.parseColor(t)
        } catch (e: Throwable) {
            0xFF212529.toInt()
        }
    }

    private fun stroke(tool: Int, color: Int, width: Float, pts: DoubleArray, img: String?, text: String?): JSONObject {
        val o = JSONObject()
        o.put("t", tool)
        o.put("c", color)
        o.put("w", width.toDouble())
        if (img != null) o.put("i", img)
        if (text != null) o.put("tx", text)
        val p = JSONArray()
        for (v in pts) p.put(Math.round(v * 10000.0) / 10000.0)
        o.put("p", p)
        return o
    }

    /** Converts web-version strokes (PDF points, origin top-left) to the app's normalized format. */
    private fun convertWeb(c: Context, id: String, pdfBytes: ByteArray, st: JSONObject) {
        val core = PdfiumCore(c)
        val pd = core.newDocument(pdfBytes)
        val n = core.getPageCount(pd)
        val pw = FloatArray(n)
        val ph = FloatArray(n)
        for (i in 0 until n) {
            core.openPage(pd, i)
            val s = core.getPageSize(pd, i)
            pw[i] = max(1, s.width).toFloat()
            ph[i] = max(1, s.height).toFloat()
        }
        core.closeDocument(pd)

        val imgDir = Library.imgDir(c, id)
        var imgN = 0
        val root = JSONObject()
        val keys = st.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            val pi = k.toIntOrNull() ?: continue
            if (pi < 0 || pi >= n) continue
            val arr = st.optJSONArray(k) ?: continue
            val W = pw[pi]
            val H = ph[pi]
            val out = JSONArray()
            for (i in 0 until arr.length()) {
                val s = arr.optJSONObject(i) ?: continue
                val col = colorOf(s.optString("c", "#212529"))
                when (s.optString("t")) {
                    "pen", "hl" -> {
                        val p = s.optJSONArray("p") ?: continue
                        if (p.length() == 0) continue
                        val pts = DoubleArray(p.length() * 2)
                        for (j in 0 until p.length()) {
                            val q = p.optJSONArray(j) ?: continue
                            pts[2 * j] = (q.optDouble(0, 0.0) / W).coerceIn(0.0, 1.0)
                            pts[2 * j + 1] = (q.optDouble(1, 0.0) / H).coerceIn(0.0, 1.0)
                        }
                        val w = (s.optDouble("w", 2.0) / W).toFloat().coerceIn(0.0004f, 0.2f)
                        val tool = if (s.optString("t") == "hl") Tool.HL else Tool.PEN
                        out.put(stroke(tool, col, w, if (p.length() == 1) doubleArrayOf(pts[0], pts[1], pts[0], pts[1]) else pts, null, null))
                    }
                    "hr" -> {
                        val rs = s.optJSONArray("r") ?: continue
                        for (j in 0 until rs.length()) {
                            val r = rs.optJSONArray(j) ?: continue
                            val x = r.optDouble(0, 0.0)
                            val y = r.optDouble(1, 0.0)
                            val rw = r.optDouble(2, 0.0)
                            val rh = r.optDouble(3, 0.0)
                            if (rh <= 0.0 || rw <= 0.0) continue
                            val wf = (rh / W)
                            var xa = (x + rh / 2.0) / W
                            var xb = (x + rw - rh / 2.0) / W
                            if (xb < xa) {
                                val m = (x + rw / 2.0) / W
                                xa = m
                                xb = m
                            }
                            val yc = (y + rh / 2.0) / H
                            out.put(
                                stroke(
                                    Tool.HL, col, wf.toFloat().coerceIn(0.0004f, 0.2f),
                                    doubleArrayOf(xa.coerceIn(0.0, 1.0), yc.coerceIn(0.0, 1.0), xb.coerceIn(0.0, 1.0), yc.coerceIn(0.0, 1.0)),
                                    null, null
                                )
                            )
                        }
                    }
                    "tx" -> {
                        val text = s.optString("s", "")
                        if (text.isBlank()) continue
                        val fs = s.optDouble("w", 16.0)
                        val x = s.optDouble("x", 0.0)
                        val yBase = s.optDouble("y", 0.0)
                        val yTop = yBase - fs * 0.9
                        val widthPts = s.optDouble("W", W * 0.5) * 1.15 + 6.0
                        val nw = min(widthPts / W, 1.0 - (x / W).coerceIn(0.0, 0.95)).coerceIn(0.05, 1.0)
                        val fontFrac = (fs / W).toFloat().coerceIn(0.004f, 0.2f)
                        // height of the text box, measured at a reference width of 1000 px
                        val tp = TextPaint(android.graphics.Paint.ANTI_ALIAS_FLAG)
                        tp.textSize = fontFrac * 1000f
                        val lay = StaticLayout.Builder.obtain(text, 0, text.length, tp, max(1, (nw * 1000.0).toInt()))
                            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                            .setLineSpacing(0f, 1.1f)
                            .build()
                        val nh = lay.height.toDouble() / (1000.0 * H / W)
                        val nx = (x / W).coerceIn(0.0, 1.0 - nw)
                        val ny = (yTop / H).coerceIn(0.0, max(0.0, 1.0 - nh))
                        out.put(stroke(Tool.TEXT, col, fontFrac, doubleArrayOf(nx, ny, nw, nh), null, text))
                    }
                    "img" -> {
                        val src = s.optString("src", "")
                        val comma = src.indexOf(',')
                        if (comma < 0) continue
                        val raw = Base64.decode(src.substring(comma + 1), Base64.DEFAULT)
                        var bmp = BitmapFactory.decodeByteArray(raw, 0, raw.size) ?: continue
                        if (bmp.hasAlpha()) {
                            val flat = Bitmap.createBitmap(bmp.width, bmp.height, Bitmap.Config.ARGB_8888)
                            val cv = Canvas(flat)
                            cv.drawColor(Color.WHITE)
                            cv.drawBitmap(bmp, 0f, 0f, null)
                            bmp = flat
                        }
                        val name = "img_imp" + System.currentTimeMillis() + "_" + (imgN++) + ".jpg"
                        File(imgDir, name).outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
                        val ix = s.optDouble("x", 0.0)
                        val iy = s.optDouble("y", 0.0)
                        val iw = s.optDouble("iw", 100.0)
                        val ih = s.optDouble("ih", 100.0)
                        out.put(
                            stroke(
                                Tool.IMAGE, 0, 0f,
                                doubleArrayOf(
                                    (ix / W).coerceIn(0.0, 1.0), (iy / H).coerceIn(0.0, 1.0),
                                    (iw / W).coerceIn(0.01, 1.0), (ih / H).coerceIn(0.01, 1.0)
                                ),
                                name, null
                            )
                        )
                    }
                }
            }
            if (out.length() > 0) root.put(pi.toString(), out)
        }
        if (root.length() > 0) Library.inkFile(c, id).writeText(root.toString(), Charsets.UTF_8)
    }
}
