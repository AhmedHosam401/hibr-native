package com.hibr.nativeapp

import android.app.Application
import android.content.Context
import androidx.appcompat.app.AppCompatDelegate

class HibrApp : Application() {
    override fun onCreate() {
        super.onCreate()
        AppCompatDelegate.setDefaultNightMode(savedNightMode(this))
    }

    companion object {
        /** AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM (-1), MODE_NIGHT_NO (1) or MODE_NIGHT_YES (2). */
        fun savedNightMode(c: Context): Int =
            c.getSharedPreferences("settings", Context.MODE_PRIVATE)
                .getInt("night", AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)

        fun saveNightMode(c: Context, mode: Int) {
            c.getSharedPreferences("settings", Context.MODE_PRIVATE).edit().putInt("night", mode).apply()
            AppCompatDelegate.setDefaultNightMode(mode)
        }
    }
}
