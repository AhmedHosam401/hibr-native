package com.hibr.nativeapp

import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.text.DateFormat
import java.util.Date
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var adapter: DocAdapter
    private lateinit var emptyView: TextView
    private lateinit var searchBox: EditText
    private lateinit var starBtn: ImageButton
    private lateinit var fab: TextView
    private lateinit var topBar: LinearLayout
    private lateinit var list: RecyclerView
    private var starOnly = false
    private var query = ""
    private val io = Executors.newSingleThreadExecutor()
    private val tried = HashSet<String>()

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) importUri(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        val wic = WindowInsetsControllerCompat(window, window.decorView)
        wic.isAppearanceLightStatusBars = !night
        wic.isAppearanceLightNavigationBars = !night

        val root = FrameLayout(this)
        root.setBackgroundColor(color(R.color.bg))
        root.layoutDirection = View.LAYOUT_DIRECTION_RTL

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL

        topBar = LinearLayout(this)
        topBar.orientation = LinearLayout.HORIZONTAL
        topBar.gravity = Gravity.CENTER_VERTICAL
        topBar.layoutDirection = View.LAYOUT_DIRECTION_LTR
        topBar.setBackgroundColor(color(R.color.surface))
        topBar.setPadding(dp(12), 0, dp(4), 0)
        val logo = ImageView(this)
        logo.setImageResource(R.drawable.ic_logo)
        topBar.addView(logo, LinearLayout.LayoutParams(dp(34), dp(34)))
        topBar.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        starBtn = iconButton(R.drawable.ic_star) { toggleStar() }
        val searchBtn = iconButton(R.drawable.ic_search) { toggleSearch() }
        topBar.addView(starBtn, LinearLayout.LayoutParams(dp(48), dp(48)))
        topBar.addView(searchBtn, LinearLayout.LayoutParams(dp(48), dp(48)))
        col.addView(topBar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)))

        searchBox = EditText(this)
        searchBox.hint = "ابحث باسم الملف"
        searchBox.visibility = View.GONE
        searchBox.setSingleLine(true)
        searchBox.setTextColor(color(R.color.ink))
        searchBox.setHintTextColor(color(R.color.muted))
        searchBox.setBackgroundColor(color(R.color.surface))
        searchBox.setPadding(dp(16), dp(10), dp(16), dp(10))
        searchBox.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                query = s?.toString()?.trim() ?: ""
                refresh()
            }
        })
        col.addView(searchBox, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        adapter = DocAdapter(
            this,
            { d -> openDoc(d) },
            { d ->
                d.star = !d.star
                Library.save(this)
                refresh()
            },
            { d, v -> showMenu(d, v) }
        )
        list = RecyclerView(this)
        list.layoutManager = LinearLayoutManager(this)
        list.clipToPadding = false
        list.setPadding(dp(12), dp(12), dp(12), dp(110))
        list.adapter = adapter
        col.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        emptyView = TextView(this)
        emptyView.text = "لا توجد ملفات بعد.\nاضغط «فتح PDF» لإضافة ملف."
        emptyView.gravity = Gravity.CENTER
        emptyView.setTextColor(color(R.color.muted))
        emptyView.textSize = 15f
        emptyView.visibility = View.GONE
        root.addView(
            emptyView,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER)
        )

        fab = TextView(this)
        fab.text = "+ فتح PDF"
        fab.setTextColor(color(R.color.on_accent))
        fab.textSize = 16f
        fab.setTypeface(fab.typeface, Typeface.BOLD)
        fab.gravity = Gravity.CENTER
        fab.setPadding(dp(26), 0, dp(26), 0)
        val fabBg = GradientDrawable()
        fabBg.setColor(color(R.color.accent))
        fabBg.cornerRadius = dp(26).toFloat()
        fab.background = fabBg
        fab.elevation = dp(6).toFloat()
        fab.setOnClickListener { picker.launch(arrayOf("application/pdf")) }
        val fabLp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(52), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        fabLp.bottomMargin = dp(20)
        root.addView(fab, fabLp)

        ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            val tlp = topBar.layoutParams
            tlp.height = dp(56) + b.top
            topBar.layoutParams = tlp
            topBar.setPadding(dp(12) + b.left, b.top, dp(4) + b.right, 0)
            list.setPadding(dp(12) + b.left, dp(12), dp(12) + b.right, dp(110))
            val flp = fab.layoutParams as FrameLayout.LayoutParams
            flp.bottomMargin = dp(20) + b.bottom
            fab.layoutParams = flp
            insets
        }

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun iconButton(res: Int, onClick: () -> Unit): ImageButton {
        val b = ImageButton(this)
        b.setImageResource(res)
        b.setBackgroundResource(R.drawable.ripple_circle)
        b.setColorFilter(color(R.color.ink))
        b.setOnClickListener { onClick() }
        return b
    }

    private fun toggleStar() {
        starOnly = !starOnly
        starBtn.setImageResource(if (starOnly) R.drawable.ic_star_fill else R.drawable.ic_star)
        starBtn.setColorFilter(if (starOnly) 0xFFF59F00.toInt() else color(R.color.ink))
        refresh()
    }

    private fun toggleSearch() {
        if (searchBox.visibility == View.VISIBLE) {
            searchBox.setText("")
            searchBox.visibility = View.GONE
        } else {
            searchBox.visibility = View.VISIBLE
            searchBox.requestFocus()
        }
    }

    private fun refresh() {
        val all = Library.all(this)
        var items = all.sortedByDescending { it.openedAt }
        if (starOnly) items = items.filter { it.star }
        if (query.isNotEmpty()) items = items.filter { it.name.contains(query, ignoreCase = true) }
        adapter.items = items
        adapter.notifyDataSetChanged()
        for (d in all) {
            if (!Library.thumbFile(this, d.id).exists() && tried.add(d.id)) {
                io.execute {
                    Library.makeThumb(this, d)
                    runOnUiThread { refresh() }
                }
            }
        }
        if (items.isEmpty()) {
            emptyView.text = if (all.isEmpty()) "لا توجد ملفات بعد.\nاضغط «فتح PDF» لإضافة ملف." else "لا توجد ملفات مطابقة"
            emptyView.visibility = View.VISIBLE
        } else {
            emptyView.visibility = View.GONE
        }
    }

    private fun importUri(uri: Uri) {
        Toast.makeText(this, "جاري الإضافة...", Toast.LENGTH_SHORT).show()
        io.execute {
            val d = Library.importPdf(this, uri)
            if (d != null) Library.makeThumb(this, d)
            val err = Library.lastError
            runOnUiThread {
                if (err.isNotEmpty()) {
                    Toast.makeText(this, "المعاينة: " + err, Toast.LENGTH_LONG).show()
                    Library.lastError = ""
                }
                if (d == null) {
                    Toast.makeText(this, "تعذر فتح الملف", Toast.LENGTH_SHORT).show()
                } else {
                    refresh()
                    openDoc(d)
                }
            }
        }
    }

    private fun openDoc(d: Doc) {
        val i = Intent(this, ViewerActivity::class.java)
        i.putExtra("id", d.id)
        startActivity(i)
    }

    private fun showMenu(d: Doc, anchor: View) {
        val pm = PopupMenu(this, anchor)
        pm.menu.add(0, 1, 0, "مشاركة")
        pm.menu.add(0, 2, 1, "إعادة تسمية")
        pm.menu.add(0, 3, 2, "حذف")
        pm.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> share(d)
                2 -> rename(d)
                3 -> confirmDelete(d)
            }
            true
        }
        pm.show()
    }

    private fun share(d: Doc) {
        Toast.makeText(this, "جاري التجهيز...", Toast.LENGTH_SHORT).show()
        io.execute {
            try {
                val f = Exporter.prepare(this, d)
                runOnUiThread {
                    try {
                        val uri = FileProvider.getUriForFile(this, "$packageName.files", f)
                        val i = Intent(Intent.ACTION_SEND)
                        i.type = "application/pdf"
                        i.putExtra(Intent.EXTRA_STREAM, uri)
                        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        startActivity(Intent.createChooser(i, d.name))
                    } catch (e: Exception) {
                        Toast.makeText(this, "تعذرت المشاركة", Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (e: Throwable) {
                val msg = e.javaClass.simpleName + ": " + (e.message ?: "")
                runOnUiThread { Toast.makeText(this, "تعذرت المشاركة\n" + msg, Toast.LENGTH_LONG).show() }
            }
        }
    }

    private fun rename(d: Doc) {
        val et = EditText(this)
        et.setText(d.name)
        et.setSelection(d.name.length)
        AlertDialog.Builder(this)
            .setTitle("إعادة تسمية")
            .setView(et)
            .setPositiveButton("حفظ") { _, _ ->
                val n = et.text.toString().trim()
                if (n.isNotEmpty()) {
                    d.name = n
                    Library.save(this)
                    refresh()
                }
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun confirmDelete(d: Doc) {
        AlertDialog.Builder(this)
            .setTitle("حذف الملف؟")
            .setMessage(d.name)
            .setPositiveButton("حذف") { _, _ ->
                Library.delete(this, d)
                refresh()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }
}

class DocAdapter(
    private val ctx: Context,
    private val onOpen: (Doc) -> Unit,
    private val onStar: (Doc) -> Unit,
    private val onMore: (Doc, View) -> Unit
) : RecyclerView.Adapter<DocAdapter.VH>() {

    var items: List<Doc> = emptyList()

    class VH(
        val row: LinearLayout,
        val thumb: ImageView,
        val name: TextView,
        val meta: TextView,
        val star: ImageButton,
        val more: ImageButton
    ) : RecyclerView.ViewHolder(row)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val bg = GradientDrawable()
        bg.setColor(ctx.color(R.color.surface))
        bg.cornerRadius = ctx.dp(14).toFloat()
        bg.setStroke(ctx.dp(1), ctx.color(R.color.line))
        row.background = bg
        row.clipToOutline = true
        val rlp = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ctx.dp(84))
        rlp.bottomMargin = ctx.dp(10)
        row.layoutParams = rlp

        val thumb = ImageView(ctx)
        thumb.scaleType = ImageView.ScaleType.CENTER_CROP
        thumb.setBackgroundColor(Color.WHITE)
        row.addView(thumb, LinearLayout.LayoutParams(ctx.dp(64), ViewGroup.LayoutParams.MATCH_PARENT))

        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_VERTICAL
        val name = TextView(ctx)
        name.setTextColor(ctx.color(R.color.ink))
        name.textSize = 15f
        name.setTypeface(name.typeface, Typeface.BOLD)
        name.maxLines = 1
        name.ellipsize = TextUtils.TruncateAt.END
        val meta = TextView(ctx)
        meta.setTextColor(ctx.color(R.color.muted))
        meta.textSize = 12f
        meta.maxLines = 1
        col.addView(name, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        col.addView(meta, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val clp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
        clp.marginStart = ctx.dp(12)
        clp.marginEnd = ctx.dp(4)
        row.addView(col, clp)

        val star = ImageButton(ctx)
        star.setBackgroundResource(R.drawable.ripple_circle)
        val more = ImageButton(ctx)
        more.setBackgroundResource(R.drawable.ripple_circle)
        more.setImageResource(R.drawable.ic_more)
        more.setColorFilter(ctx.color(R.color.ink))
        row.addView(star, LinearLayout.LayoutParams(ctx.dp(44), ctx.dp(44)))
        row.addView(more, LinearLayout.LayoutParams(ctx.dp(44), ctx.dp(44)))
        return VH(row, thumb, name, meta, star, more)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val d = items[position]
        holder.name.text = d.name
        val date = DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(d.openedAt))
        holder.meta.text = if (d.pages > 0) "$date · ${d.pages} ص" else date
        val tf = Library.thumbFile(ctx, d.id)
        if (tf.exists()) {
            holder.thumb.setImageBitmap(BitmapFactory.decodeFile(tf.path))
        } else {
            holder.thumb.setImageDrawable(null)
        }
        holder.star.setImageResource(if (d.star) R.drawable.ic_star_fill else R.drawable.ic_star)
        holder.star.setColorFilter(if (d.star) 0xFFF59F00.toInt() else ctx.color(R.color.ink))
        holder.row.setOnClickListener { onOpen(d) }
        holder.star.setOnClickListener { onStar(d) }
        holder.more.setOnClickListener { onMore(d, holder.more) }
    }
}
