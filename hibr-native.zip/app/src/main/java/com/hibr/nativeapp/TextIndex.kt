package com.hibr.nativeapp

import android.content.Context
import android.graphics.RectF
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.tom_roush.pdfbox.text.TextPosition
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** One word with its box (normalized to the page, origin top-left). cx = start x of every char + end x (LTR words only). */
class Word(
    val text: String,
    val x0: Float,
    val y0: Float,
    val x1: Float,
    val y1: Float,
    val cx: FloatArray?
)

class PageText(val words: List<Word>) {
    val text: String
    val starts = IntArray(words.size)

    init {
        val sb = StringBuilder()
        for (i in words.indices) {
            starts[i] = sb.length
            sb.append(words[i].text)
            sb.append(' ')
        }
        text = sb.toString()
    }
}

class Hit(val page: Int, val rects: List<RectF>)

object TextNorm {
    fun isRtl(ch: Char): Boolean {
        val c = ch.code
        return (c in 0x0590..0x08FF) || (c in 0xFB1D..0xFDFF) || (c in 0xFE70..0xFEFF)
    }

    fun hasRtl(s: String): Boolean {
        for (ch in s) if (isRtl(ch)) return true
        return false
    }

    /** Removes Arabic diacritics / tatweel and unifies alef forms. */
    fun norm(s: String): String {
        val sb = StringBuilder(s.length)
        for (ch in s) {
            val c = ch.code
            if ((c in 0x064B..0x065F) || c == 0x0670 || c == 0x0640) continue
            when (c) {
                0x0623, 0x0625, 0x0622 -> sb.append('\u0627')
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }
}

class TextIndex(private val ctx: Context, private val file: File) {
    val pages = ConcurrentHashMap<Int, PageText>()

    @Volatile
    var total = 0

    @Volatile
    var done = 0

    @Volatile
    var finished = false

    @Volatile
    var failed = false
    private var started = false

    private class Grabber : PDFTextStripper() {
        val words = ArrayList<Word>()

        override fun writeString(text: String, textPositions: MutableList<TextPosition>) {
            if (textPositions.isEmpty() || text.isBlank()) return
            val p0 = textPositions[0]
            if (p0.dir != 0f) return
            val pw = p0.pageWidth
            val ph = p0.pageHeight
            if (pw <= 0f || ph <= 0f) return
            var x0 = Float.MAX_VALUE
            var y0 = Float.MAX_VALUE
            var x1 = -Float.MAX_VALUE
            var y1 = -Float.MAX_VALUE
            for (t in textPositions) {
                val l = t.xDirAdj
                val r = t.xDirAdj + t.widthDirAdj
                val top = t.yDirAdj - t.heightDir
                val bot = t.yDirAdj + t.heightDir * 0.2f
                if (l < x0) x0 = l
                if (r > x1) x1 = r
                if (top < y0) y0 = top
                if (bot > y1) y1 = bot
            }
            val nt = TextNorm.norm(text)
            if (nt.isBlank()) return
            var cx: FloatArray? = null
            if (nt.length == text.length && textPositions.size == text.length && !TextNorm.hasRtl(text)) {
                val a = FloatArray(text.length + 1)
                for (i in 0 until text.length) a[i] = textPositions[i].xDirAdj / pw
                a[text.length] = x1 / pw
                cx = a
            }
            words.add(Word(nt, x0 / pw, y0 / ph, x1 / pw, y1 / ph, cx))
        }
    }

    fun start(onProgress: () -> Unit) {
        if (started) return
        started = true
        val th = Thread {
            try {
                PDFBoxResourceLoader.init(ctx.applicationContext)
                val pd = PDDocument.load(file, MemoryUsageSetting.setupTempFileOnly())
                try {
                    total = pd.numberOfPages
                    val g = Grabber()
                    g.setSortByPosition(true)
                    for (i in 0 until total) {
                        if (pd.getPage(i).rotation == 0) {
                            g.words.clear()
                            g.setStartPage(i + 1)
                            g.setEndPage(i + 1)
                            try {
                                g.getText(pd)
                            } catch (e: Exception) {
                            }
                            pages[i] = PageText(ArrayList(g.words))
                        } else {
                            pages[i] = PageText(emptyList())
                        }
                        done = i + 1
                        if (i % 4 == 0 || i == total - 1) onProgress()
                    }
                } finally {
                    pd.close()
                }
                finished = true
            } catch (e: Throwable) {
                failed = true
            }
            onProgress()
        }
        th.priority = Thread.MIN_PRIORITY
        th.start()
    }

    fun search(q0: String): List<Hit> {
        val q = TextNorm.norm(q0.trim())
        if (q.isEmpty()) return emptyList()
        val qs = if (TextNorm.hasRtl(q)) listOf(q, q.reversed()) else listOf(q)
        val out = ArrayList<Hit>()
        val keys = pages.keys.sorted()
        for (pg in keys) {
            val pt = pages[pg] ?: continue
            for (qq in qs) {
                var from = 0
                while (true) {
                    val at = pt.text.indexOf(qq, from, true)
                    if (at < 0) break
                    val rects = rectsFor(pt, at, at + qq.length)
                    if (rects.isNotEmpty()) out.add(Hit(pg, rects))
                    from = at + max(1, qq.length)
                }
            }
        }
        out.sortWith(
            compareBy<Hit>({ it.page }, { it.rects[0].top }, { it.rects[0].left })
        )
        return out
    }

    private fun rectsFor(pt: PageText, a: Int, b: Int): List<RectF> {
        val out = ArrayList<RectF>()
        for (i in pt.words.indices) {
            val w = pt.words[i]
            val s = pt.starts[i]
            val e = s + w.text.length
            val o0 = max(a, s)
            val o1 = min(b, e)
            if (o1 <= o0) continue
            val cx = w.cx
            val r = if (cx != null && cx.size == w.text.length + 1) {
                RectF(cx[o0 - s], w.y0, cx[o1 - s], w.y1)
            } else {
                RectF(w.x0, w.y0, w.x1, w.y1)
            }
            val last = if (out.isEmpty()) null else out[out.size - 1]
            if (last != null && abs(last.top - r.top) < (r.bottom - r.top) * 0.5f) {
                last.union(r)
            } else {
                out.add(r)
            }
        }
        return out
    }
}
