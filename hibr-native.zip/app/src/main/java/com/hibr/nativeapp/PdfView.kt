package com.hibr.nativeapp

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.ParcelFileDescriptor
import android.util.LruCache
import android.view.GestureDetector
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.widget.OverScroller
import com.shockwave.pdfium.PdfDocument
import com.shockwave.pdfium.PdfiumCore
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt

private fun cacheBytes(): Int {
    val m = Runtime.getRuntime().maxMemory() / 6
    return min(m, 110L * 1024L * 1024L).toInt()
}

/**
 * Native PDF view: continuous vertical pages, pinch zoom around the fingers,
 * pan, fling, double-tap zoom, tile rendering with PDFium on a worker thread.
 */
class PdfView(context: Context) : View(context) {

    interface Listener {
        fun onTap()
        fun onScrollChanged(frac: Float, page: Int, pages: Int)
        fun onOpened(pages: Int)
        fun onError(msg: String)
        fun onInkChanged()
        fun onTextSelection(text: String?) {}
        fun onToc(items: List<TocItem>) {}
        fun onOpenUri(uri: String) {}
    }

    var listener: Listener? = null
    var bgColor: Int = Color.LTGRAY

    private val core = PdfiumCore(context)

    @Volatile
    private var doc: PdfDocument? = null
    private var pfd: ParcelFileDescriptor? = null
    private val worker = Executors.newSingleThreadExecutor()
    private val opened = HashSet<Int>() // touched only on the worker thread

    private var pages = 0
    private var pw = FloatArray(0)
    private var ph = FloatArray(0)
    private var tops = FloatArray(0)
    private var hs = FloatArray(0)
    private var baseW = 0f
    private var baseH = 0f
    private val dens = context.resources.displayMetrics.density
    private val gap = 8f * dens

    var zoom = 1f
        private set
    private var sx = 0f
    private var sy = 0f

    // How far (px) the pages may be pulled down below the top of the screen. While the top bar is shown this is
    // the bar height (so the first page can rest under the bar); when the bar hides it goes to 0, so the page
    // slides up by itself and there is never an empty gap above the file.
    var topSlack = 0f
        private set
    private var slackAnim: ValueAnimator? = null
    private var slackInit = false

    private fun minScrollY(): Float = -topSlack

    private fun maxScrollY(): Float = max(0f, baseH * zoom - height)

    fun setTopSlack(px: Float, animate: Boolean) {
        slackAnim?.cancel()
        slackAnim = null
        if (!animate || width == 0 || baseH <= 0f) {
            topSlack = px
            if (!slackInit && px > 0f) {
                slackInit = true
                if (sy <= 0.5f) sy = -px
            }
            clampScroll()
            notifyScroll()
            postInvalidateOnAnimation()
            return
        }
        val a = ValueAnimator.ofFloat(topSlack, px)
        a.duration = 180
        a.interpolator = AccelerateDecelerateInterpolator()
        a.addUpdateListener { v ->
            topSlack = v.animatedValue as Float
            clampScroll()
            postInvalidateOnAnimation()
        }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                notifyScroll()
            }
        })
        slackAnim = a
        a.start()
    }

    private val minZ = 0.5f
    private val maxZ = 6f
    private val tile = 512

    private data class Key(val page: Int, val lod: Int, val tx: Int, val ty: Int)

    private val tileCache = object : LruCache<Key, Bitmap>(cacheBytes()) {
        override fun sizeOf(key: Key, value: Bitmap): Int = value.byteCount
    }
    private val lowCache = object : LruCache<Int, Bitmap>(28 * 1024 * 1024) {
        override fun sizeOf(key: Int, value: Bitmap): Int = value.byteCount
    }
    private val pending = ConcurrentHashMap<Key, Boolean>()
    private val lowPending = ConcurrentHashMap<Int, Boolean>()
    private val want = ConcurrentHashMap<Key, Int>()
    private val wantLow = ConcurrentHashMap<Int, Int>()
    private val failed = ConcurrentHashMap<Key, Boolean>()
    private val lowFailed = ConcurrentHashMap<Int, Boolean>()

    @Volatile
    private var frame = 0

    private val white = Paint().apply { color = Color.WHITE }
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.DITHER_FLAG)
    private val pagePaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.DITHER_FLAG)

    /** Dark rendering of the PDF pages (inverted, hue-corrected). Ink, images and text are not affected. */
    var pageNight = false
        set(value) {
            field = value
            pagePaint.colorFilter = if (value) ColorMatrixColorFilter(nightMatrix()) else null
            white.color = if (value) 0xFF111113.toInt() else Color.WHITE
            postInvalidateOnAnimation()
        }

    private fun nightMatrix(): ColorMatrix {
        val hue = ColorMatrix(
            floatArrayOf(
                -0.574f, 1.430f, 0.144f, 0f, 0f,
                0.426f, 0.430f, 0.144f, 0f, 0f,
                0.426f, 1.430f, -0.856f, 0f, 0f,
                0f, 0f, 0f, 1f, 0f
            )
        )
        val inv = ColorMatrix(
            floatArrayOf(
                -1f, 0f, 0f, 0f, 255f,
                0f, -1f, 0f, 0f, 255f,
                0f, 0f, -1f, 0f, 255f,
                0f, 0f, 0f, 1f, 0f
            )
        )
        val soft = ColorMatrix(
            floatArrayOf(
                0.88f, 0f, 0f, 0f, 16f,
                0f, 0.88f, 0f, 0f, 16f,
                0f, 0f, 0.88f, 0f, 16f,
                0f, 0f, 0f, 1f, 0f
            )
        )
        hue.postConcat(inv)
        hue.postConcat(soft)
        return hue
    }
    private val dstRect = RectF()

    private val scroller = OverScroller(context)
    private var scaling = false
    private var animating = false
    private val locked: Boolean
        get() = scaling || animating
    private var fallbackZoom = 1f
    private var lastFx = 0f
    private var lastFy = 0f

    // ---- ink state
    var ink: InkStore? = null
    var drawMode = false
        set(value) {
            field = value
            cancelStroke()
            if (!value) clearLasso()
        }
    var tool = Tool.PEN
        set(value) {
            if (field != value) clearLasso()
            field = value
        }
    var color = Color.rgb(214, 51, 108)
    var penWidth = 0.003f
    var hlWidth = 0.014f
    private var stylusSeen = false
    private var layoutVer = 0
    private var inkActive = false
    private var inkPointerId = -1
    private var inkSuppressed = false
    private var curPage = -1
    private var curStroke: Stroke? = null
    private val curBuf = FloatBuf()
    private var curTool = Tool.PEN
    private var lastPx = 0f
    private var lastPy = 0f
    private var downX = 0f
    private var downY = 0f
    private var downTime = 0L
    private var erasingNow = false
    var shapeOn = true
    private var snapped = false
    private var holdX = 0f
    private var holdY = 0f
    private val holdSlop = 6f * dens
    private val holdRun = Runnable { trySnap() }
    private var eraserX = 0f
    private var eraserY = 0f
    private val eraserRadius = 18f * dens
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.5f * dens
        color = 0xFF888888.toInt()
    }

    // ---- inserted images (selection / move / resize)
    var imgDir: File? = null
    private val imgCache = object : LruCache<String, Bitmap>(32 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val imgPending = ConcurrentHashMap<String, Boolean>()
    private val imgFailed = ConcurrentHashMap<String, Boolean>()
    private val imgExec = Executors.newSingleThreadExecutor()
    private val imgDst = RectF()
    private val selRect = RectF()
    private val hitRect = RectF()
    private var selPage = -1
    private var selIdx = -1
    private var selStroke: Stroke? = null
    private var selMode = 0 // 0 none, 1 move, 2 resize, 3 delete (pending)
    private var selDownX = 0f
    private var selDownY = 0f
    private var selStart = FloatArray(4)
    private var selAspect = 1f
    private var selStartWidth = 0f
    private var selTapEaten = false
    private val selPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f * dens
        color = 0xFF6F5BD8.toInt()
    }
    private val selFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF6F5BD8.toInt() }
    private val delFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFE03131.toInt() }
    private val selGlyph = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f * dens
        strokeCap = Paint.Cap.ROUND
        color = Color.WHITE
    }

    /** Called when the pencil button on a selected text box is tapped: current text, colour, size fraction. */
    var onTextEdit: ((String, Int, Float) -> Unit)? = null

    private fun isObj(st: Stroke): Boolean = st.tool == Tool.IMAGE || st.tool == Tool.TEXT

    private fun cloneStroke(st: Stroke): Stroke {
        val c = Stroke(st.tool, st.color, st.width, st.pts.copyOf())
        c.img = st.img
        c.text = st.text
        return c
    }

    private fun textLayout(text: String, widthPx: Float, sizePx: Float, col: Int): StaticLayout {
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
        tp.textSize = max(1f, sizePx)
        tp.color = col
        return StaticLayout.Builder.obtain(text, 0, text.length, tp, max(1, widthPx.toInt()))
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setLineSpacing(0f, 1.1f)
            .build()
    }

    private fun imageBitmap(name: String): Bitmap? {
        val b = imgCache.get(name)
        if (b != null) return b
        val dir = imgDir ?: return null
        if (imgFailed.containsKey(name)) return null
        if (imgPending.putIfAbsent(name, true) == null) {
            imgExec.execute {
                try {
                    val bm = BitmapFactory.decodeFile(File(dir, name).absolutePath)
                    if (bm != null) imgCache.put(name, bm) else imgFailed[name] = true
                } catch (e: Throwable) {
                    imgFailed[name] = true
                }
                imgPending.remove(name)
                postInvalidateOnAnimation()
            }
        }
        return null
    }

    private fun imgScreenRect(page: Int, a: FloatArray, out: RectF) {
        val z = zoom
        val left = offX(z) - sx + a[0] * baseW * z
        val top = tops[page] * z - sy + a[1] * hs[page] * z
        out.set(left, top, left + a[2] * baseW * z, top + a[3] * hs[page] * z)
    }

    private fun hitImage(px: Float, py: Float): Pair<Int, Int>? {
        val store = ink ?: return null
        if (pages == 0) return null
        val p = pageAtScreen(py)
        val list = store.strokes(p)
        for (k in list.indices.reversed()) {
            val st = list[k]
            if (!isObj(st)) continue
            imgScreenRect(p, st.pts, hitRect)
            if (hitRect.contains(px, py)) return Pair(p, k)
        }
        return null
    }

    private fun selectImage(page: Int, idx: Int) {
        clearLasso()
        val l = ink?.strokes(page) ?: return
        if (idx < 0 || idx >= l.size) return
        val st = l[idx]
        if (!isObj(st)) return
        selPage = page
        selIdx = idx
        selStroke = cloneStroke(st)
        selMode = 0
        postInvalidateOnAnimation()
    }

    fun clearSelection() {
        selStroke = null
        selPage = -1
        selIdx = -1
        selMode = 0
        postInvalidateOnAnimation()
    }

    /** Adds an image at the centre of what is currently visible and selects it. */
    fun insertImage(name: String, bmp: Bitmap) {
        val store = ink ?: return
        if (pages == 0 || baseW <= 0f) return
        imgCache.put(name, bmp)
        val p = pageAtScreen(height / 2f).coerceIn(0, pages - 1)
        val aspect = bmp.height.toFloat() / max(1, bmp.width).toFloat()
        var nw = 0.5f
        var nh = nw * aspect * baseW / hs[p]
        if (nh > 0.8f) {
            nh = 0.8f
            nw = nh * hs[p] / (aspect * baseW)
        }
        val cx = nxOf(width / 2f).coerceIn(0f, 1f)
        val cy = nyOf(height / 2f, p).coerceIn(0f, 1f)
        val nx = (cx - nw / 2f).coerceIn(0f, max(0f, 1f - nw))
        val ny = (cy - nh / 2f).coerceIn(0f, max(0f, 1f - nh))
        val st = Stroke(Tool.IMAGE, 0, 0f, floatArrayOf(nx, ny, nw, nh))
        st.img = name
        store.add(p, st)
        selectImage(p, store.strokes(p).size - 1)
        listener?.onInkChanged()
        postInvalidateOnAnimation()
    }

    /** Adds a text box at the centre of what is currently visible and selects it. */
    fun insertText(text: String, col: Int, sizeFrac: Float) {
        val store = ink ?: return
        if (pages == 0 || baseW <= 0f || text.isBlank()) return
        val p = pageAtScreen(height / 2f).coerceIn(0, pages - 1)
        val nw = 0.6f
        val lay = textLayout(text, nw * baseW, sizeFrac * baseW, col)
        val nh = lay.height.toFloat() / hs[p]
        val cx = nxOf(width / 2f).coerceIn(0f, 1f)
        val cy = nyOf(height / 2f, p).coerceIn(0f, 1f)
        val nx = (cx - nw / 2f).coerceIn(0f, max(0f, 1f - nw))
        val ny = (cy - nh / 2f).coerceIn(0f, max(0f, 1f - nh))
        val st = Stroke(Tool.TEXT, col, sizeFrac, floatArrayOf(nx, ny, nw, nh))
        st.text = text
        store.add(p, st)
        selectImage(p, store.strokes(p).size - 1)
        listener?.onInkChanged()
        postInvalidateOnAnimation()
    }

    /** Applies new text / colour / size to the selected text box (one undoable step). */
    fun updateSelectedText(text: String, col: Int, sizeFrac: Float) {
        val store = ink ?: return
        val ss = selStroke ?: return
        if (ss.tool != Tool.TEXT || text.isBlank()) return
        val p = selPage
        val i = selIdx
        val nw = ss.pts[2]
        val lay = textLayout(text, nw * baseW, sizeFrac * baseW, col)
        val ns = Stroke(Tool.TEXT, col, sizeFrac, floatArrayOf(ss.pts[0], ss.pts[1], nw, lay.height.toFloat() / hs[p]))
        ns.text = text
        store.replace(p, i, ns)
        selectImage(p, i)
        listener?.onInkChanged()
        postInvalidateOnAnimation()
    }

    // ---- lasso selection of pen / highlighter strokes (move / resize / delete)
    private val lassoBuf = ArrayList<Float>()
    private var lassoOn = false
    private var lsPage = -1
    private var lsIdx = IntArray(0)
    private val lsBase = ArrayList<Stroke>()
    private val lsWork = HashMap<Int, Stroke>()
    private val lsBox = RectF()
    private var lsMode = 0 // 1 move, 2 resize, 3 delete (pending)
    private var lsDownX = 0f
    private var lsDownY = 0f
    private var lsDx = 0f
    private var lsDy = 0f
    private var lsScale = 1f
    private var lsStartDx = 0f
    private var lsStartDy = 0f
    private var lsStartScale = 1f
    private val lassoPath = Path()
    private val lassoPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.5f * dens
        color = 0xFF6F5BD8.toInt()
        pathEffect = DashPathEffect(floatArrayOf(10f * dens, 6f * dens), 0f)
    }

    private fun clearLasso() {
        lassoOn = false
        lassoBuf.clear()
        lsPage = -1
        lsIdx = IntArray(0)
        lsBase.clear()
        lsWork.clear()
        lsMode = 0
        postInvalidateOnAnimation()
    }

    private fun lassoBegin(px: Float, py: Float) {
        clearSelection()
        clearLasso()
        lassoOn = true
        lassoBuf.add(px)
        lassoBuf.add(py)
    }

    private fun lassoMove(px: Float, py: Float) {
        if (!lassoOn) return
        val n = lassoBuf.size
        val dx = px - lassoBuf[n - 2]
        val dy = py - lassoBuf[n - 1]
        if (dx * dx + dy * dy < 4f * dens * dens) return
        lassoBuf.add(px)
        lassoBuf.add(py)
        postInvalidateOnAnimation()
    }

    private fun pointInPoly(x: Float, y: Float, poly: FloatArray): Boolean {
        var inside = false
        val n = poly.size / 2
        var j = n - 1
        for (i in 0 until n) {
            val xi = poly[2 * i]
            val yi = poly[2 * i + 1]
            val xj = poly[2 * j]
            val yj = poly[2 * j + 1]
            if ((yi > y) != (yj > y) && x < (xj - xi) * (y - yi) / (yj - yi) + xi) inside = !inside
            j = i
        }
        return inside
    }

    private fun lassoFinish() {
        val store = ink
        val n = lassoBuf.size / 2
        lassoOn = false
        if (store == null || n < 4 || pages == 0) {
            lassoBuf.clear()
            postInvalidateOnAnimation()
            return
        }
        val p = pageAtScreen(lassoBuf[1]).coerceIn(0, pages - 1)
        val poly = FloatArray(n * 2)
        for (i in 0 until n) {
            poly[2 * i] = (lassoBuf[2 * i] - (offX(zoom) - sx)) / zoom
            poly[2 * i + 1] = (lassoBuf[2 * i + 1] + sy) / zoom - tops[p]
        }
        lassoBuf.clear()
        val list = store.strokes(p)
        val picked = ArrayList<Int>()
        for (k in list.indices) {
            val st = list[k]
            if (st.tool != Tool.PEN && st.tool != Tool.HL) continue
            val a = st.pts
            val m = a.size / 2
            var inside = 0
            for (j in 0 until m) {
                if (pointInPoly(a[2 * j] * baseW, a[2 * j + 1] * hs[p], poly)) inside++
            }
            if (m > 0 && inside * 2 >= m) picked.add(k)
        }
        if (picked.isEmpty()) {
            postInvalidateOnAnimation()
            return
        }
        lsPage = p
        lsIdx = picked.toIntArray()
        lsBase.clear()
        lsWork.clear()
        for (k in picked) {
            val c = cloneStroke(list[k])
            lsBase.add(c)
            lsWork[k] = c
        }
        lsDx = 0f
        lsDy = 0f
        lsScale = 1f
        computeLsBox()
        postInvalidateOnAnimation()
    }

    private fun computeLsBox() {
        var l = Float.MAX_VALUE
        var t = Float.MAX_VALUE
        var r = -Float.MAX_VALUE
        var b = -Float.MAX_VALUE
        val h = hs[lsPage]
        for (st in lsBase) {
            val a = st.pts
            for (j in 0 until a.size / 2) {
                val x = a[2 * j] * baseW
                val y = a[2 * j + 1] * h
                if (x < l) l = x
                if (x > r) r = x
                if (y < t) t = y
                if (y > b) b = y
            }
        }
        lsBox.set(l, t, r, b)
    }

    private fun applyLasso() {
        val h = hs[lsPage]
        val s = lsScale
        for (k in lsBase.indices) {
            val b = lsBase[k]
            val src = b.pts
            val np = FloatArray(src.size)
            for (j in 0 until src.size / 2) {
                val x = (lsBox.left + (src[2 * j] * baseW - lsBox.left) * s + lsDx) / baseW
                val y = (lsBox.top + (src[2 * j + 1] * h - lsBox.top) * s + lsDy) / h
                np[2 * j] = x.coerceIn(0f, 1f)
                np[2 * j + 1] = y.coerceIn(0f, 1f)
            }
            lsWork[lsIdx[k]] = Stroke(b.tool, b.color, (b.width * s).coerceIn(0.0005f, 0.06f), np)
        }
    }

    private fun lsScreenRect(out: RectF) {
        val z = zoom
        val px0 = offX(z) - sx
        val py0 = tops[lsPage] * z - sy
        val l = lsBox.left + lsDx
        val t = lsBox.top + lsDy
        out.set(
            px0 + l * z,
            py0 + t * z,
            px0 + (l + lsBox.width() * lsScale) * z,
            py0 + (t + lsBox.height() * lsScale) * z
        )
        out.inset(-6f * dens, -6f * dens)
    }

    private fun handleLasso(e: MotionEvent): Boolean {
        if (lsIdx.isEmpty() || lsPage < 0) return false
        val store = ink ?: return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lsMode = 0
                lsScreenRect(selRect)
                val hr = 26f * dens
                val inset = 16f * dens
                val dxD = e.x - (selRect.right - inset)
                val dyD = e.y - (selRect.top + inset)
                val dxR = e.x - (selRect.right - inset)
                val dyR = e.y - (selRect.bottom - inset)
                if (dxD * dxD + dyD * dyD <= hr * hr) {
                    lsMode = 3
                } else if (dxR * dxR + dyR * dyR <= hr * hr) {
                    lsMode = 2
                } else if (selRect.contains(e.x, e.y)) {
                    lsMode = 1
                }
                if (lsMode == 0) {
                    clearLasso()
                    return false
                }
                scroller.forceFinished(true)
                lsDownX = e.x
                lsDownY = e.y
                lsStartDx = lsDx
                lsStartDy = lsDy
                lsStartScale = lsScale
                return true
            }
            MotionEvent.ACTION_POINTER_DOWN -> return lsMode != 0
            MotionEvent.ACTION_MOVE -> {
                if (lsMode == 0) return false
                if (lsMode == 3) return true
                val dxPx = (e.x - lsDownX) / zoom
                val dyPx = (e.y - lsDownY) / zoom
                val bw = max(1f, lsBox.width())
                val bh = max(1f, lsBox.height())
                val ph = hs[lsPage]
                if (lsMode == 1) {
                    val loX = -lsBox.left
                    val hiX = max(loX, baseW - lsBox.left - bw * lsScale)
                    val loY = -lsBox.top
                    val hiY = max(loY, ph - lsBox.top - bh * lsScale)
                    lsDx = (lsStartDx + dxPx).coerceIn(loX, hiX)
                    lsDy = (lsStartDy + dyPx).coerceIn(loY, hiY)
                } else {
                    val wc = bw * lsStartScale
                    val hc = bh * lsStartScale
                    var s = lsStartScale * (1f + (dxPx * wc + dyPx * hc) / (wc * wc + hc * hc))
                    val sMax = min((baseW - lsBox.left - lsDx) / bw, (ph - lsBox.top - lsDy) / bh)
                    s = s.coerceIn(0.2f, max(0.2f, sMax))
                    lsScale = s
                }
                applyLasso()
                postInvalidateOnAnimation()
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (lsMode == 0) return false
                val mode = lsMode
                lsMode = 0
                if (mode == 3) {
                    lsScreenRect(selRect)
                    val hr = 26f * dens
                    val dxD = e.x - (selRect.right - 16f * dens)
                    val dyD = e.y - (selRect.top + 16f * dens)
                    if (dxD * dxD + dyD * dyD <= hr * hr) {
                        val p = lsPage
                        val idx = lsIdx.toList()
                        clearLasso()
                        store.eraseBegin()
                        store.eraseRemove(p, idx)
                        store.eraseEnd()
                        listener?.onInkChanged()
                    }
                    return true
                }
                if (lsDx != lsStartDx || lsDy != lsStartDy || lsScale != lsStartScale) {
                    val ns = ArrayList<Stroke>()
                    for (k in lsIdx.indices) {
                        val w = lsWork[lsIdx[k]]
                        if (w != null) ns.add(cloneStroke(w)) else ns.add(cloneStroke(lsBase[k]))
                    }
                    store.replaceMany(lsPage, lsIdx, ns)
                    lsBase.clear()
                    lsWork.clear()
                    for (k in lsIdx.indices) {
                        val c = cloneStroke(ns[k])
                        lsBase.add(c)
                        lsWork[lsIdx[k]] = c
                    }
                    lsDx = 0f
                    lsDy = 0f
                    lsScale = 1f
                    computeLsBox()
                    listener?.onInkChanged()
                }
                postInvalidateOnAnimation()
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                if (lsMode == 0) return false
                lsMode = 0
                lsDx = lsStartDx
                lsDy = lsStartDy
                lsScale = lsStartScale
                applyLasso()
                postInvalidateOnAnimation()
                return true
            }
        }
        return false
    }

    private fun drawLassoOverlay(c: Canvas) {
        if (lassoOn && lassoBuf.size >= 4) {
            lassoPath.reset()
            lassoPath.moveTo(lassoBuf[0], lassoBuf[1])
            var i = 1
            while (i < lassoBuf.size / 2) {
                lassoPath.lineTo(lassoBuf[2 * i], lassoBuf[2 * i + 1])
                i++
            }
            c.drawPath(lassoPath, lassoPaint)
        }
        if (lsIdx.isNotEmpty() && lsPage >= 0 && lsPage < pages) {
            lsScreenRect(selRect)
            c.drawRect(selRect, selPaint)
            val hr = 13f * dens
            val inset = 16f * dens
            val rx = selRect.right - inset
            val by = selRect.bottom - inset
            val ty = selRect.top + inset
            c.drawCircle(rx, by, hr, selFill)
            c.drawLine(rx - hr * 0.45f, by + hr * 0.45f, rx + hr * 0.45f, by - hr * 0.45f, selGlyph)
            c.drawCircle(rx, ty, hr, delFill)
            val d = hr * 0.4f
            c.drawLine(rx - d, ty - d, rx + d, ty + d, selGlyph)
            c.drawLine(rx - d, ty + d, rx + d, ty - d, selGlyph)
        }
    }

    // ---- text search hits + text selection (long press) ----
    var textIndex: TextIndex? = null
    private var hitList: List<Hit> = emptyList()
    private var hitCur = -1
    private val hitsByPage = HashMap<Int, ArrayList<IntArray>>()
    private val hitRects = ArrayList<RectF>()
    private val hitRectOwner = ArrayList<Int>()
    private val hitRectPage = ArrayList<Int>()
    private val hitPaint = Paint().apply { color = 0x66FFD400 }
    private val hitCurPaint = Paint().apply { color = 0xAAFF8A00.toInt() }
    private val tsPaint = Paint().apply { color = 0x553D7BFF }
    private var tsActive = false
    private var tsDragging = false
    private var tsPage = -1
    private var tsA = 0
    private var tsB = 0
    private val tsRects = ArrayList<RectF>()
    private val ovRect = RectF()

    fun pageCount(): Int = pages

    /** Clears image / lasso / text selections. Returns true if something was selected (used by the Back button). */
    fun clearAllSelection(): Boolean {
        var any = false
        if (selStroke != null) {
            clearSelection()
            any = true
        }
        if (lsIdx.isNotEmpty()) {
            clearLasso()
            any = true
        }
        if (tsActive) {
            clearTextSelection()
            any = true
        }
        return any
    }

    /** Renders a small bitmap of one page on the worker thread; cb runs on the UI thread (null on failure). */
    fun renderThumb(i: Int, w: Int, cb: (Bitmap?) -> Unit) {
        val d = doc
        if (d == null || i < 0 || i >= pages) {
            cb(null)
            return
        }
        val aspect = ph[i] / pw[i]
        try {
            worker.execute {
                var out: Bitmap? = null
                try {
                    ensureOpen(d, i)
                    val h = max(1, (w * aspect).roundToInt())
                    val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                    b.eraseColor(Color.WHITE)
                    core.renderPageBitmap(d, b, i, 0, 0, w, h, false)
                    out = b
                } catch (e: Throwable) {
                }
                post { cb(out) }
            }
        } catch (e: Throwable) {
            cb(null)
        }
    }

    fun currentPage(): Int = if (pages == 0) 0 else pageAt((sy + height * 0.35f) / zoom)

    fun setHits(h: List<Hit>, cur: Int) {
        hitList = h
        hitCur = cur
        hitRects.clear()
        hitRectOwner.clear()
        hitRectPage.clear()
        for (k in h.indices) {
            for (r in h[k].rects) {
                hitRects.add(r)
                hitRectOwner.add(k)
                hitRectPage.add(h[k].page)
            }
        }
        postInvalidateOnAnimation()
    }

    fun setCurrentHit(cur: Int) {
        hitCur = cur
        postInvalidateOnAnimation()
    }

    /** Scrolls so that the given hit is comfortably visible. */
    fun goToHit(k: Int) {
        if (k < 0 || k >= hitList.size || pages == 0) return
        val h = hitList[k]
        if (h.page < 0 || h.page >= pages || h.rects.isEmpty()) return
        val r = h.rects[0]
        val z = zoom
        val yDoc = tops[h.page] + r.top * hs[h.page]
        val xc = (r.left + r.right) / 2f
        scroller.forceFinished(true)
        sy = yDoc * z - height * 0.35f
        if (baseW * z > width) sx = offX(z) + xc * baseW * z - width / 2f
        clampScroll()
        hitCur = k
        notifyScroll()
        postInvalidateOnAnimation()
    }

    // ---- links & navigation
    private val linksCache = java.util.concurrent.ConcurrentHashMap<Int, List<LinkRect>>()
    private val linksAsked = java.util.concurrent.ConcurrentHashMap<Int, Boolean>()

    private fun requestLinks(i: Int) {
        if (linksAsked.putIfAbsent(i, true) != null) return
        val d = doc ?: return
        worker.execute {
            try {
                ensureOpen(d, i)
                val raw = core.getPageLinks(d, i)
                val out = ArrayList<LinkRect>()
                for (l in raw) {
                    val b = l.bounds ?: continue
                    val r = core.mapRectToDevice(d, i, 0, 0, 10000, 10000, 0, b)
                    val rr = RectF(
                        min(r.left, r.right) / 10000f,
                        min(r.top, r.bottom) / 10000f,
                        max(r.left, r.right) / 10000f,
                        max(r.top, r.bottom) / 10000f
                    )
                    val dest = l.destPageIdx
                    out.add(LinkRect(rr, if (dest != null) dest.toInt() else -1, l.uri))
                }
                linksCache[i] = out
            } catch (e: Throwable) {
                linksCache[i] = emptyList()
            }
        }
    }

    private fun linkAt(px: Float, py: Float): LinkRect? {
        if (pages == 0) return null
        val p = pageAtScreen(py)
        val lk = linksCache[p] ?: return null
        val nx = nxOf(px)
        val ny = nyOf(py, p)
        for (l in lk) if (l.rect.contains(nx, ny)) return l
        return null
    }

    fun goToPage(p: Int) {
        if (pages == 0) return
        val k = p.coerceIn(0, pages - 1)
        scroller.forceFinished(true)
        sy = tops[k] * zoom - (if (topSlack > 0f) topSlack else 0f)
        clampScroll()
        notifyScroll()
        postInvalidateOnAnimation()
    }

    private fun drawOverlay(canvas: Canvas, i: Int, left: Float, top: Float, z: Float) {
        var any = false
        for (n in hitRects.indices) if (hitRectPage[n] == i) {
            any = true
            break
        }
        if (!any && !(tsActive && tsPage == i)) return
        canvas.save()
        canvas.translate(left, top)
        canvas.scale(z, z)
        val ph = hs[i]
        for (n in hitRects.indices) {
            if (hitRectPage[n] != i) continue
            val r = hitRects[n]
            ovRect.set(r.left * baseW, r.top * ph, r.right * baseW, r.bottom * ph)
            canvas.drawRect(ovRect, if (hitRectOwner[n] == hitCur) hitCurPaint else hitPaint)
        }
        if (tsActive && tsPage == i) {
            for (r in tsRects) {
                ovRect.set(r.left * baseW, r.top * ph, r.right * baseW, r.bottom * ph)
                canvas.drawRect(ovRect, tsPaint)
            }
        }
        canvas.restore()
    }

    private fun wordNear(page: Int, px: Float, py: Float, strict: Boolean): Int {
        val pt = textIndex?.pages?.get(page) ?: return -1
        if (pt.words.isEmpty()) return -1
        val nx = nxOf(px)
        val ny = nyOf(py, page)
        var best = -1
        var bestD = Float.MAX_VALUE
        for (i in pt.words.indices) {
            val w = pt.words[i]
            val dx = if (nx < w.x0) w.x0 - nx else if (nx > w.x1) nx - w.x1 else 0f
            val dy = if (ny < w.y0) w.y0 - ny else if (ny > w.y1) ny - w.y1 else 0f
            val d = dx * baseW + dy * hs[page]
            if (d < bestD) {
                bestD = d
                best = i
            }
        }
        if (strict && bestD > 10f * dens / zoom) return -1
        return best
    }

    private fun rebuildTsRects() {
        tsRects.clear()
        val pt = textIndex?.pages?.get(tsPage) ?: return
        val a = min(tsA, tsB)
        val b = max(tsA, tsB)
        var last: RectF? = null
        for (i in a..b) {
            if (i < 0 || i >= pt.words.size) continue
            val w = pt.words[i]
            val r = RectF(w.x0, w.y0, w.x1, w.y1)
            val l = last
            if (l != null && Math.abs(l.top - r.top) < (r.bottom - r.top) * 0.5f) {
                l.union(r)
            } else {
                tsRects.add(r)
                last = r
            }
        }
    }

    private fun beginTextSelect(px: Float, py: Float): Boolean {
        if (pages == 0) return false
        val p = pageAtScreen(py)
        val w = wordNear(p, px, py, true)
        if (w < 0) return false
        clearSelection()
        clearLasso()
        tsPage = p
        tsA = w
        tsB = w
        tsActive = true
        tsDragging = true
        rebuildTsRects()
        postInvalidateOnAnimation()
        return true
    }

    private fun extendTextSelect(px: Float, py: Float) {
        if (!tsActive) return
        val w = wordNear(tsPage, px, py, false)
        if (w < 0 || w == tsB) return
        tsB = w
        rebuildTsRects()
        postInvalidateOnAnimation()
    }

    fun selectionText(): String {
        val pt = textIndex?.pages?.get(tsPage) ?: return ""
        if (!tsActive) return ""
        val a = min(tsA, tsB)
        val b = max(tsA, tsB)
        val sb = StringBuilder()
        var prev: Word? = null
        for (i in a..b) {
            if (i < 0 || i >= pt.words.size) continue
            val w = pt.words[i]
            val pr = prev
            if (pr != null) {
                if (Math.abs(pr.y0 - w.y0) < (w.y1 - w.y0) * 0.5f) sb.append(' ') else sb.append('\n')
            }
            sb.append(w.text)
            prev = w
        }
        return sb.toString()
    }

    fun clearTextSelection() {
        if (!tsActive) return
        tsActive = false
        tsDragging = false
        tsRects.clear()
        listener?.onTextSelection(null)
        postInvalidateOnAnimation()
    }

    /** Turns the selected text into highlighter strokes that follow the text lines (one undo step). */
    fun highlightSelection(col: Int) {
        val store = ink ?: return
        if (!tsActive || tsPage < 0 || pages == 0) return
        val p = tsPage
        val out = ArrayList<Stroke>()
        for (r in tsRects) {
            val wFrac = (r.bottom - r.top) * hs[p] / baseW
            val half = wFrac / 2f
            var xa = r.left + half
            var xb = r.right - half
            if (xb < xa) {
                val m = (r.left + r.right) / 2f
                xa = m
                xb = m
            }
            val yc = (r.top + r.bottom) / 2f
            out.add(Stroke(Tool.HL, col, wFrac, floatArrayOf(xa, yc, xb, yc)))
        }
        store.addMany(p, out)
        clearTextSelection()
        listener?.onInkChanged()
        postInvalidateOnAnimation()
    }

    private fun deleteSelected() {
        val store = ink ?: return
        val p = selPage
        val i = selIdx
        clearSelection()
        store.eraseBegin()
        store.eraseRemove(p, listOf(i))
        store.eraseEnd()
        listener?.onInkChanged()
        postInvalidateOnAnimation()
    }

    private fun handleSel(e: MotionEvent): Boolean {
        val ss = selStroke ?: return false
        val store = ink ?: return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                selMode = 0
                imgScreenRect(selPage, ss.pts, selRect)
                val hr = 26f * dens
                val inset = 16f * dens
                val dxD = e.x - (selRect.right - inset)
                val dyD = e.y - (selRect.top + inset)
                val dxR = e.x - (selRect.right - inset)
                val dyR = e.y - (selRect.bottom - inset)
                val dxE = e.x - (selRect.left + inset)
                val dyE = e.y - (selRect.top + inset)
                if (dxD * dxD + dyD * dyD <= hr * hr) {
                    selMode = 3
                } else if (ss.tool == Tool.TEXT && dxE * dxE + dyE * dyE <= hr * hr) {
                    selMode = 4
                } else if (dxR * dxR + dyR * dyR <= hr * hr) {
                    selMode = 2
                } else if (selRect.contains(e.x, e.y)) {
                    selMode = 1
                }
                if (selMode == 0) {
                    clearSelection()
                    selTapEaten = true
                    return false
                }
                scroller.forceFinished(true)
                selDownX = e.x
                selDownY = e.y
                selStart = ss.pts.copyOf()
                selStartWidth = ss.width
                selAspect = (selStart[3] * hs[selPage]) / max(0.0001f, selStart[2] * baseW)
                return true
            }
            MotionEvent.ACTION_POINTER_DOWN -> return selMode != 0
            MotionEvent.ACTION_MOVE -> {
                if (selMode == 0) return false
                if (selMode == 3 || selMode == 4) return true
                val dx = (e.x - selDownX) / (zoom * baseW)
                val dy = (e.y - selDownY) / (zoom * hs[selPage])
                val q = ss.pts
                if (selMode == 1) {
                    q[0] = (selStart[0] + dx).coerceIn(0f, max(0f, 1f - q[2]))
                    q[1] = (selStart[1] + dy).coerceIn(0f, max(0f, 1f - q[3]))
                } else {
                    var nw = (selStart[2] + dx).coerceIn(0.06f, max(0.06f, 1f - selStart[0]))
                    var nh = nw * selAspect * baseW / hs[selPage]
                    val maxH = max(0.03f, 1f - selStart[1])
                    if (nh > maxH) {
                        nh = maxH
                        nw = nh * hs[selPage] / (selAspect * baseW)
                    }
                    q[2] = nw
                    q[3] = nh
                    if (ss.tool == Tool.TEXT) ss.width = selStartWidth * nw / max(0.0001f, selStart[2])
                }
                postInvalidateOnAnimation()
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (selMode == 0) return false
                val mode = selMode
                selMode = 0
                if (mode == 4) {
                    imgScreenRect(selPage, ss.pts, selRect)
                    val hr4 = 26f * dens
                    val dxE = e.x - (selRect.left + 16f * dens)
                    val dyE = e.y - (selRect.top + 16f * dens)
                    if (dxE * dxE + dyE * dyE <= hr4 * hr4) onTextEdit?.invoke(ss.text ?: "", ss.color, ss.width)
                    return true
                }
                if (mode == 3) {
                    imgScreenRect(selPage, ss.pts, selRect)
                    val hr = 26f * dens
                    val dxD = e.x - (selRect.right - 16f * dens)
                    val dyD = e.y - (selRect.top + 16f * dens)
                    if (dxD * dxD + dyD * dyD <= hr * hr) deleteSelected()
                    return true
                }
                var changed = false
                for (k in 0 until 4) if (Math.abs(ss.pts[k] - selStart[k]) > 0.0005f) changed = true
                if (changed) {
                    store.replace(selPage, selIdx, cloneStroke(ss))
                    listener?.onInkChanged()
                }
                postInvalidateOnAnimation()
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                if (selMode == 0) return false
                selMode = 0
                for (k in 0 until 4) ss.pts[k] = selStart[k]
                ss.width = selStartWidth
                postInvalidateOnAnimation()
                return true
            }
        }
        return false
    }

    private fun drawSelection(c: Canvas) {
        val ss = selStroke ?: return
        if (selPage < 0 || selPage >= pages) return
        imgScreenRect(selPage, ss.pts, selRect)
        c.drawRect(selRect, selPaint)
        val hr = 13f * dens
        val inset = 16f * dens
        val rx = selRect.right - inset
        val by = selRect.bottom - inset
        val ty = selRect.top + inset
        c.drawCircle(rx, by, hr, selFill)
        c.drawLine(rx - hr * 0.45f, by + hr * 0.45f, rx + hr * 0.45f, by - hr * 0.45f, selGlyph)
        c.drawCircle(rx, ty, hr, delFill)
        val d = hr * 0.4f
        c.drawLine(rx - d, ty - d, rx + d, ty + d, selGlyph)
        c.drawLine(rx - d, ty + d, rx + d, ty - d, selGlyph)
        if (ss.tool == Tool.TEXT) {
            val lx = selRect.left + inset
            c.drawCircle(lx, ty, hr, selFill)
            c.drawLine(lx - d, ty + d, lx + d, ty - d, selGlyph)
            c.drawLine(lx - d, ty + d, lx - d * 0.2f, ty + d, selGlyph)
        }
    }

    private val scaleDetector = ScaleGestureDetector(
        context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
                scaling = true
                scroller.forceFinished(true)
                lastFx = detector.focusX
                lastFy = detector.focusY
                return true
            }

            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val nz = (zoom * detector.scaleFactor).coerceIn(minZ, maxZ)
                zoomAbout(lastFx, lastFy, detector.focusX, detector.focusY, nz)
                lastFx = detector.focusX
                lastFy = detector.focusY
                return true
            }

            override fun onScaleEnd(detector: ScaleGestureDetector) {
                scaling = false
                postInvalidateOnAnimation()
            }
        }
    ).apply { isQuickScaleEnabled = false }

    private val gestureDetector = GestureDetector(
        context,
        object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean {
                scroller.forceFinished(true)
                return true
            }

            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float): Boolean {
                if (scaling || scaleDetector.isInProgress) return false
                sx += distanceX
                sy += distanceY
                clampScroll()
                notifyScroll()
                postInvalidateOnAnimation()
                return true
            }

            override fun onFling(e1: MotionEvent?, e2: MotionEvent, velocityX: Float, velocityY: Float): Boolean {
                if (scaling || scaleDetector.isInProgress) return false
                val maxX = max(0f, baseW * zoom - width).toInt()
                val maxY = maxScrollY().toInt()
                scroller.fling(sx.toInt(), sy.toInt(), (-velocityX).toInt(), (-velocityY).toInt(), 0, maxX, minScrollY().toInt(), maxY)
                postInvalidateOnAnimation()
                return true
            }

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (selTapEaten) {
                    selTapEaten = false
                    return true
                }
                if (tsActive) {
                    clearTextSelection()
                    return true
                }
                if (!drawMode) {
                    val h = hitImage(e.x, e.y)
                    if (h != null) {
                        selectImage(h.first, h.second)
                        return true
                    }
                    val lk = linkAt(e.x, e.y)
                    if (lk != null) {
                        if (lk.page >= 0) {
                            goToPage(lk.page)
                        } else if (lk.uri != null) {
                            listener?.onOpenUri(lk.uri)
                        }
                        return true
                    }
                }
                listener?.onTap()
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                animateZoomTo(if (zoom < 1.4f) 2.5f else 1f, e.x, e.y)
                return true
            }

            override fun onLongPress(e: MotionEvent) {
                if (!drawMode && textIndex != null && beginTextSelect(e.x, e.y)) {
                    performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                } else {
                    recenter()
                }
            }
        }
    )

    // ---------------------------------------------------------------- open / close

    fun open(file: File, page: Int, frac: Float) {
        worker.execute {
            try {
                val d = core.newDocument(file.readBytes())
                val n = core.getPageCount(d)
                val w = FloatArray(n)
                val h = FloatArray(n)
                for (i in 0 until n) {
                    val s = core.getPageSize(d, i)
                    w[i] = if (s.width > 0) s.width.toFloat() else 612f
                    h[i] = if (s.height > 0) s.height.toFloat() else 792f
                }
                val toc = ArrayList<TocItem>()
                try {
                    Toc.flatten(core.getTableOfContents(d), 0, toc)
                } catch (e: Throwable) {
                }
                post {
                    doc = d
                    pages = n
                    pw = w
                    ph = h
                    if (width > 0) {
                        relayout()
                        applyAnchor(page.coerceIn(0, max(0, n - 1)), frac)
                    } else {
                        pendingAnchorPage = page
                        pendingAnchorFrac = frac
                    }
                    listener?.onOpened(n)
                    listener?.onToc(toc)
                    notifyScroll()
                    invalidate()
                }
            } catch (e: Throwable) {
                val msg = e.javaClass.simpleName + ": " + (e.message ?: "")
                post { listener?.onError(msg) }
            }
        }
    }

    private var pendingAnchorPage = -1
    private var pendingAnchorFrac = 0f

    fun release() {
        val d = doc
        val f = pfd
        doc = null
        pfd = null
        worker.execute {
            try {
                if (d != null) core.closeDocument(d)
            } catch (e: Throwable) {
            }
            try {
                f?.close()
            } catch (e: Throwable) {
            }
        }
        worker.shutdown()
        imgExec.shutdown()
        imgCache.evictAll()
        tileCache.evictAll()
        lowCache.evictAll()
    }

    // ---------------------------------------------------------------- layout

    private fun relayout() {
        baseW = width.toFloat()
        tops = FloatArray(pages)
        hs = FloatArray(pages)
        var y = 0f
        for (i in 0 until pages) {
            tops[i] = y
            hs[i] = baseW * ph[i] / pw[i]
            y += hs[i] + gap
        }
        baseH = max(0f, y - gap)
        layoutVer++
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        if (lsIdx.isNotEmpty()) clearLasso()
        if (pages > 0 && w > 0 && baseW > 0f) {
            val a = anchor()
            relayout()
            applyAnchor(a.first, a.second)
            postInvalidateOnAnimation()
        } else if (pages > 0 && w > 0) {
            relayout()
            if (pendingAnchorPage >= 0) {
                applyAnchor(pendingAnchorPage.coerceIn(0, pages - 1), pendingAnchorFrac)
                pendingAnchorPage = -1
            }
            notifyScroll()
            postInvalidateOnAnimation()
        }
    }

    fun anchor(): Pair<Int, Float> {
        if (pages == 0) return Pair(0, 0f)
        val byy = sy / zoom
        val p = pageAt(byy)
        val f = ((byy - tops[p]) / hs[p]).coerceIn(0f, 1f)
        return Pair(p, f)
    }

    private fun applyAnchor(p: Int, f: Float) {
        if (pages == 0) return
        sy = (tops[p] + f * hs[p]) * zoom
        if (p == 0 && f < 0.001f) sy = minScrollY()
        sx = 0f
        clampScroll()
    }

    private fun offX(z: Float): Float = max(0f, (width - baseW * z) / 2f)

    private fun clampScroll() {
        val maxX = max(0f, baseW * zoom - width)
        val maxY = maxScrollY()
        sx = sx.coerceIn(0f, maxX)
        sy = sy.coerceIn(minScrollY(), maxY)
    }

    private fun pageAt(byy: Float): Int {
        var lo = 0
        var hi = pages - 1
        while (lo < hi) {
            val mid = (lo + hi + 1) ushr 1
            if (tops[mid] <= byy) lo = mid else hi = mid - 1
        }
        return lo
    }

    private fun notifyScroll() {
        if (pages == 0) return
        val maxY = maxScrollY()
        val frac = if (maxY > 0f) (sy / maxY).coerceIn(0f, 1f) else 0f
        val page = pageAt((sy + height * 0.35f) / zoom)
        listener?.onScrollChanged(frac, page, pages)
    }

    fun scrollToFraction(f: Float) {
        val maxY = maxScrollY()
        sy = f.coerceIn(0f, 1f) * maxY
        clampScroll()
        notifyScroll()
        postInvalidateOnAnimation()
    }

    // ---------------------------------------------------------------- zoom

    private fun zoomAbout(fxOld: Float, fyOld: Float, fxNew: Float, fyNew: Float, nz: Float) {
        val bx = (fxOld - offX(zoom) + sx) / zoom
        val byy = (fyOld + sy) / zoom
        zoom = nz
        sx = offX(nz) + bx * nz - fxNew
        sy = byy * nz - fyNew
        clampScroll()
        notifyScroll()
        postInvalidateOnAnimation()
    }

    private fun animateZoomTo(target: Float, fx: Float, fy: Float) {
        val z0 = zoom
        val t = target.coerceIn(minZ, maxZ)
        animating = true
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 240
        a.interpolator = DecelerateInterpolator()
        a.addUpdateListener { v ->
            val f = v.animatedFraction
            zoomAbout(fx, fy, fx, fy, z0 + (t - z0) * f)
        }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                animating = false
                postInvalidateOnAnimation()
            }
        })
        a.start()
    }

    private fun recenter() {
        val maxX = baseW * zoom - width
        if (maxX <= 2f) return
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        val from = sx
        val to = maxX / 2f
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 240
        a.interpolator = DecelerateInterpolator()
        a.addUpdateListener { v ->
            sx = from + (to - from) * v.animatedFraction
            clampScroll()
            postInvalidateOnAnimation()
        }
        a.start()
    }

    // ---------------------------------------------------------------- ink

    fun undoInk() {
        clearSelection()
        clearLasso()
        if (ink?.undo() == true) {
            listener?.onInkChanged()
            postInvalidateOnAnimation()
        }
    }

    fun redoInk() {
        clearSelection()
        clearLasso()
        if (ink?.redo() == true) {
            listener?.onInkChanged()
            postInvalidateOnAnimation()
        }
    }

    private fun pageAtScreen(py: Float): Int = pageAt((py + sy) / zoom)

    private fun nxOf(px: Float): Float = ((px - offX(zoom) + sx) / zoom) / baseW

    private fun nyOf(py: Float, p: Int): Float = (((py + sy) / zoom) - tops[p]) / hs[p]

    private fun handleInk(e: MotionEvent): Boolean {
        val store = ink ?: return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                inkSuppressed = false
                val stylus = e.getToolType(0) == MotionEvent.TOOL_TYPE_STYLUS
                if (stylus) stylusSeen = true
                if (!stylus && stylusSeen) {
                    inkSuppressed = true
                    return false
                }
                scroller.forceFinished(true)
                inkPointerId = e.getPointerId(0)
                downX = e.x
                downY = e.y
                downTime = e.eventTime
                val eraserBtn = (e.buttonState and MotionEvent.BUTTON_STYLUS_PRIMARY) != 0
                curTool = if (eraserBtn) Tool.ERASER else tool
                inkActive = true
                if (curTool == Tool.SELECT) {
                    lassoBegin(e.x, e.y)
                    return true
                }
                if (curTool == Tool.ERASER) {
                    store.eraseBegin()
                    erasingNow = true
                    eraseAt(e.x, e.y)
                } else {
                    beginStroke(e.x, e.y)
                }
                return true
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                if (inkActive) cancelStroke()
                inkSuppressed = true
                return false
            }
            MotionEvent.ACTION_MOVE -> {
                if (inkSuppressed || !inkActive) return false
                val idx = e.findPointerIndex(inkPointerId)
                if (idx < 0) return true
                for (h in 0 until e.historySize) {
                    moveInk(e.getHistoricalX(idx, h), e.getHistoricalY(idx, h))
                }
                moveInk(e.getX(idx), e.getY(idx))
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (inkSuppressed) {
                    inkSuppressed = false
                    return false
                }
                if (!inkActive) return false
                val stylus = e.getToolType(0) == MotionEvent.TOOL_TYPE_STYLUS
                val moved = Math.hypot((e.x - downX).toDouble(), (e.y - downY).toDouble())
                val quick = !stylus && (e.eventTime - downTime) < 250 && moved < 12 * dens
                if (quick) {
                    cancelStroke()
                    listener?.onTap()
                } else {
                    endStroke()
                }
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                cancelStroke()
                inkSuppressed = false
                return true
            }
        }
        return false
    }

    private fun beginStroke(px: Float, py: Float) {
        curPage = pageAtScreen(py)
        curBuf.clear()
        lastPx = px
        lastPy = py
        curBuf.add(nxOf(px).coerceIn(0f, 1f), nyOf(py, curPage).coerceIn(0f, 1f))
        updateCur()
        snapped = false
        holdX = px
        holdY = py
        removeCallbacks(holdRun)
        if (shapeOn) postDelayed(holdRun, 550)
    }

    private fun moveInk(px: Float, py: Float) {
        if (curTool == Tool.SELECT) {
            lassoMove(px, py)
            return
        }
        if (curTool == Tool.ERASER) {
            eraseAt(px, py)
            return
        }
        if (snapped) return
        if (shapeOn) {
            val hx = px - holdX
            val hy = py - holdY
            if (hx * hx + hy * hy > holdSlop * holdSlop) {
                holdX = px
                holdY = py
                removeCallbacks(holdRun)
                postDelayed(holdRun, 550)
            }
        }
        val dx = px - lastPx
        val dy = py - lastPy
        if (dx * dx + dy * dy < 2.25f) return
        lastPx = px
        lastPy = py
        curBuf.add(nxOf(px).coerceIn(0f, 1f), nyOf(py, curPage).coerceIn(0f, 1f))
        updateCur()
    }

    private fun updateCur() {
        val w = if (curTool == Tool.HL) hlWidth else penWidth
        curStroke = Stroke(curTool, color, w, curBuf.toArray())
        postInvalidateOnAnimation()
    }

    private fun trySnap() {
        if (!inkActive || snapped || curTool == Tool.ERASER || curPage < 0) return
        val src = curBuf.toArray()
        if (src.size < 12) return
        val w = baseW
        val h = hs[curPage]
        val pp = FloatArray(src.size)
        for (i in 0 until src.size / 2) {
            pp[2 * i] = src[2 * i] * w
            pp[2 * i + 1] = src[2 * i + 1] * h
        }
        val out = Shapes.snap(pp, 24f * dens / zoom) ?: return
        val np = FloatArray(out.size)
        for (i in 0 until out.size / 2) {
            np[2 * i] = (out[2 * i] / w).coerceIn(0f, 1f)
            np[2 * i + 1] = (out[2 * i + 1] / h).coerceIn(0f, 1f)
        }
        val wd = if (curTool == Tool.HL) hlWidth else penWidth
        curStroke = Stroke(curTool, color, wd, np)
        snapped = true
        performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
        postInvalidateOnAnimation()
    }

    private fun endStroke() {
        removeCallbacks(holdRun)
        snapped = false
        if (curTool == Tool.SELECT) {
            lassoFinish()
            inkActive = false
            curPage = -1
            return
        }
        val store = ink
        if (curTool == Tool.ERASER) {
            store?.eraseEnd()
            erasingNow = false
        } else {
            val s = curStroke
            if (s != null && store != null) store.add(curPage, s)
        }
        curStroke = null
        inkActive = false
        curPage = -1
        listener?.onInkChanged()
        postInvalidateOnAnimation()
    }

    private fun cancelStroke() {
        removeCallbacks(holdRun)
        snapped = false
        if (lassoOn) {
            lassoOn = false
            lassoBuf.clear()
        }
        if (curTool == Tool.ERASER && erasingNow) {
            ink?.eraseEnd()
            erasingNow = false
            listener?.onInkChanged()
        }
        curStroke = null
        inkActive = false
        curPage = -1
        postInvalidateOnAnimation()
    }

    private fun eraseAt(px: Float, py: Float) {
        val store = ink ?: return
        if (pages == 0) return
        eraserX = px
        eraserY = py
        val p = pageAtScreen(py)
        val bx = nxOf(px) * baseW
        val byy = nyOf(py, p) * hs[p]
        val r = eraserRadius / zoom
        val list = store.strokes(p)
        var hits: ArrayList<Int>? = null
        for (k in list.indices) {
            val s = list[k]
            if (s.tool == Tool.IMAGE || s.tool == Tool.TEXT) continue
            val rr = r + s.width * baseW / 2f
            val a = s.pts
            var hit = false
            var i = 0
            while (i < a.size) {
                val dx = a[i] * baseW - bx
                val dy = a[i + 1] * hs[p] - byy
                if (dx * dx + dy * dy <= rr * rr) {
                    hit = true
                    break
                }
                i += 2
            }
            if (hit) {
                if (hits == null) hits = ArrayList()
                hits.add(k)
            }
        }
        if (hits != null) {
            store.eraseRemove(p, hits)
            listener?.onInkChanged()
        }
        postInvalidateOnAnimation()
    }

    private fun buildPath(s: Stroke, page: Int): Path {
        val p = Path()
        val a = s.pts
        val n = a.size / 2
        val h = hs[page]
        var px = a[0] * baseW
        var py = a[1] * h
        p.moveTo(px, py)
        if (n == 1) {
            p.lineTo(px + 0.01f, py)
            return p
        }
        for (i in 1 until n) {
            val x = a[2 * i] * baseW
            val y = a[2 * i + 1] * h
            p.quadTo(px, py, (px + x) / 2f, (py + y) / 2f)
            px = x
            py = y
        }
        p.lineTo(px, py)
        return p
    }

    private fun drawStroke(c: Canvas, s: Stroke, page: Int) {
        if (s.tool == Tool.TEXT) {
            val t = s.text ?: return
            val a = s.pts
            val lay = textLayout(t, a[2] * baseW, s.width * baseW, s.color)
            c.save()
            c.translate(a[0] * baseW, a[1] * hs[page])
            lay.draw(c)
            c.restore()
            return
        }
        if (s.tool == Tool.IMAGE) {
            val name = s.img ?: return
            val bm = imageBitmap(name) ?: return
            val a = s.pts
            val ph0 = hs[page]
            imgDst.set(a[0] * baseW, a[1] * ph0, (a[0] + a[2]) * baseW, (a[1] + a[3]) * ph0)
            c.drawBitmap(bm, null, imgDst, bmpPaint)
            return
        }
        val cached = s.path
        val path: Path = if (cached != null && s.pathVer == layoutVer) {
            cached
        } else {
            val np = buildPath(s, page)
            s.path = np
            s.pathVer = layoutVer
            np
        }
        strokePaint.color = s.color
        strokePaint.alpha = if (s.tool == Tool.HL) 102 else 255
        strokePaint.strokeWidth = s.width * baseW
        c.drawPath(path, strokePaint)
    }

    private fun drawInk(c: Canvas, i: Int, left: Float, top: Float, z: Float) {
        val store = ink ?: return
        val list = store.strokes(i)
        val cur = curStroke
        val showCur = cur != null && curPage == i
        if (list.isEmpty() && !showCur) return
        c.save()
        c.translate(left, top)
        c.scale(z, z)
        val sel = selStroke
        for (k in list.indices) {
            val s0 = list[k]
            val s1 = if (sel != null && selPage == i && selIdx == k) sel else if (lsPage == i) (lsWork[k] ?: s0) else s0
            drawStroke(c, s1, i)
        }
        if (showCur && cur != null) {
            cur.pathVer = -1
            drawStroke(c, cur, i)
        }
        c.restore()
    }

    // ---------------------------------------------------------------- input

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (doc == null) return true
        if (e.actionMasked == MotionEvent.ACTION_DOWN) selTapEaten = false
        if (selStroke != null && handleSel(e)) return true
        if (lsIdx.isNotEmpty() && handleLasso(e)) return true
        if (tsDragging) {
            when (e.actionMasked) {
                MotionEvent.ACTION_MOVE -> extendTextSelect(e.x, e.y)
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    tsDragging = false
                    listener?.onTextSelection(selectionText())
                }
            }
            return true
        }
        scaleDetector.onTouchEvent(e)
        if (drawMode && ink != null && handleInk(e)) return true
        gestureDetector.onTouchEvent(e)
        return true
    }

    override fun computeScroll() {
        if (scroller.computeScrollOffset()) {
            sx = scroller.currX.toFloat()
            sy = scroller.currY.toFloat()
            clampScroll()
            notifyScroll()
            postInvalidateOnAnimation()
        }
    }

    // ---------------------------------------------------------------- drawing

    private fun lodFor(i: Int, z: Float): Int {
        val r = (baseW * z / pw[i]).toDouble()
        return (2.0 * ln(r) / ln(2.0)).roundToInt()
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(bgColor)
        if (doc == null || pages == 0 || baseW <= 0f) return
        frame++
        val z = zoom
        val ox = offX(z)
        val first = pageAt(sy / z)
        val last = pageAt((sy + height) / z)
        var allReady = true
        for (i in first..last) {
            val left = ox - sx
            val top = tops[i] * z - sy
            dstRect.set(left, top, left + baseW * z, top + hs[i] * z)
            canvas.drawRect(dstRect, white)
            val lo = lowCache.get(i)
            if (lo != null) {
                canvas.drawBitmap(lo, null, dstRect, pagePaint)
            } else if (!lowFailed.containsKey(i)) {
                requestLow(i)
            }
            val lodFb = lodFor(i, fallbackZoom)
            val lodNow = if (locked) lodFb else lodFor(i, z)
            if (lodFb != lodNow) drawPageTiles(canvas, i, left, top, z, lodFb, false)
            if (!drawPageTiles(canvas, i, left, top, z, lodNow, true)) allReady = false
            if (!drawMode) requestLinks(i)
            drawOverlay(canvas, i, left, top, z)
            drawInk(canvas, i, left, top, z)
        }
        drawSelection(canvas)
        drawLassoOverlay(canvas)
        if (erasingNow) canvas.drawCircle(eraserX, eraserY, eraserRadius, ringPaint)
        if (!locked && allReady && fallbackZoom != z) fallbackZoom = z
    }

    private fun drawPageTiles(c: Canvas, i: Int, left: Float, top: Float, z: Float, lod: Int, request: Boolean): Boolean {
        val r = baseW * z / pw[i]
        val q = 2.0.pow(lod / 2.0).toFloat()
        val tp = tile / q
        val fullW = pw[i] * q
        val fullH = ph[i] * q
        val nx = max(1, ceil(fullW / tile).toInt())
        val ny = max(1, ceil(fullH / tile).toInt())
        val vx0 = max(0f, -left / r)
        val vx1 = min(pw[i], (width - left) / r)
        val vy0 = max(0f, -top / r)
        val vy1 = min(ph[i], (height - top) / r)
        if (vx1 <= vx0 || vy1 <= vy0) return true
        val tx0 = floor(vx0 / tp).toInt().coerceIn(0, nx - 1)
        val tx1 = floor(vx1 / tp).toInt().coerceIn(0, nx - 1)
        val ty0 = floor(vy0 / tp).toInt().coerceIn(0, ny - 1)
        val ty1 = floor(vy1 / tp).toInt().coerceIn(0, ny - 1)
        var allReady = true
        for (ty in ty0..ty1) {
            for (tx in tx0..tx1) {
                val k = Key(i, lod, tx, ty)
                val bmp = tileCache.get(k)
                if (bmp != null) {
                    dstRect.set(
                        left + tx * tp * r,
                        top + ty * tp * r,
                        left + (tx * tp + bmp.width / q) * r,
                        top + (ty * tp + bmp.height / q) * r
                    )
                    dstRect.inset(-0.5f, -0.5f)
                    c.drawBitmap(bmp, null, dstRect, pagePaint)
                } else {
                    allReady = false
                    if (request && !failed.containsKey(k)) requestTile(k)
                }
            }
        }
        return allReady
    }

    // ---------------------------------------------------------------- rendering (worker thread)

    private fun requestTile(k: Key) {
        want[k] = frame
        if (pending.putIfAbsent(k, true) != null) return
        worker.execute {
            try {
                val stamp = want[k] ?: -100
                if (stamp >= frame - 2 && tileCache.get(k) == null) renderTile(k)
            } catch (e: Throwable) {
                failed[k] = true
            } finally {
                pending.remove(k)
                want.remove(k)
                postInvalidateOnAnimation()
            }
        }
    }

    private fun requestLow(i: Int) {
        wantLow[i] = frame
        if (lowPending.putIfAbsent(i, true) != null) return
        worker.execute {
            try {
                val stamp = wantLow[i] ?: -100
                if (stamp >= frame - 4 && lowCache.get(i) == null) renderLow(i)
            } catch (e: Throwable) {
                lowFailed[i] = true
            } finally {
                lowPending.remove(i)
                wantLow.remove(i)
                postInvalidateOnAnimation()
            }
        }
    }

    private fun ensureOpen(d: PdfDocument, i: Int) {
        if (opened.add(i)) core.openPage(d, i)
    }

    private fun renderTile(k: Key) {
        val d = doc ?: return
        val q = 2.0.pow(k.lod / 2.0).toFloat()
        val fullW = (pw[k.page] * q).roundToInt()
        val fullH = (ph[k.page] * q).roundToInt()
        val wPx = min(tile, fullW - k.tx * tile)
        val hPx = min(tile, fullH - k.ty * tile)
        if (wPx <= 0 || hPx <= 0) {
            failed[k] = true
            return
        }
        ensureOpen(d, k.page)
        val bmp = Bitmap.createBitmap(wPx, hPx, Bitmap.Config.ARGB_8888)
        bmp.eraseColor(Color.WHITE)
        core.renderPageBitmap(d, bmp, k.page, -k.tx * tile, -k.ty * tile, fullW, fullH, false)
        tileCache.put(k, bmp)
    }

    private fun renderLow(i: Int) {
        val d = doc ?: return
        val w = 480
        val h = max(1, (480f * ph[i] / pw[i]).roundToInt())
        ensureOpen(d, i)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bmp.eraseColor(Color.WHITE)
        core.renderPageBitmap(d, bmp, i, 0, 0, w, h, false)
        lowCache.put(i, bmp)
    }
}
