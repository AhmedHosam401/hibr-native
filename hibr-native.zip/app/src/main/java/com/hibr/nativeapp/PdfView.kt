package com.hibr.nativeapp

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.ParcelFileDescriptor
import android.util.LruCache
import android.view.GestureDetector
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.widget.OverScroller
import com.shockwave.pdfium.PdfDocument
import com.shockwave.pdfium.PdfiumCore
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt

private fun cacheBytes(): Int {
    val m = Runtime.getRuntime().maxMemory() / 6
    return min(m, 110L * 1024L * 1024L).toInt()
}

/**
 * Native PDF view: continuous vertical pages, pinch zoom around the fingers,
 * pan, fling, double-tap zoom, tile rendering with PDFium on a worker thread.
 */
class PdfView(context: Context) : View(context) {

    interface Listener {
        fun onTap()
        fun onScrollChanged(frac: Float, page: Int, pages: Int)
        fun onOpened(pages: Int)
        fun onError(msg: String)
        fun onInkChanged()
    }

    var listener: Listener? = null
    var bgColor: Int = Color.LTGRAY

    private val core = PdfiumCore(context)

    @Volatile
    private var doc: PdfDocument? = null
    private var pfd: ParcelFileDescriptor? = null
    private val worker = Executors.newSingleThreadExecutor()
    private val opened = HashSet<Int>() // touched only on the worker thread

    private var pages = 0
    private var pw = FloatArray(0)
    private var ph = FloatArray(0)
    private var tops = FloatArray(0)
    private var hs = FloatArray(0)
    private var baseW = 0f
    private var baseH = 0f
    private val dens = context.resources.displayMetrics.density
    private val gap = 8f * dens

    var zoom = 1f
        private set
    private var sx = 0f
    private var sy = 0f

    // How far (px) the pages may be pulled down below the top of the screen. While the top bar is shown this is
    // the bar height (so the first page can rest under the bar); when the bar hides it goes to 0, so the page
    // slides up by itself and there is never an empty gap above the file.
    var topSlack = 0f
        private set
    private var slackAnim: ValueAnimator? = null
    private var slackInit = false

    private fun minScrollY(): Float = -topSlack

    private fun maxScrollY(): Float = max(0f, baseH * zoom - height)

    fun setTopSlack(px: Float, animate: Boolean) {
        slackAnim?.cancel()
        slackAnim = null
        if (!animate || width == 0 || baseH <= 0f) {
            topSlack = px
            if (!slackInit && px > 0f) {
                slackInit = true
                if (sy <= 0.5f) sy = -px
            }
            clampScroll()
            notifyScroll()
            postInvalidateOnAnimation()
            return
        }
        val a = ValueAnimator.ofFloat(topSlack, px)
        a.duration = 180
        a.interpolator = AccelerateDecelerateInterpolator()
        a.addUpdateListener { v ->
            topSlack = v.animatedValue as Float
            clampScroll()
            postInvalidateOnAnimation()
        }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                notifyScroll()
            }
        })
        slackAnim = a
        a.start()
    }

    private val minZ = 0.5f
    private val maxZ = 6f
    private val tile = 512

    private data class Key(val page: Int, val lod: Int, val tx: Int, val ty: Int)

    private val tileCache = object : LruCache<Key, Bitmap>(cacheBytes()) {
        override fun sizeOf(key: Key, value: Bitmap): Int = value.byteCount
    }
    private val lowCache = object : LruCache<Int, Bitmap>(28 * 1024 * 1024) {
        override fun sizeOf(key: Int, value: Bitmap): Int = value.byteCount
    }
    private val pending = ConcurrentHashMap<Key, Boolean>()
    private val lowPending = ConcurrentHashMap<Int, Boolean>()
    private val want = ConcurrentHashMap<Key, Int>()
    private val wantLow = ConcurrentHashMap<Int, Int>()
    private val failed = ConcurrentHashMap<Key, Boolean>()
    private val lowFailed = ConcurrentHashMap<Int, Boolean>()

    @Volatile
    private var frame = 0

    private val white = Paint().apply { color = Color.WHITE }
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.DITHER_FLAG)
    private val dstRect = RectF()

    private val scroller = OverScroller(context)
    private var scaling = false
    private var animating = false
    private val locked: Boolean
        get() = scaling || animating
    private var fallbackZoom = 1f
    private var lastFx = 0f
    private var lastFy = 0f

    // ---- ink state
    var ink: InkStore? = null
    var drawMode = false
        set(value) {
            field = value
            cancelStroke()
        }
    var tool = Tool.PEN
    var color = Color.rgb(214, 51, 108)
    var penWidth = 0.003f
    var hlWidth = 0.014f
    private var stylusSeen = false
    private var layoutVer = 0
    private var inkActive = false
    private var inkPointerId = -1
    private var inkSuppressed = false
    private var curPage = -1
    private var curStroke: Stroke? = null
    private val curBuf = FloatBuf()
    private var curTool = Tool.PEN
    private var lastPx = 0f
    private var lastPy = 0f
    private var downX = 0f
    private var downY = 0f
    private var downTime = 0L
    private var erasingNow = false
    var shapeOn = true
    private var snapped = false
    private var holdX = 0f
    private var holdY = 0f
    private val holdSlop = 6f * dens
    private val holdRun = Runnable { trySnap() }
    private var eraserX = 0f
    private var eraserY = 0f
    private val eraserRadius = 18f * dens
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.5f * dens
        color = 0xFF888888.toInt()
    }

    // ---- inserted images (selection / move / resize)
    var imgDir: File? = null
    private val imgCache = object : LruCache<String, Bitmap>(32 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val imgPending = ConcurrentHashMap<String, Boolean>()
    private val imgFailed = ConcurrentHashMap<String, Boolean>()
    private val imgExec = Executors.newSingleThreadExecutor()
    private val imgDst = RectF()
    private val selRect = RectF()
    private val hitRect = RectF()
    private var selPage = -1
    private var selIdx = -1
    private var selStroke: Stroke? = null
    private var selMode = 0 // 0 none, 1 move, 2 resize, 3 delete (pending)
    private var selDownX = 0f
    private var selDownY = 0f
    private var selStart = FloatArray(4)
    private var selAspect = 1f
    private var selStartWidth = 0f
    private var selTapEaten = false
    private val selPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f * dens
        color = 0xFF6F5BD8.toInt()
    }
    private val selFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF6F5BD8.toInt() }
    private val delFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFE03131.toInt() }
    private val selGlyph = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f * dens
        strokeCap = Paint.Cap.ROUND
        color = Color.WHITE
    }

    /** Called when the pencil button on a selected text box is tapped: current text, colour, size fraction. */
    var onTextEdit: ((String, Int, Float) -> Unit)? = null

    private fun isObj(st: Stroke): Boolean = st.tool == Tool.IMAGE || st.tool == Tool.TEXT

    private fun cloneStroke(st: Stroke): Stroke {
        val c = Stroke(st.tool, st.color, st.width, st.pts.copyOf())
        c.img = st.img
        c.text = st.text
        return c
    }

    private fun textLayout(text: String, widthPx: Float, sizePx: Float, col: Int): StaticLayout {
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
        tp.textSize = max(1f, sizePx)
        tp.color = col
        return StaticLayout.Builder.obtain(text, 0, text.length, tp, max(1, widthPx.toInt()))
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setLineSpacing(0f, 1.1f)
            .build()
    }

    private fun imageBitmap(name: String): Bitmap? {
        val b = imgCache.get(name)
        if (b != null) return b
        val dir = imgDir ?: return null
        if (imgFailed.containsKey(name)) return null
        if (imgPending.putIfAbsent(name, true) == null) {
            imgExec.execute {
                try {
                    val bm = BitmapFactory.decodeFile(File(dir, name).absolutePath)
                    if (bm != null) imgCache.put(name, bm) else imgFailed[name] = true
                } catch (e: Throwable) {
                    imgFailed[name] = true
                }
                imgPending.remove(name)
                postInvalidateOnAnimation()
            }
        }
        return null
    }

    private fun imgScreenRect(page: Int, a: FloatArray, out: RectF) {
        val z = zoom
        val left = offX(z) - sx + a[0] * baseW * z
        val top = tops[page] * z - sy + a[1] * hs[page] * z
        out.set(left, top, left + a[2] * baseW * z, top + a[3] * hs[page] * z)
    }

    private fun hitImage(px: Float, py: Float): Pair<Int, Int>? {
        val store = ink ?: return null
        if (pages == 0) return null
        val p = pageAtScreen(py)
        val list = store.strokes(p)
        for (k in list.indices.reversed()) {
            val st = list[k]
            if (!isObj(st)) continue
            imgScreenRect(p, st.pts, hitRect)
            if (hitRect.contains(px, py)) return Pair(p, k)
        }
        return null
    }

    private fun selectImage(page: Int, idx: Int) {
        val l = ink?.strokes(page) ?: return
        if (idx < 0 || idx >= l.size) return
        val st = l[idx]
        if (!isObj(st)) return
        selPage = page
        selIdx = idx
        selStroke = cloneStroke(st)
        selMode = 0
        postInvalidateOnAnimation()
    }

    fun clearSelection() {
        selStroke = null
        selPage = -1
        selIdx = -1
        selMode = 0
        postInvalidateOnAnimation()
    }

    /** Adds an image at the centre of what is currently visible and selects it. */
    fun insertImage(name: String, bmp: Bitmap) {
        val store = ink ?: return
        if (pages == 0 || baseW <= 0f) return
        imgCache.put(name, bmp)
        val p = pageAtScreen(height / 2f).coerceIn(0, pages - 1)
        val aspect = bmp.height.toFloat() / max(1, bmp.width).toFloat()
        var nw = 0.5f
        var nh = nw * aspect * baseW / hs[p]
        if (nh > 0.8f) {
            nh = 0.8f
            nw = nh * hs[p] / (aspect * baseW)
        }
        val cx = nxOf(width / 2f).coerceIn(0f, 1f)
        val cy = nyOf(height / 2f, p).coerceIn(0f, 1f)
        val nx = (cx - nw / 2f).coerceIn(0f, max(0f, 1f - nw))
        val ny = (cy - nh / 2f).coerceIn(0f, max(0f, 1f - nh))
        val st = Stroke(Tool.IMAGE, 0, 0f, floatArrayOf(nx, ny, nw, nh))
        st.img = name
        store.add(p, st)
        selectImage(p, store.strokes(p).size - 1)
        listener?.onInkChanged()
        postInvalidateOnAnimation()
    }

    /** Adds a text box at the centre of what is currently visible and selects it. */
    fun insertText(text: String, col: Int, sizeFrac: Float) {
        val store = ink ?: return
        if (pages == 0 || baseW <= 0f || text.isBlank()) return
        val p = pageAtScreen(height / 2f).coerceIn(0, pages - 1)
        val nw = 0.6f
        val lay = textLayout(text, nw * baseW, sizeFrac * baseW, col)
        val nh = lay.height.toFloat() / hs[p]
        val cx = nxOf(width / 2f).coerceIn(0f, 1f)
        val cy = nyOf(height / 2f, p).coerceIn(0f, 1f)
        val nx = (cx - nw / 2f).coerceIn(0f, max(0f, 1f - nw))
        val ny = (cy - nh / 2f).coerceIn(0f, max(0f, 1f - nh))
        val st = Stroke(Tool.TEXT, col, sizeFrac, floatArrayOf(nx, ny, nw, nh))
        st.text = text
        store.add(p, st)
        selectImage(p, store.strokes(p).size - 1)
        listener?.onInkChanged()
        postInvalidateOnAnimation()
    }

    /** Applies new text / colour / size to the selected text box (one undoable step). */
    fun updateSelectedText(text: String, col: Int, sizeFrac: Float) {
        val store = ink ?: return
        val ss = selStroke ?: return
        if (ss.tool != Tool.TEXT || text.isBlank()) return
        val p = selPage
        val i = selIdx
        val nw = ss.pts[2]
        val lay = textLayout(text, nw * baseW, sizeFrac * baseW, col)
        val ns = Stroke(Tool.TEXT, col, sizeFrac, floatArrayOf(ss.pts[0], ss.pts[1], nw, lay.height.toFloat() / hs[p]))
        ns.text = text
        store.replace(p, i, ns)
        selectImage(p, i)
        listener?.onInkChanged()
        postInvalidateOnAnimation()
    }

    private fun deleteSelected() {
        val store = ink ?: return
        val p = selPage
        val i = selIdx
        clearSelection()
        store.eraseBegin()
        store.eraseRemove(p, listOf(i))
        store.eraseEnd()
        listener?.onInkChanged()
        postInvalidateOnAnimation()
    }

    private fun handleSel(e: MotionEvent): Boolean {
        val ss = selStroke ?: return false
        val store = ink ?: return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                selMode = 0
                imgScreenRect(selPage, ss.pts, selRect)
                val hr = 26f * dens
                val inset = 16f * dens
                val dxD = e.x - (selRect.right - inset)
                val dyD = e.y - (selRect.top + inset)
                val dxR = e.x - (selRect.right - inset)
                val dyR = e.y - (selRect.bottom - inset)
                val dxE = e.x - (selRect.left + inset)
                val dyE = e.y - (selRect.top + inset)
                if (dxD * dxD + dyD * dyD <= hr * hr) {
                    selMode = 3
                } else if (ss.tool == Tool.TEXT && dxE * dxE + dyE * dyE <= hr * hr) {
                    selMode = 4
                } else if (dxR * dxR + dyR * dyR <= hr * hr) {
                    selMode = 2
                } else if (selRect.contains(e.x, e.y)) {
                    selMode = 1
                }
                if (selMode == 0) {
                    clearSelection()
                    selTapEaten = true
                    return false
                }
                scroller.forceFinished(true)
                selDownX = e.x
                selDownY = e.y
                selStart = ss.pts.copyOf()
                selStartWidth = ss.width
                selAspect = (selStart[3] * hs[selPage]) / max(0.0001f, selStart[2] * baseW)
                return true
            }
            MotionEvent.ACTION_POINTER_DOWN -> return selMode != 0
            MotionEvent.ACTION_MOVE -> {
                if (selMode == 0) return false
                if (selMode == 3 || selMode == 4) return true
                val dx = (e.x - selDownX) / (zoom * baseW)
                val dy = (e.y - selDownY) / (zoom * hs[selPage])
                val q = ss.pts
                if (selMode == 1) {
                    q[0] = (selStart[0] + dx).coerceIn(0f, max(0f, 1f - q[2]))
                    q[1] = (selStart[1] + dy).coerceIn(0f, max(0f, 1f - q[3]))
                } else {
                    var nw = (selStart[2] + dx).coerceIn(0.06f, max(0.06f, 1f - selStart[0]))
                    var nh = nw * selAspect * baseW / hs[selPage]
                    val maxH = max(0.03f, 1f - selStart[1])
                    if (nh > maxH) {
                        nh = maxH
                        nw = nh * hs[selPage] / (selAspect * baseW)
                    }
                    q[2] = nw
                    q[3] = nh
                    if (ss.tool == Tool.TEXT) ss.width = selStartWidth * nw / max(0.0001f, selStart[2])
                }
                postInvalidateOnAnimation()
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (selMode == 0) return false
                val mode = selMode
                selMode = 0
                if (mode == 4) {
                    imgScreenRect(selPage, ss.pts, selRect)
                    val hr4 = 26f * dens
                    val dxE = e.x - (selRect.left + 16f * dens)
                    val dyE = e.y - (selRect.top + 16f * dens)
                    if (dxE * dxE + dyE * dyE <= hr4 * hr4) onTextEdit?.invoke(ss.text ?: "", ss.color, ss.width)
                    return true
                }
                if (mode == 3) {
                    imgScreenRect(selPage, ss.pts, selRect)
                    val hr = 26f * dens
                    val dxD = e.x - (selRect.right - 16f * dens)
                    val dyD = e.y - (selRect.top + 16f * dens)
                    if (dxD * dxD + dyD * dyD <= hr * hr) deleteSelected()
                    return true
                }
                var changed = false
                for (k in 0 until 4) if (Math.abs(ss.pts[k] - selStart[k]) > 0.0005f) changed = true
                if (changed) {
                    store.replace(selPage, selIdx, cloneStroke(ss))
                    listener?.onInkChanged()
                }
                postInvalidateOnAnimation()
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                if (selMode == 0) return false
                selMode = 0
                for (k in 0 until 4) ss.pts[k] = selStart[k]
                ss.width = selStartWidth
                postInvalidateOnAnimation()
                return true
            }
        }
        return false
    }

    private fun drawSelection(c: Canvas) {
        val ss = selStroke ?: return
        if (selPage < 0 || selPage >= pages) return
        imgScreenRect(selPage, ss.pts, selRect)
        c.drawRect(selRect, selPaint)
        val hr = 13f * dens
        val inset = 16f * dens
        val rx = selRect.right - inset
        val by = selRect.bottom - inset
        val ty = selRect.top + inset
        c.drawCircle(rx, by, hr, selFill)
        c.drawLine(rx - hr * 0.45f, by + hr * 0.45f, rx + hr * 0.45f, by - hr * 0.45f, selGlyph)
        c.drawCircle(rx, ty, hr, delFill)
        val d = hr * 0.4f
        c.drawLine(rx - d, ty - d, rx + d, ty + d, selGlyph)
        c.drawLine(rx - d, ty + d, rx + d, ty - d, selGlyph)
        if (ss.tool == Tool.TEXT) {
            val lx = selRect.left + inset
            c.drawCircle(lx, ty, hr, selFill)
            c.drawLine(lx - d, ty + d, lx + d, ty - d, selGlyph)
            c.drawLine(lx - d, ty + d, lx - d * 0.2f, ty + d, selGlyph)
        }
    }

    private val scaleDetector = ScaleGestureDetector(
        context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
                scaling = true
                scroller.forceFinished(true)
                lastFx = detector.focusX
                lastFy = detector.focusY
                return true
            }

            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val nz = (zoom * detector.scaleFactor).coerceIn(minZ, maxZ)
                zoomAbout(lastFx, lastFy, detector.focusX, detector.focusY, nz)
                lastFx = detector.focusX
                lastFy = detector.focusY
                return true
            }

            override fun onScaleEnd(detector: ScaleGestureDetector) {
                scaling = false
                postInvalidateOnAnimation()
            }
        }
    ).apply { isQuickScaleEnabled = false }

    private val gestureDetector = GestureDetector(
        context,
        object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean {
                scroller.forceFinished(true)
                return true
            }

            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float): Boolean {
                if (scaling || scaleDetector.isInProgress) return false
                sx += distanceX
                sy += distanceY
                clampScroll()
                notifyScroll()
                postInvalidateOnAnimation()
                return true
            }

            override fun onFling(e1: MotionEvent?, e2: MotionEvent, velocityX: Float, velocityY: Float): Boolean {
                if (scaling || scaleDetector.isInProgress) return false
                val maxX = max(0f, baseW * zoom - width).toInt()
                val maxY = maxScrollY().toInt()
                scroller.fling(sx.toInt(), sy.toInt(), (-velocityX).toInt(), (-velocityY).toInt(), 0, maxX, minScrollY().toInt(), maxY)
                postInvalidateOnAnimation()
                return true
            }

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (selTapEaten) {
                    selTapEaten = false
                    return true
                }
                if (!drawMode) {
                    val h = hitImage(e.x, e.y)
                    if (h != null) {
                        selectImage(h.first, h.second)
                        return true
                    }
                }
                listener?.onTap()
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                animateZoomTo(if (zoom < 1.4f) 2.5f else 1f, e.x, e.y)
                return true
            }

            override fun onLongPress(e: MotionEvent) {
                recenter()
            }
        }
    )

    // ---------------------------------------------------------------- open / close

    fun open(file: File, page: Int, frac: Float) {
        worker.execute {
            try {
                val d = core.newDocument(file.readBytes())
                val n = core.getPageCount(d)
                val w = FloatArray(n)
                val h = FloatArray(n)
                for (i in 0 until n) {
                    val s = core.getPageSize(d, i)
                    w[i] = if (s.width > 0) s.width.toFloat() else 612f
                    h[i] = if (s.height > 0) s.height.toFloat() else 792f
                }
                post {
                    doc = d
                    pages = n
                    pw = w
                    ph = h
                    if (width > 0) {
                        relayout()
                        applyAnchor(page.coerceIn(0, max(0, n - 1)), frac)
                    } else {
                        pendingAnchorPage = page
                        pendingAnchorFrac = frac
                    }
                    listener?.onOpened(n)
                    notifyScroll()
                    invalidate()
                }
            } catch (e: Throwable) {
                val msg = e.javaClass.simpleName + ": " + (e.message ?: "")
                post { listener?.onError(msg) }
            }
        }
    }

    private var pendingAnchorPage = -1
    private var pendingAnchorFrac = 0f

    fun release() {
        val d = doc
        val f = pfd
        doc = null
        pfd = null
        worker.execute {
            try {
                if (d != null) core.closeDocument(d)
            } catch (e: Throwable) {
            }
            try {
                f?.close()
            } catch (e: Throwable) {
            }
        }
        worker.shutdown()
        imgExec.shutdown()
        imgCache.evictAll()
        tileCache.evictAll()
        lowCache.evictAll()
    }

    // ---------------------------------------------------------------- layout

    private fun relayout() {
        baseW = width.toFloat()
        tops = FloatArray(pages)
        hs = FloatArray(pages)
        var y = 0f
        for (i in 0 until pages) {
            tops[i] = y
            hs[i] = baseW * ph[i] / pw[i]
            y += hs[i] + gap
        }
        baseH = max(0f, y - gap)
        layoutVer++
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        if (pages > 0 && w > 0 && baseW > 0f) {
            val a = anchor()
            relayout()
            applyAnchor(a.first, a.second)
            postInvalidateOnAnimation()
        } else if (pages > 0 && w > 0) {
            relayout()
            if (pendingAnchorPage >= 0) {
                applyAnchor(pendingAnchorPage.coerceIn(0, pages - 1), pendingAnchorFrac)
                pendingAnchorPage = -1
            }
            notifyScroll()
            postInvalidateOnAnimation()
        }
    }

    fun anchor(): Pair<Int, Float> {
        if (pages == 0) return Pair(0, 0f)
        val byy = sy / zoom
        val p = pageAt(byy)
        val f = ((byy - tops[p]) / hs[p]).coerceIn(0f, 1f)
        return Pair(p, f)
    }

    private fun applyAnchor(p: Int, f: Float) {
        if (pages == 0) return
        sy = (tops[p] + f * hs[p]) * zoom
        if (p == 0 && f < 0.001f) sy = minScrollY()
        sx = 0f
        clampScroll()
    }

    private fun offX(z: Float): Float = max(0f, (width - baseW * z) / 2f)

    private fun clampScroll() {
        val maxX = max(0f, baseW * zoom - width)
        val maxY = maxScrollY()
        sx = sx.coerceIn(0f, maxX)
        sy = sy.coerceIn(minScrollY(), maxY)
    }

    private fun pageAt(byy: Float): Int {
        var lo = 0
        var hi = pages - 1
        while (lo < hi) {
            val mid = (lo + hi + 1) ushr 1
            if (tops[mid] <= byy) lo = mid else hi = mid - 1
        }
        return lo
    }

    private fun notifyScroll() {
        if (pages == 0) return
        val maxY = maxScrollY()
        val frac = if (maxY > 0f) (sy / maxY).coerceIn(0f, 1f) else 0f
        val page = pageAt((sy + height * 0.35f) / zoom)
        listener?.onScrollChanged(frac, page, pages)
    }

    fun scrollToFraction(f: Float) {
        val maxY = maxScrollY()
        sy = f.coerceIn(0f, 1f) * maxY
        clampScroll()
        notifyScroll()
        postInvalidateOnAnimation()
    }

    // ---------------------------------------------------------------- zoom

    private fun zoomAbout(fxOld: Float, fyOld: Float, fxNew: Float, fyNew: Float, nz: Float) {
        val bx = (fxOld - offX(zoom) + sx) / zoom
        val byy = (fyOld + sy) / zoom
        zoom = nz
        sx = offX(nz) + bx * nz - fxNew
        sy = byy * nz - fyNew
        clampScroll()
        notifyScroll()
        postInvalidateOnAnimation()
    }

    private fun animateZoomTo(target: Float, fx: Float, fy: Float) {
        val z0 = zoom
        val t = target.coerceIn(minZ, maxZ)
        animating = true
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 240
        a.interpolator = DecelerateInterpolator()
        a.addUpdateListener { v ->
            val f = v.animatedFraction
            zoomAbout(fx, fy, fx, fy, z0 + (t - z0) * f)
        }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                animating = false
                postInvalidateOnAnimation()
            }
        })
        a.start()
    }

    private fun recenter() {
        val maxX = baseW * zoom - width
        if (maxX <= 2f) return
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        val from = sx
        val to = maxX / 2f
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 240
        a.interpolator = DecelerateInterpolator()
        a.addUpdateListener { v ->
            sx = from + (to - from) * v.animatedFraction
            clampScroll()
            postInvalidateOnAnimation()
        }
        a.start()
    }

    // ---------------------------------------------------------------- ink

    fun undoInk() {
        clearSelection()
        if (ink?.undo() == true) {
            listener?.onInkChanged()
            postInvalidateOnAnimation()
        }
    }

    fun redoInk() {
        clearSelection()
        if (ink?.redo() == true) {
            listener?.onInkChanged()
            postInvalidateOnAnimation()
        }
    }

    private fun pageAtScreen(py: Float): Int = pageAt((py + sy) / zoom)

    private fun nxOf(px: Float): Float = ((px - offX(zoom) + sx) / zoom) / baseW

    private fun nyOf(py: Float, p: Int): Float = (((py + sy) / zoom) - tops[p]) / hs[p]

    private fun handleInk(e: MotionEvent): Boolean {
        val store = ink ?: return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                inkSuppressed = false
                val stylus = e.getToolType(0) == MotionEvent.TOOL_TYPE_STYLUS
                if (stylus) stylusSeen = true
                if (!stylus && stylusSeen) {
                    inkSuppressed = true
                    return false
                }
                scroller.forceFinished(true)
                inkPointerId = e.getPointerId(0)
                downX = e.x
                downY = e.y
                downTime = e.eventTime
                val eraserBtn = (e.buttonState and MotionEvent.BUTTON_STYLUS_PRIMARY) != 0
                curTool = if (eraserBtn) Tool.ERASER else tool
                inkActive = true
                if (curTool == Tool.ERASER) {
                    store.eraseBegin()
                    erasingNow = true
                    eraseAt(e.x, e.y)
                } else {
                    beginStroke(e.x, e.y)
                }
                return true
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                if (inkActive) cancelStroke()
                inkSuppressed = true
                return false
            }
            MotionEvent.ACTION_MOVE -> {
                if (inkSuppressed || !inkActive) return false
                val idx = e.findPointerIndex(inkPointerId)
                if (idx < 0) return true
                for (h in 0 until e.historySize) {
                    moveInk(e.getHistoricalX(idx, h), e.getHistoricalY(idx, h))
                }
                moveInk(e.getX(idx), e.getY(idx))
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (inkSuppressed) {
                    inkSuppressed = false
                    return false
                }
                if (!inkActive) return false
                val stylus = e.getToolType(0) == MotionEvent.TOOL_TYPE_STYLUS
                val moved = Math.hypot((e.x - downX).toDouble(), (e.y - downY).toDouble())
                val quick = !stylus && (e.eventTime - downTime) < 250 && moved < 12 * dens
                if (quick) {
                    cancelStroke()
                    listener?.onTap()
                } else {
                    endStroke()
                }
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                cancelStroke()
                inkSuppressed = false
                return true
            }
        }
        return false
    }

    private fun beginStroke(px: Float, py: Float) {
        curPage = pageAtScreen(py)
        curBuf.clear()
        lastPx = px
        lastPy = py
        curBuf.add(nxOf(px).coerceIn(0f, 1f), nyOf(py, curPage).coerceIn(0f, 1f))
        updateCur()
        snapped = false
        holdX = px
        holdY = py
        removeCallbacks(holdRun)
        if (shapeOn) postDelayed(holdRun, 550)
    }

    private fun moveInk(px: Float, py: Float) {
        if (curTool == Tool.ERASER) {
            eraseAt(px, py)
            return
        }
        if (snapped) return
        if (shapeOn) {
            val hx = px - holdX
            val hy = py - holdY
            if (hx * hx + hy * hy > holdSlop * holdSlop) {
                holdX = px
                holdY = py
                removeCallbacks(holdRun)
                postDelayed(holdRun, 550)
            }
        }
        val dx = px - lastPx
        val dy = py - lastPy
        if (dx * dx + dy * dy < 2.25f) return
        lastPx = px
        lastPy = py
        curBuf.add(nxOf(px).coerceIn(0f, 1f), nyOf(py, curPage).coerceIn(0f, 1f))
        updateCur()
    }

    private fun updateCur() {
        val w = if (curTool == Tool.HL) hlWidth else penWidth
        curStroke = Stroke(curTool, color, w, curBuf.toArray())
        postInvalidateOnAnimation()
    }

    private fun trySnap() {
        if (!inkActive || snapped || curTool == Tool.ERASER || curPage < 0) return
        val src = curBuf.toArray()
        if (src.size < 12) return
        val w = baseW
        val h = hs[curPage]
        val pp = FloatArray(src.size)
        for (i in 0 until src.size / 2) {
            pp[2 * i] = src[2 * i] * w
            pp[2 * i + 1] = src[2 * i + 1] * h
        }
        val out = Shapes.snap(pp, 24f * dens / zoom) ?: return
        val np = FloatArray(out.size)
        for (i in 0 until out.size / 2) {
            np[2 * i] = (out[2 * i] / w).coerceIn(0f, 1f)
            np[2 * i + 1] = (out[2 * i + 1] / h).coerceIn(0f, 1f)
        }
        val wd = if (curTool == Tool.HL) hlWidth else penWidth
        curStroke = Stroke(curTool, color, wd, np)
        snapped = true
        performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
        postInvalidateOnAnimation()
    }

    private fun endStroke() {
        removeCallbacks(holdRun)
        snapped = false
        val store = ink
        if (curTool == Tool.ERASER) {
            store?.eraseEnd()
            erasingNow = false
        } else {
            val s = curStroke
            if (s != null && store != null) store.add(curPage, s)
        }
        curStroke = null
        inkActive = false
        curPage = -1
        listener?.onInkChanged()
        postInvalidateOnAnimation()
    }

    private fun cancelStroke() {
        removeCallbacks(holdRun)
        snapped = false
        if (curTool == Tool.ERASER && erasingNow) {
            ink?.eraseEnd()
            erasingNow = false
            listener?.onInkChanged()
        }
        curStroke = null
        inkActive = false
        curPage = -1
        postInvalidateOnAnimation()
    }

    private fun eraseAt(px: Float, py: Float) {
        val store = ink ?: return
        if (pages == 0) return
        eraserX = px
        eraserY = py
        val p = pageAtScreen(py)
        val bx = nxOf(px) * baseW
        val byy = nyOf(py, p) * hs[p]
        val r = eraserRadius / zoom
        val list = store.strokes(p)
        var hits: ArrayList<Int>? = null
        for (k in list.indices) {
            val s = list[k]
            if (s.tool == Tool.IMAGE || s.tool == Tool.TEXT) continue
            val rr = r + s.width * baseW / 2f
            val a = s.pts
            var hit = false
            var i = 0
            while (i < a.size) {
                val dx = a[i] * baseW - bx
                val dy = a[i + 1] * hs[p] - byy
                if (dx * dx + dy * dy <= rr * rr) {
                    hit = true
                    break
                }
                i += 2
            }
            if (hit) {
                if (hits == null) hits = ArrayList()
                hits.add(k)
            }
        }
        if (hits != null) {
            store.eraseRemove(p, hits)
            listener?.onInkChanged()
        }
        postInvalidateOnAnimation()
    }

    private fun buildPath(s: Stroke, page: Int): Path {
        val p = Path()
        val a = s.pts
        val n = a.size / 2
        val h = hs[page]
        var px = a[0] * baseW
        var py = a[1] * h
        p.moveTo(px, py)
        if (n == 1) {
            p.lineTo(px + 0.01f, py)
            return p
        }
        for (i in 1 until n) {
            val x = a[2 * i] * baseW
            val y = a[2 * i + 1] * h
            p.quadTo(px, py, (px + x) / 2f, (py + y) / 2f)
            px = x
            py = y
        }
        p.lineTo(px, py)
        return p
    }

    private fun drawStroke(c: Canvas, s: Stroke, page: Int) {
        if (s.tool == Tool.TEXT) {
            val t = s.text ?: return
            val a = s.pts
            val lay = textLayout(t, a[2] * baseW, s.width * baseW, s.color)
            c.save()
            c.translate(a[0] * baseW, a[1] * hs[page])
            lay.draw(c)
            c.restore()
            return
        }
        if (s.tool == Tool.IMAGE) {
            val name = s.img ?: return
            val bm = imageBitmap(name) ?: return
            val a = s.pts
            val ph0 = hs[page]
            imgDst.set(a[0] * baseW, a[1] * ph0, (a[0] + a[2]) * baseW, (a[1] + a[3]) * ph0)
            c.drawBitmap(bm, null, imgDst, bmpPaint)
            return
        }
        val cached = s.path
        val path: Path = if (cached != null && s.pathVer == layoutVer) {
            cached
        } else {
            val np = buildPath(s, page)
            s.path = np
            s.pathVer = layoutVer
            np
        }
        strokePaint.color = s.color
        strokePaint.alpha = if (s.tool == Tool.HL) 102 else 255
        strokePaint.strokeWidth = s.width * baseW
        c.drawPath(path, strokePaint)
    }

    private fun drawInk(c: Canvas, i: Int, left: Float, top: Float, z: Float) {
        val store = ink ?: return
        val list = store.strokes(i)
        val cur = curStroke
        val showCur = cur != null && curPage == i
        if (list.isEmpty() && !showCur) return
        c.save()
        c.translate(left, top)
        c.scale(z, z)
        val sel = selStroke
        for (k in list.indices) {
            val s0 = list[k]
            val s1 = if (sel != null && selPage == i && selIdx == k) sel else s0
            drawStroke(c, s1, i)
        }
        if (showCur && cur != null) {
            cur.pathVer = -1
            drawStroke(c, cur, i)
        }
        c.restore()
    }

    // ---------------------------------------------------------------- input

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (doc == null) return true
        if (e.actionMasked == MotionEvent.ACTION_DOWN) selTapEaten = false
        if (selStroke != null && handleSel(e)) return true
        scaleDetector.onTouchEvent(e)
        if (drawMode && ink != null && handleInk(e)) return true
        gestureDetector.onTouchEvent(e)
        return true
    }

    override fun computeScroll() {
        if (scroller.computeScrollOffset()) {
            sx = scroller.currX.toFloat()
            sy = scroller.currY.toFloat()
            clampScroll()
            notifyScroll()
            postInvalidateOnAnimation()
        }
    }

    // ---------------------------------------------------------------- drawing

    private fun lodFor(i: Int, z: Float): Int {
        val r = (baseW * z / pw[i]).toDouble()
        return (2.0 * ln(r) / ln(2.0)).roundToInt()
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(bgColor)
        if (doc == null || pages == 0 || baseW <= 0f) return
        frame++
        val z = zoom
        val ox = offX(z)
        val first = pageAt(sy / z)
        val last = pageAt((sy + height) / z)
        var allReady = true
        for (i in first..last) {
            val left = ox - sx
            val top = tops[i] * z - sy
            dstRect.set(left, top, left + baseW * z, top + hs[i] * z)
            canvas.drawRect(dstRect, white)
            val lo = lowCache.get(i)
            if (lo != null) {
                canvas.drawBitmap(lo, null, dstRect, bmpPaint)
            } else if (!lowFailed.containsKey(i)) {
                requestLow(i)
            }
            val lodFb = lodFor(i, fallbackZoom)
            val lodNow = if (locked) lodFb else lodFor(i, z)
            if (lodFb != lodNow) drawPageTiles(canvas, i, left, top, z, lodFb, false)
            if (!drawPageTiles(canvas, i, left, top, z, lodNow, true)) allReady = false
            drawInk(canvas, i, left, top, z)
        }
        drawSelection(canvas)
        if (erasingNow) canvas.drawCircle(eraserX, eraserY, eraserRadius, ringPaint)
        if (!locked && allReady && fallbackZoom != z) fallbackZoom = z
    }

    private fun drawPageTiles(c: Canvas, i: Int, left: Float, top: Float, z: Float, lod: Int, request: Boolean): Boolean {
        val r = baseW * z / pw[i]
        val q = 2.0.pow(lod / 2.0).toFloat()
        val tp = tile / q
        val fullW = pw[i] * q
        val fullH = ph[i] * q
        val nx = max(1, ceil(fullW / tile).toInt())
        val ny = max(1, ceil(fullH / tile).toInt())
        val vx0 = max(0f, -left / r)
        val vx1 = min(pw[i], (width - left) / r)
        val vy0 = max(0f, -top / r)
        val vy1 = min(ph[i], (height - top) / r)
        if (vx1 <= vx0 || vy1 <= vy0) return true
        val tx0 = floor(vx0 / tp).toInt().coerceIn(0, nx - 1)
        val tx1 = floor(vx1 / tp).toInt().coerceIn(0, nx - 1)
        val ty0 = floor(vy0 / tp).toInt().coerceIn(0, ny - 1)
        val ty1 = floor(vy1 / tp).toInt().coerceIn(0, ny - 1)
        var allReady = true
        for (ty in ty0..ty1) {
            for (tx in tx0..tx1) {
                val k = Key(i, lod, tx, ty)
                val bmp = tileCache.get(k)
                if (bmp != null) {
                    dstRect.set(
                        left + tx * tp * r,
                        top + ty * tp * r,
                        left + (tx * tp + bmp.width / q) * r,
                        top + (ty * tp + bmp.height / q) * r
                    )
                    dstRect.inset(-0.5f, -0.5f)
                    c.drawBitmap(bmp, null, dstRect, bmpPaint)
                } else {
                    allReady = false
                    if (request && !failed.containsKey(k)) requestTile(k)
                }
            }
        }
        return allReady
    }

    // ---------------------------------------------------------------- rendering (worker thread)

    private fun requestTile(k: Key) {
        want[k] = frame
        if (pending.putIfAbsent(k, true) != null) return
        worker.execute {
            try {
                val stamp = want[k] ?: -100
                if (stamp >= frame - 2 && tileCache.get(k) == null) renderTile(k)
            } catch (e: Throwable) {
                failed[k] = true
            } finally {
                pending.remove(k)
                want.remove(k)
                postInvalidateOnAnimation()
            }
        }
    }

    private fun requestLow(i: Int) {
        wantLow[i] = frame
        if (lowPending.putIfAbsent(i, true) != null) return
        worker.execute {
            try {
                val stamp = wantLow[i] ?: -100
                if (stamp >= frame - 4 && lowCache.get(i) == null) renderLow(i)
            } catch (e: Throwable) {
                lowFailed[i] = true
            } finally {
                lowPending.remove(i)
                wantLow.remove(i)
                postInvalidateOnAnimation()
            }
        }
    }

    private fun ensureOpen(d: PdfDocument, i: Int) {
        if (opened.add(i)) core.openPage(d, i)
    }

    private fun renderTile(k: Key) {
        val d = doc ?: return
        val q = 2.0.pow(k.lod / 2.0).toFloat()
        val fullW = (pw[k.page] * q).roundToInt()
        val fullH = (ph[k.page] * q).roundToInt()
        val wPx = min(tile, fullW - k.tx * tile)
        val hPx = min(tile, fullH - k.ty * tile)
        if (wPx <= 0 || hPx <= 0) {
            failed[k] = true
            return
        }
        ensureOpen(d, k.page)
        val bmp = Bitmap.createBitmap(wPx, hPx, Bitmap.Config.ARGB_8888)
        bmp.eraseColor(Color.WHITE)
        core.renderPageBitmap(d, bmp, k.page, -k.tx * tile, -k.ty * tile, fullW, fullH, false)
        tileCache.put(k, bmp)
    }

    private fun renderLow(i: Int) {
        val d = doc ?: return
        val w = 480
        val h = max(1, (480f * ph[i] / pw[i]).roundToInt())
        ensureOpen(d, i)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bmp.eraseColor(Color.WHITE)
        core.renderPageBitmap(d, bmp, i, 0, 0, w, h, false)
        lowCache.put(i, bmp)
    }
}
