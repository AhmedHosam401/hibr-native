package com.hibr.nativeapp

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.ParcelFileDescriptor
import android.util.LruCache
import android.view.GestureDetector
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.widget.OverScroller
import com.shockwave.pdfium.PdfDocument
import com.shockwave.pdfium.PdfiumCore
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt

private fun cacheBytes(): Int {
    val m = Runtime.getRuntime().maxMemory() / 6
    return min(m, 110L * 1024L * 1024L).toInt()
}

/**
 * Native PDF view: continuous vertical pages, pinch zoom around the fingers,
 * pan, fling, double-tap zoom, tile rendering with PDFium on a worker thread.
 */
class PdfView(context: Context) : View(context) {

    interface Listener {
        fun onTap()
        fun onScrollChanged(frac: Float, page: Int, pages: Int)
        fun onOpened(pages: Int)
        fun onError(msg: String)
        fun onInkChanged()
    }

    var listener: Listener? = null
    var bgColor: Int = Color.LTGRAY

    private val core = PdfiumCore(context)

    @Volatile
    private var doc: PdfDocument? = null
    private var pfd: ParcelFileDescriptor? = null
    private val worker = Executors.newSingleThreadExecutor()
    private val opened = HashSet<Int>() // touched only on the worker thread

    private var pages = 0
    private var pw = FloatArray(0)
    private var ph = FloatArray(0)
    private var tops = FloatArray(0)
    private var hs = FloatArray(0)
    private var baseW = 0f
    private var baseH = 0f
    private val dens = context.resources.displayMetrics.density
    private val gap = 8f * dens

    var zoom = 1f
        private set
    private var sx = 0f
    private var sy = 0f

    // Pages are pushed down by this many px while the top bar is shown (so the bar never covers the page).
    var topPad = 0f
        private set
    private var padAnim: ValueAnimator? = null

    private fun maxScrollY(): Float = max(0f, baseH * zoom + topPad - height)

    fun setTopPad(px: Float, animate: Boolean) {
        padAnim?.cancel()
        padAnim = null
        if (!animate || width == 0 || baseH <= 0f) {
            topPad = px
            clampScroll()
            notifyScroll()
            postInvalidateOnAnimation()
            return
        }
        val a = ValueAnimator.ofFloat(topPad, px)
        a.duration = 180
        a.interpolator = AccelerateDecelerateInterpolator()
        a.addUpdateListener { v ->
            topPad = v.animatedValue as Float
            clampScroll()
            postInvalidateOnAnimation()
        }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                notifyScroll()
            }
        })
        padAnim = a
        a.start()
    }

    private val minZ = 0.5f
    private val maxZ = 6f
    private val tile = 512

    private data class Key(val page: Int, val lod: Int, val tx: Int, val ty: Int)

    private val tileCache = object : LruCache<Key, Bitmap>(cacheBytes()) {
        override fun sizeOf(key: Key, value: Bitmap): Int = value.byteCount
    }
    private val lowCache = object : LruCache<Int, Bitmap>(28 * 1024 * 1024) {
        override fun sizeOf(key: Int, value: Bitmap): Int = value.byteCount
    }
    private val pending = ConcurrentHashMap<Key, Boolean>()
    private val lowPending = ConcurrentHashMap<Int, Boolean>()
    private val want = ConcurrentHashMap<Key, Int>()
    private val wantLow = ConcurrentHashMap<Int, Int>()
    private val failed = ConcurrentHashMap<Key, Boolean>()
    private val lowFailed = ConcurrentHashMap<Int, Boolean>()

    @Volatile
    private var frame = 0

    private val white = Paint().apply { color = Color.WHITE }
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.DITHER_FLAG)
    private val dstRect = RectF()

    private val scroller = OverScroller(context)
    private var scaling = false
    private var animating = false
    private val locked: Boolean
        get() = scaling || animating
    private var fallbackZoom = 1f
    private var lastFx = 0f
    private var lastFy = 0f

    // ---- ink state
    var ink: InkStore? = null
    var drawMode = false
        set(value) {
            field = value
            cancelStroke()
        }
    var tool = Tool.PEN
    var color = Color.rgb(214, 51, 108)
    var penWidth = 0.003f
    var hlWidth = 0.014f
    private var stylusSeen = false
    private var layoutVer = 0
    private var inkActive = false
    private var inkPointerId = -1
    private var inkSuppressed = false
    private var curPage = -1
    private var curStroke: Stroke? = null
    private val curBuf = FloatBuf()
    private var curTool = Tool.PEN
    private var lastPx = 0f
    private var lastPy = 0f
    private var downX = 0f
    private var downY = 0f
    private var downTime = 0L
    private var erasingNow = false
    var shapeOn = true
    private var snapped = false
    private var holdX = 0f
    private var holdY = 0f
    private val holdSlop = 6f * dens
    private val holdRun = Runnable { trySnap() }
    private var eraserX = 0f
    private var eraserY = 0f
    private val eraserRadius = 18f * dens
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.5f * dens
        color = 0xFF888888.toInt()
    }

    private val scaleDetector = ScaleGestureDetector(
        context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
                scaling = true
                scroller.forceFinished(true)
                lastFx = detector.focusX
                lastFy = detector.focusY
                return true
            }

            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val nz = (zoom * detector.scaleFactor).coerceIn(minZ, maxZ)
                zoomAbout(lastFx, lastFy, detector.focusX, detector.focusY, nz)
                lastFx = detector.focusX
                lastFy = detector.focusY
                return true
            }

            override fun onScaleEnd(detector: ScaleGestureDetector) {
                scaling = false
                postInvalidateOnAnimation()
            }
        }
    ).apply { isQuickScaleEnabled = false }

    private val gestureDetector = GestureDetector(
        context,
        object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean {
                scroller.forceFinished(true)
                return true
            }

            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float): Boolean {
                if (scaling || scaleDetector.isInProgress) return false
                sx += distanceX
                sy += distanceY
                clampScroll()
                notifyScroll()
                postInvalidateOnAnimation()
                return true
            }

            override fun onFling(e1: MotionEvent?, e2: MotionEvent, velocityX: Float, velocityY: Float): Boolean {
                if (scaling || scaleDetector.isInProgress) return false
                val maxX = max(0f, baseW * zoom - width).toInt()
                val maxY = maxScrollY().toInt()
                scroller.fling(sx.toInt(), sy.toInt(), (-velocityX).toInt(), (-velocityY).toInt(), 0, maxX, 0, maxY)
                postInvalidateOnAnimation()
                return true
            }

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                listener?.onTap()
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                animateZoomTo(if (zoom < 1.4f) 2.5f else 1f, e.x, e.y)
                return true
            }

            override fun onLongPress(e: MotionEvent) {
                recenter()
            }
        }
    )

    // ---------------------------------------------------------------- open / close

    fun open(file: File, page: Int, frac: Float) {
        worker.execute {
            try {
                val d = core.newDocument(file.readBytes())
                val n = core.getPageCount(d)
                val w = FloatArray(n)
                val h = FloatArray(n)
                for (i in 0 until n) {
                    val s = core.getPageSize(d, i)
                    w[i] = if (s.width > 0) s.width.toFloat() else 612f
                    h[i] = if (s.height > 0) s.height.toFloat() else 792f
                }
                post {
                    doc = d
                    pages = n
                    pw = w
                    ph = h
                    if (width > 0) {
                        relayout()
                        applyAnchor(page.coerceIn(0, max(0, n - 1)), frac)
                    } else {
                        pendingAnchorPage = page
                        pendingAnchorFrac = frac
                    }
                    listener?.onOpened(n)
                    notifyScroll()
                    invalidate()
                }
            } catch (e: Throwable) {
                val msg = e.javaClass.simpleName + ": " + (e.message ?: "")
                post { listener?.onError(msg) }
            }
        }
    }

    private var pendingAnchorPage = -1
    private var pendingAnchorFrac = 0f

    fun release() {
        val d = doc
        val f = pfd
        doc = null
        pfd = null
        worker.execute {
            try {
                if (d != null) core.closeDocument(d)
            } catch (e: Throwable) {
            }
            try {
                f?.close()
            } catch (e: Throwable) {
            }
        }
        worker.shutdown()
        tileCache.evictAll()
        lowCache.evictAll()
    }

    // ---------------------------------------------------------------- layout

    private fun relayout() {
        baseW = width.toFloat()
        tops = FloatArray(pages)
        hs = FloatArray(pages)
        var y = 0f
        for (i in 0 until pages) {
            tops[i] = y
            hs[i] = baseW * ph[i] / pw[i]
            y += hs[i] + gap
        }
        baseH = max(0f, y - gap)
        layoutVer++
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        if (pages > 0 && w > 0 && baseW > 0f) {
            val a = anchor()
            relayout()
            applyAnchor(a.first, a.second)
            postInvalidateOnAnimation()
        } else if (pages > 0 && w > 0) {
            relayout()
            if (pendingAnchorPage >= 0) {
                applyAnchor(pendingAnchorPage.coerceIn(0, pages - 1), pendingAnchorFrac)
                pendingAnchorPage = -1
            }
            notifyScroll()
            postInvalidateOnAnimation()
        }
    }

    fun anchor(): Pair<Int, Float> {
        if (pages == 0) return Pair(0, 0f)
        val byy = sy / zoom
        val p = pageAt(byy)
        val f = ((byy - tops[p]) / hs[p]).coerceIn(0f, 1f)
        return Pair(p, f)
    }

    private fun applyAnchor(p: Int, f: Float) {
        if (pages == 0) return
        sy = (tops[p] + f * hs[p]) * zoom
        sx = 0f
        clampScroll()
    }

    private fun offX(z: Float): Float = max(0f, (width - baseW * z) / 2f)

    private fun clampScroll() {
        val maxX = max(0f, baseW * zoom - width)
        val maxY = maxScrollY()
        sx = sx.coerceIn(0f, maxX)
        sy = sy.coerceIn(0f, maxY)
    }

    private fun pageAt(byy: Float): Int {
        var lo = 0
        var hi = pages - 1
        while (lo < hi) {
            val mid = (lo + hi + 1) ushr 1
            if (tops[mid] <= byy) lo = mid else hi = mid - 1
        }
        return lo
    }

    private fun notifyScroll() {
        if (pages == 0) return
        val maxY = maxScrollY()
        val frac = if (maxY > 0f) sy / maxY else 0f
        val page = pageAt((sy - topPad + height * 0.35f) / zoom)
        listener?.onScrollChanged(frac, page, pages)
    }

    fun scrollToFraction(f: Float) {
        val maxY = maxScrollY()
        sy = f.coerceIn(0f, 1f) * maxY
        clampScroll()
        notifyScroll()
        postInvalidateOnAnimation()
    }

    // ---------------------------------------------------------------- zoom

    private fun zoomAbout(fxOld: Float, fyOld: Float, fxNew: Float, fyNew: Float, nz: Float) {
        val bx = (fxOld - offX(zoom) + sx) / zoom
        val byy = (fyOld - topPad + sy) / zoom
        zoom = nz
        sx = offX(nz) + bx * nz - fxNew
        sy = byy * nz - fyNew + topPad
        clampScroll()
        notifyScroll()
        postInvalidateOnAnimation()
    }

    private fun animateZoomTo(target: Float, fx: Float, fy: Float) {
        val z0 = zoom
        val t = target.coerceIn(minZ, maxZ)
        animating = true
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 240
        a.interpolator = DecelerateInterpolator()
        a.addUpdateListener { v ->
            val f = v.animatedFraction
            zoomAbout(fx, fy, fx, fy, z0 + (t - z0) * f)
        }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                animating = false
                postInvalidateOnAnimation()
            }
        })
        a.start()
    }

    private fun recenter() {
        val maxX = baseW * zoom - width
        if (maxX <= 2f) return
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        val from = sx
        val to = maxX / 2f
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 240
        a.interpolator = DecelerateInterpolator()
        a.addUpdateListener { v ->
            sx = from + (to - from) * v.animatedFraction
            clampScroll()
            postInvalidateOnAnimation()
        }
        a.start()
    }

    // ---------------------------------------------------------------- ink

    fun undoInk() {
        if (ink?.undo() == true) {
            listener?.onInkChanged()
            postInvalidateOnAnimation()
        }
    }

    fun redoInk() {
        if (ink?.redo() == true) {
            listener?.onInkChanged()
            postInvalidateOnAnimation()
        }
    }

    private fun pageAtScreen(py: Float): Int = pageAt((py - topPad + sy) / zoom)

    private fun nxOf(px: Float): Float = ((px - offX(zoom) + sx) / zoom) / baseW

    private fun nyOf(py: Float, p: Int): Float = (((py - topPad + sy) / zoom) - tops[p]) / hs[p]

    private fun handleInk(e: MotionEvent): Boolean {
        val store = ink ?: return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                inkSuppressed = false
                val stylus = e.getToolType(0) == MotionEvent.TOOL_TYPE_STYLUS
                if (stylus) stylusSeen = true
                if (!stylus && stylusSeen) {
                    inkSuppressed = true
                    return false
                }
                scroller.forceFinished(true)
                inkPointerId = e.getPointerId(0)
                downX = e.x
                downY = e.y
                downTime = e.eventTime
                val eraserBtn = (e.buttonState and MotionEvent.BUTTON_STYLUS_PRIMARY) != 0
                curTool = if (eraserBtn) Tool.ERASER else tool
                inkActive = true
                if (curTool == Tool.ERASER) {
                    store.eraseBegin()
                    erasingNow = true
                    eraseAt(e.x, e.y)
                } else {
                    beginStroke(e.x, e.y)
                }
                return true
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                if (inkActive) cancelStroke()
                inkSuppressed = true
                return false
            }
            MotionEvent.ACTION_MOVE -> {
                if (inkSuppressed || !inkActive) return false
                val idx = e.findPointerIndex(inkPointerId)
                if (idx < 0) return true
                for (h in 0 until e.historySize) {
                    moveInk(e.getHistoricalX(idx, h), e.getHistoricalY(idx, h))
                }
                moveInk(e.getX(idx), e.getY(idx))
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (inkSuppressed) {
                    inkSuppressed = false
                    return false
                }
                if (!inkActive) return false
                val stylus = e.getToolType(0) == MotionEvent.TOOL_TYPE_STYLUS
                val moved = Math.hypot((e.x - downX).toDouble(), (e.y - downY).toDouble())
                val quick = !stylus && (e.eventTime - downTime) < 250 && moved < 12 * dens
                if (quick) {
                    cancelStroke()
                    listener?.onTap()
                } else {
                    endStroke()
                }
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                cancelStroke()
                inkSuppressed = false
                return true
            }
        }
        return false
    }

    private fun beginStroke(px: Float, py: Float) {
        curPage = pageAtScreen(py)
        curBuf.clear()
        lastPx = px
        lastPy = py
        curBuf.add(nxOf(px).coerceIn(0f, 1f), nyOf(py, curPage).coerceIn(0f, 1f))
        updateCur()
        snapped = false
        holdX = px
        holdY = py
        removeCallbacks(holdRun)
        if (shapeOn) postDelayed(holdRun, 550)
    }

    private fun moveInk(px: Float, py: Float) {
        if (curTool == Tool.ERASER) {
            eraseAt(px, py)
            return
        }
        if (snapped) return
        if (shapeOn) {
            val hx = px - holdX
            val hy = py - holdY
            if (hx * hx + hy * hy > holdSlop * holdSlop) {
                holdX = px
                holdY = py
                removeCallbacks(holdRun)
                postDelayed(holdRun, 550)
            }
        }
        val dx = px - lastPx
        val dy = py - lastPy
        if (dx * dx + dy * dy < 2.25f) return
        lastPx = px
        lastPy = py
        curBuf.add(nxOf(px).coerceIn(0f, 1f), nyOf(py, curPage).coerceIn(0f, 1f))
        updateCur()
    }

    private fun updateCur() {
        val w = if (curTool == Tool.HL) hlWidth else penWidth
        curStroke = Stroke(curTool, color, w, curBuf.toArray())
        postInvalidateOnAnimation()
    }

    private fun trySnap() {
        if (!inkActive || snapped || curTool == Tool.ERASER || curPage < 0) return
        val src = curBuf.toArray()
        if (src.size < 12) return
        val w = baseW
        val h = hs[curPage]
        val pp = FloatArray(src.size)
        for (i in 0 until src.size / 2) {
            pp[2 * i] = src[2 * i] * w
            pp[2 * i + 1] = src[2 * i + 1] * h
        }
        val out = Shapes.snap(pp, 24f * dens / zoom) ?: return
        val np = FloatArray(out.size)
        for (i in 0 until out.size / 2) {
            np[2 * i] = (out[2 * i] / w).coerceIn(0f, 1f)
            np[2 * i + 1] = (out[2 * i + 1] / h).coerceIn(0f, 1f)
        }
        val wd = if (curTool == Tool.HL) hlWidth else penWidth
        curStroke = Stroke(curTool, color, wd, np)
        snapped = true
        performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
        postInvalidateOnAnimation()
    }

    private fun endStroke() {
        removeCallbacks(holdRun)
        snapped = false
        val store = ink
        if (curTool == Tool.ERASER) {
            store?.eraseEnd()
            erasingNow = false
        } else {
            val s = curStroke
            if (s != null && store != null) store.add(curPage, s)
        }
        curStroke = null
        inkActive = false
        curPage = -1
        listener?.onInkChanged()
        postInvalidateOnAnimation()
    }

    private fun cancelStroke() {
        removeCallbacks(holdRun)
        snapped = false
        if (curTool == Tool.ERASER && erasingNow) {
            ink?.eraseEnd()
            erasingNow = false
            listener?.onInkChanged()
        }
        curStroke = null
        inkActive = false
        curPage = -1
        postInvalidateOnAnimation()
    }

    private fun eraseAt(px: Float, py: Float) {
        val store = ink ?: return
        if (pages == 0) return
        eraserX = px
        eraserY = py
        val p = pageAtScreen(py)
        val bx = nxOf(px) * baseW
        val byy = nyOf(py, p) * hs[p]
        val r = eraserRadius / zoom
        val list = store.strokes(p)
        var hits: ArrayList<Int>? = null
        for (k in list.indices) {
            val s = list[k]
            val rr = r + s.width * baseW / 2f
            val a = s.pts
            var hit = false
            var i = 0
            while (i < a.size) {
                val dx = a[i] * baseW - bx
                val dy = a[i + 1] * hs[p] - byy
                if (dx * dx + dy * dy <= rr * rr) {
                    hit = true
                    break
                }
                i += 2
            }
            if (hit) {
                if (hits == null) hits = ArrayList()
                hits.add(k)
            }
        }
        if (hits != null) {
            store.eraseRemove(p, hits)
            listener?.onInkChanged()
        }
        postInvalidateOnAnimation()
    }

    private fun buildPath(s: Stroke, page: Int): Path {
        val p = Path()
        val a = s.pts
        val n = a.size / 2
        val h = hs[page]
        var px = a[0] * baseW
        var py = a[1] * h
        p.moveTo(px, py)
        if (n == 1) {
            p.lineTo(px + 0.01f, py)
            return p
        }
        for (i in 1 until n) {
            val x = a[2 * i] * baseW
            val y = a[2 * i + 1] * h
            p.quadTo(px, py, (px + x) / 2f, (py + y) / 2f)
            px = x
            py = y
        }
        p.lineTo(px, py)
        return p
    }

    private fun drawStroke(c: Canvas, s: Stroke, page: Int) {
        val cached = s.path
        val path: Path = if (cached != null && s.pathVer == layoutVer) {
            cached
        } else {
            val np = buildPath(s, page)
            s.path = np
            s.pathVer = layoutVer
            np
        }
        strokePaint.color = s.color
        strokePaint.alpha = if (s.tool == Tool.HL) 102 else 255
        strokePaint.strokeWidth = s.width * baseW
        c.drawPath(path, strokePaint)
    }

    private fun drawInk(c: Canvas, i: Int, left: Float, top: Float, z: Float) {
        val store = ink ?: return
        val list = store.strokes(i)
        val cur = curStroke
        val showCur = cur != null && curPage == i
        if (list.isEmpty() && !showCur) return
        c.save()
        c.translate(left, top)
        c.scale(z, z)
        for (s in list) drawStroke(c, s, i)
        if (showCur && cur != null) {
            cur.pathVer = -1
            drawStroke(c, cur, i)
        }
        c.restore()
    }

    // ---------------------------------------------------------------- input

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (doc == null) return true
        scaleDetector.onTouchEvent(e)
        if (drawMode && ink != null && handleInk(e)) return true
        gestureDetector.onTouchEvent(e)
        return true
    }

    override fun computeScroll() {
        if (scroller.computeScrollOffset()) {
            sx = scroller.currX.toFloat()
            sy = scroller.currY.toFloat()
            clampScroll()
            notifyScroll()
            postInvalidateOnAnimation()
        }
    }

    // ---------------------------------------------------------------- drawing

    private fun lodFor(i: Int, z: Float): Int {
        val r = (baseW * z / pw[i]).toDouble()
        return (2.0 * ln(r) / ln(2.0)).roundToInt()
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(bgColor)
        if (doc == null || pages == 0 || baseW <= 0f) return
        frame++
        val z = zoom
        val ox = offX(z)
        val first = pageAt((sy - topPad) / z)
        val last = pageAt((sy - topPad + height) / z)
        var allReady = true
        for (i in first..last) {
            val left = ox - sx
            val top = tops[i] * z - sy + topPad
            dstRect.set(left, top, left + baseW * z, top + hs[i] * z)
            canvas.drawRect(dstRect, white)
            val lo = lowCache.get(i)
            if (lo != null) {
                canvas.drawBitmap(lo, null, dstRect, bmpPaint)
            } else if (!lowFailed.containsKey(i)) {
                requestLow(i)
            }
            val lodFb = lodFor(i, fallbackZoom)
            val lodNow = if (locked) lodFb else lodFor(i, z)
            if (lodFb != lodNow) drawPageTiles(canvas, i, left, top, z, lodFb, false)
            if (!drawPageTiles(canvas, i, left, top, z, lodNow, true)) allReady = false
            drawInk(canvas, i, left, top, z)
        }
        if (erasingNow) canvas.drawCircle(eraserX, eraserY, eraserRadius, ringPaint)
        if (!locked && allReady && fallbackZoom != z) fallbackZoom = z
    }

    private fun drawPageTiles(c: Canvas, i: Int, left: Float, top: Float, z: Float, lod: Int, request: Boolean): Boolean {
        val r = baseW * z / pw[i]
        val q = 2.0.pow(lod / 2.0).toFloat()
        val tp = tile / q
        val fullW = pw[i] * q
        val fullH = ph[i] * q
        val nx = max(1, ceil(fullW / tile).toInt())
        val ny = max(1, ceil(fullH / tile).toInt())
        val vx0 = max(0f, -left / r)
        val vx1 = min(pw[i], (width - left) / r)
        val vy0 = max(0f, -top / r)
        val vy1 = min(ph[i], (height - top) / r)
        if (vx1 <= vx0 || vy1 <= vy0) return true
        val tx0 = floor(vx0 / tp).toInt().coerceIn(0, nx - 1)
        val tx1 = floor(vx1 / tp).toInt().coerceIn(0, nx - 1)
        val ty0 = floor(vy0 / tp).toInt().coerceIn(0, ny - 1)
        val ty1 = floor(vy1 / tp).toInt().coerceIn(0, ny - 1)
        var allReady = true
        for (ty in ty0..ty1) {
            for (tx in tx0..tx1) {
                val k = Key(i, lod, tx, ty)
                val bmp = tileCache.get(k)
                if (bmp != null) {
                    dstRect.set(
                        left + tx * tp * r,
                        top + ty * tp * r,
                        left + (tx * tp + bmp.width / q) * r,
                        top + (ty * tp + bmp.height / q) * r
                    )
                    dstRect.inset(-0.5f, -0.5f)
                    c.drawBitmap(bmp, null, dstRect, bmpPaint)
                } else {
                    allReady = false
                    if (request && !failed.containsKey(k)) requestTile(k)
                }
            }
        }
        return allReady
    }

    // ---------------------------------------------------------------- rendering (worker thread)

    private fun requestTile(k: Key) {
        want[k] = frame
        if (pending.putIfAbsent(k, true) != null) return
        worker.execute {
            try {
                val stamp = want[k] ?: -100
                if (stamp >= frame - 2 && tileCache.get(k) == null) renderTile(k)
            } catch (e: Throwable) {
                failed[k] = true
            } finally {
                pending.remove(k)
                want.remove(k)
                postInvalidateOnAnimation()
            }
        }
    }

    private fun requestLow(i: Int) {
        wantLow[i] = frame
        if (lowPending.putIfAbsent(i, true) != null) return
        worker.execute {
            try {
                val stamp = wantLow[i] ?: -100
                if (stamp >= frame - 4 && lowCache.get(i) == null) renderLow(i)
            } catch (e: Throwable) {
                lowFailed[i] = true
            } finally {
                lowPending.remove(i)
                wantLow.remove(i)
                postInvalidateOnAnimation()
            }
        }
    }

    private fun ensureOpen(d: PdfDocument, i: Int) {
        if (opened.add(i)) core.openPage(d, i)
    }

    private fun renderTile(k: Key) {
        val d = doc ?: return
        val q = 2.0.pow(k.lod / 2.0).toFloat()
        val fullW = (pw[k.page] * q).roundToInt()
        val fullH = (ph[k.page] * q).roundToInt()
        val wPx = min(tile, fullW - k.tx * tile)
        val hPx = min(tile, fullH - k.ty * tile)
        if (wPx <= 0 || hPx <= 0) {
            failed[k] = true
            return
        }
        ensureOpen(d, k.page)
        val bmp = Bitmap.createBitmap(wPx, hPx, Bitmap.Config.ARGB_8888)
        bmp.eraseColor(Color.WHITE)
        core.renderPageBitmap(d, bmp, k.page, -k.tx * tile, -k.ty * tile, fullW, fullH, false)
        tileCache.put(k, bmp)
    }

    private fun renderLow(i: Int) {
        val d = doc ?: return
        val w = 480
        val h = max(1, (480f * ph[i] / pw[i]).roundToInt())
        ensureOpen(d, i)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bmp.eraseColor(Color.WHITE)
        core.renderPageBitmap(d, bmp, i, 0, 0, w, h, false)
        lowCache.put(i, bmp)
    }
}
