package com.hibr.nativeapp

import android.content.Context
import android.graphics.Color
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.text.StaticLayout
import android.text.TextPaint
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.graphics.image.PDImageXObject
import com.tom_roush.pdfbox.pdmodel.graphics.state.PDExtendedGraphicsState
import java.io.File

object Exporter {

    private fun outFile(c: Context, d: Doc): File {
        val dir = File(c.cacheDir, "export")
        dir.mkdirs()
        val safe = d.name.replace(Regex("[\\\\/:*?\"<>|]"), "_")
        return File(dir, "$safe.pdf")
    }

    /** Returns a PDF ready to share: with the ink burned in if there is any, else a copy of the original. */
    fun prepare(c: Context, d: Doc): File {
        return if (Library.inkFile(c, d.id).exists()) {
            export(c, d)
        } else {
            val out = outFile(c, d)
            Library.file(c, d.id).copyTo(out, overwrite = true)
            out
        }
    }

    fun export(c: Context, d: Doc): File {
        PDFBoxResourceLoader.init(c.applicationContext)
        val store = InkStore(c, d.id)
        store.load()
        val out = outFile(c, d)
        val pd = PDDocument.load(Library.file(c, d.id))
        val imgs = HashMap<String, PDImageXObject>()
        try {
            for (p in 0 until pd.numberOfPages) {
                val list = store.strokes(p)
                if (list.isEmpty()) continue
                val page = pd.getPage(p)
                val box = page.cropBox
                val w = box.width
                val h = box.height
                val x0 = box.lowerLeftX
                val y0 = box.lowerLeftY
                val cs = PDPageContentStream(pd, page, PDPageContentStream.AppendMode.APPEND, true, true)
                try {
                    for (s in list) {
                        if (s.tool == Tool.TEXT) {
                            val t = s.text ?: continue
                            val ref = 1600f
                            val bw = Math.max(1, (s.pts[2] * ref).toInt())
                            val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
                            tp.textSize = s.width * ref
                            tp.color = s.color
                            val lay = StaticLayout.Builder.obtain(t, 0, t.length, tp, bw)
                                .setLineSpacing(0f, 1.1f)
                                .build()
                            val bm = Bitmap.createBitmap(bw, Math.max(1, lay.height), Bitmap.Config.ARGB_8888)
                            lay.draw(Canvas(bm))
                            val tf = File(c.cacheDir, "txt_" + System.nanoTime() + ".png")
                            tf.outputStream().use { bm.compress(Bitmap.CompressFormat.PNG, 100, it) }
                            val tim = PDImageXObject.createFromFile(tf.absolutePath, pd)
                            tf.delete()
                            val q = s.pts
                            val dh = q[2] * w * bm.height.toFloat() / bw.toFloat()
                            cs.drawImage(tim, x0 + q[0] * w, y0 + (1f - q[1]) * h - dh, q[2] * w, dh)
                            continue
                        }
                        if (s.tool == Tool.IMAGE) {
                            val name = s.img ?: continue
                            val f = File(Library.imgDir(c, d.id), name)
                            if (!f.exists()) continue
                            val im = imgs.getOrPut(name) { PDImageXObject.createFromFile(f.absolutePath, pd) }
                            val q = s.pts
                            cs.drawImage(im, x0 + q[0] * w, y0 + (1f - q[1] - q[3]) * h, q[2] * w, q[3] * h)
                            continue
                        }
                        val gs = PDExtendedGraphicsState()
                        gs.setStrokingAlphaConstant(if (s.tool == Tool.HL) 0.4f else 1f)
                        cs.setGraphicsStateParameters(gs)
                        cs.setStrokingColor(
                            Color.red(s.color) / 255f,
                            Color.green(s.color) / 255f,
                            Color.blue(s.color) / 255f
                        )
                        cs.setLineWidth(s.width * w)
                        cs.setLineCapStyle(1)
                        cs.setLineJoinStyle(1)
                        val a = s.pts
                        val n = a.size / 2
                        cs.moveTo(x0 + a[0] * w, y0 + (1f - a[1]) * h)
                        if (n == 1) cs.lineTo(x0 + a[0] * w + 0.01f, y0 + (1f - a[1]) * h)
                        for (i in 1 until n) {
                            cs.lineTo(x0 + a[2 * i] * w, y0 + (1f - a[2 * i + 1]) * h)
                        }
                        cs.stroke()
                    }
                } finally {
                    cs.close()
                }
            }
            pd.save(out)
        } finally {
            pd.close()
        }
        return out
    }
}
